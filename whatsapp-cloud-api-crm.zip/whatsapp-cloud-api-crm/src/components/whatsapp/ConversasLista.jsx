import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { format, isToday } from "date-fns";
import { Search, Loader2, Plus, Archive, Inbox, Clock, AlertCircle } from "lucide-react";
import { listarConversas, abrirPorTelefone } from "@/lib/whatsapp/api";
import { useChatPolling } from "@/lib/chat/useChatPolling";
import { normalizarTelefone, formatarTelefone, restanteDaJanela } from "@/lib/whatsapp/telefone";

/**
 * Lista de conversas do WhatsApp.
 *
 * O que ela mostra e o resto da tela não mostra: **o estado da janela de 24h**.
 * Saber, antes de abrir a conversa, quais aceitam resposta livre é o que
 * organiza o dia do atendimento — as que estão vencendo são as que precisam de
 * resposta agora, porque depois só um template (cobrado) reabre o contato.
 */

const iniciais = (nome) =>
  String(nome || "?")
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0])
    .join("")
    .toUpperCase();

const quando = (iso) => {
  const d = new Date(iso || "");
  if (Number.isNaN(d.getTime())) return "";
  return isToday(d) ? format(d, "HH:mm") : format(d, "dd/MM");
};

const nomeDaConversa = (c) =>
  c.vinculoNome || c.nomePerfil || c.telefoneExibicao || formatarTelefone(c.telefone);

/** Pastilha da janela: verde enquanto dá para responder, cinza quando fechou. */
function Janela({ conversa }) {
  const resta = restanteDaJanela(conversa.janelaExpiraEm);
  if (conversa.janelaAberta && resta) {
    const apertado = resta.endsWith("min") || resta === "1 h";
    return (
      <span
        title={`A janela de resposta livre fecha em ${resta}`}
        className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-medium ${
          apertado
            ? "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"
            : "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300"
        }`}
      >
        <Clock className="h-2.5 w-2.5" />
        {resta}
      </span>
    );
  }
  return (
    <span
      title="Fora da janela de 24h: só um template aprovado reabre o contato"
      className="inline-flex items-center gap-1 rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-medium text-slate-500 dark:bg-slate-700/40 dark:text-slate-400"
    >
      fechada
    </span>
  );
}

export default function ConversasLista({ conversaAtivaId, onSelecionar, recarregarEm = 0 }) {
  const [conversas, setConversas] = useState([]);
  const [busca, setBusca] = useState("");
  const [status, setStatus] = useState("aberta");
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");
  const [abrindo, setAbrindo] = useState(false);
  const [novoTelefone, setNovoTelefone] = useState("");
  const [novoAberto, setNovoAberto] = useState(false);

  // A assinatura do último resultado: é o que diz ao polling se houve novidade
  // (e portanto se vale manter o ritmo curto).
  const assinaturaRef = useRef("");

  const carregar = useCallback(async () => {
    try {
      const { conversas: lista } = await listarConversas({ busca, status });
      const recebidas = lista || [];
      const assinatura = recebidas
        .map((c) => `${c.id}:${c.ultimaMensagemEm}:${c.naoLidas}`)
        .join("|");
      const mudou = assinatura !== assinaturaRef.current;
      assinaturaRef.current = assinatura;
      if (mudou) setConversas(recebidas);
      setErro("");
      return mudou;
    } catch (e) {
      setErro(e?.message || "Não foi possível carregar as conversas");
      return false;
    } finally {
      setCarregando(false);
    }
  }, [busca, status]);

  const marcarAtividade = useChatPolling(carregar, { rapido: 8000, lento: 45000, ociosoApos: 90000 });

  // `carregar` muda de identidade a cada tecla digitada na busca (ela entra na
  // dependência). Guardá-la numa ref é o que permite os dois efeitos abaixo
  // dispararem pelo motivo deles, e não porque a função foi recriada.
  const carregarRef = useRef(carregar);
  carregarRef.current = carregar;

  // A thread avisa que mexeu na conversa (leu, vinculou, respondeu): a lista
  // atualiza na hora, em vez de esperar o próximo tique. Recarregar, e não
  // remontar: remontar apagaria a busca digitada e a rolagem.
  const primeiraCarga = useRef(true);
  useEffect(() => {
    if (primeiraCarga.current) { primeiraCarga.current = false; return; }
    carregarRef.current();
  }, [recarregarEm]);

  // Busca e troca de caixa: espera a digitação parar. Sem isto seria uma
  // consulta por tecla — e a consulta varre as conversas todas.
  const primeiraBusca = useRef(true);
  useEffect(() => {
    if (primeiraBusca.current) { primeiraBusca.current = false; return undefined; }
    const t = setTimeout(() => carregarRef.current(), 300);
    return () => clearTimeout(t);
  }, [busca, status]);

  const totalNaoLidas = useMemo(
    () => conversas.reduce((soma, c) => soma + Number(c.naoLidas || 0), 0),
    [conversas],
  );

  const numeroValido = normalizarTelefone(novoTelefone);

  const abrirNova = async () => {
    if (!numeroValido || abrindo) return;
    setAbrindo(true);
    try {
      const { conversa } = await abrirPorTelefone(novoTelefone);
      setNovoTelefone("");
      setNovoAberto(false);
      marcarAtividade();
      await carregar();
      onSelecionar?.(conversa?.id);
    } catch (e) {
      setErro(e?.message || "Não foi possível abrir a conversa");
    } finally {
      setAbrindo(false);
    }
  };

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center justify-between gap-2 border-b border-slate-200 px-3 py-2.5 dark:border-[#334155]">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-slate-800 dark:text-slate-100">Conversas</span>
          {totalNaoLidas > 0 && (
            <span className="rounded-full bg-emerald-500 px-1.5 py-0.5 text-[10px] font-bold text-white">
              {totalNaoLidas}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setStatus((s) => (s === "aberta" ? "arquivada" : "aberta"))}
            title={status === "aberta" ? "Ver arquivadas" : "Ver caixa de entrada"}
            className="rounded-md p-1.5 text-slate-500 transition-colors hover:bg-slate-100 dark:hover:bg-[#243348]"
          >
            {status === "aberta" ? <Archive className="h-4 w-4" /> : <Inbox className="h-4 w-4" />}
          </button>
          <button
            type="button"
            onClick={() => setNovoAberto((v) => !v)}
            title="Iniciar conversa por número"
            className="rounded-md p-1.5 text-slate-500 transition-colors hover:bg-slate-100 dark:hover:bg-[#243348]"
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>
      </div>

      {novoAberto && (
        <div className="space-y-1.5 border-b border-slate-200 p-2 dark:border-[#334155]">
          <input
            value={novoTelefone}
            onChange={(e) => setNovoTelefone(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && abrirNova()}
            placeholder="DDD + número, ou +código do país"
            className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-emerald-400 dark:border-[#334155] dark:bg-[#0f172a] dark:text-slate-100"
          />
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              {novoTelefone && !numeroValido
                ? "Número não reconhecido"
                : numeroValido
                  ? formatarTelefone(numeroValido)
                  : " "}
            </span>
            <button
              type="button"
              onClick={abrirNova}
              disabled={!numeroValido || abrindo}
              className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white disabled:opacity-40"
            >
              {abrindo ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Abrir"}
            </button>
          </div>
          {/* A conversa nova nasce FORA da janela: quem nunca escreveu para nós
              não deu as 24h. A tela avisa antes, não depois da recusa. */}
          <p className="text-[11px] text-slate-500 dark:text-slate-400">
            Contato novo só recebe template aprovado até responder.
          </p>
        </div>
      )}

      <div className="border-b border-slate-200 p-2 dark:border-[#334155]">
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
          <input
            value={busca}
            onChange={(e) => { setBusca(e.target.value); marcarAtividade(); }}
            placeholder="Buscar por nome ou número"
            className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-8 pr-3 text-sm outline-none focus:border-emerald-400 dark:border-[#334155] dark:bg-[#0f172a] dark:text-slate-100"
          />
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto">
        {carregando && (
          <div className="flex items-center justify-center py-8 text-slate-400">
            <Loader2 className="h-5 w-5 animate-spin" />
          </div>
        )}

        {!carregando && erro && (
          <div className="m-3 flex items-start gap-2 rounded-lg bg-red-50 p-3 text-xs text-red-700 dark:bg-red-500/10 dark:text-red-300">
            <AlertCircle className="mt-0.5 h-3.5 w-3.5 flex-shrink-0" />
            <span>{erro}</span>
          </div>
        )}

        {!carregando && !erro && conversas.length === 0 && (
          <p className="px-4 py-8 text-center text-xs text-slate-500 dark:text-slate-400">
            {status === "aberta"
              ? "Nenhuma conversa por aqui ainda."
              : "Nenhuma conversa arquivada."}
          </p>
        )}

        {conversas.map((c) => {
          const ativa = c.id === conversaAtivaId;
          return (
            <button
              key={c.id}
              type="button"
              onClick={() => { marcarAtividade(); onSelecionar?.(c.id); }}
              className={`flex w-full items-start gap-2.5 border-b border-slate-100 px-3 py-2.5 text-left transition-colors dark:border-[#243348] ${
                ativa
                  ? "bg-emerald-50 dark:bg-emerald-500/10"
                  : "hover:bg-slate-50 dark:hover:bg-[#243348]"
              }`}
            >
              <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-emerald-100 text-xs font-semibold text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300">
                {iniciais(nomeDaConversa(c))}
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="truncate text-sm font-medium text-slate-800 dark:text-slate-100">
                    {nomeDaConversa(c)}
                  </span>
                  <span className="flex-shrink-0 text-[10px] text-slate-400">
                    {quando(c.ultimaMensagemEm)}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-xs text-slate-500 dark:text-slate-400">
                    {c.ultimaMensagemDirecao === "saida" && "Você: "}
                    {c.ultimaMensagemPreview || "—"}
                  </span>
                  {c.naoLidas > 0 && (
                    <span className="flex-shrink-0 rounded-full bg-emerald-500 px-1.5 py-0.5 text-[10px] font-bold text-white">
                      {c.naoLidas}
                    </span>
                  )}
                </div>
                <div className="mt-1 flex items-center gap-1.5">
                  <Janela conversa={c} />
                  {c.vinculoTipo && c.vinculoTipo !== "nenhum" && (
                    <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-500 dark:bg-slate-700/40 dark:text-slate-400">
                      {c.vinculoTipo}
                    </span>
                  )}
                  {c.responsavelNome && (
                    <span className="truncate text-[10px] text-slate-400">{c.responsavelNome}</span>
                  )}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
