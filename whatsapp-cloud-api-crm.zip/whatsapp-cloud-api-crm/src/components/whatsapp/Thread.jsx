import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { format, isToday } from "date-fns";
import {
  ArrowLeft, Send, Loader2, AlertCircle, Check, CheckCheck, Clock, Paperclip,
  UserPlus, UserMinus, Link2, Unlink, Ticket, Archive, FileText, X, Search,
} from "lucide-react";
import toast from "react-hot-toast";
import {
  listarMensagens, marcarLido, enviarTexto, enviarTemplate, listarTemplates,
  assumir as assumirConversa, arquivar as arquivarConversa, abrirTicket,
  vincular, sugerirVinculo, buscarCadastros,
} from "@/lib/whatsapp/api";
import { useChatPolling } from "@/lib/chat/useChatPolling";
import { formatarTelefone, restanteDaJanela } from "@/lib/whatsapp/telefone";

/**
 * A conversa aberta: histórico + o que dá para responder AGORA.
 *
 * O compositor tem dois estados, e não é enfeite: dentro da janela de 24h ele é
 * uma caixa de texto; fora dela, o texto livre não existe — a Meta recusaria — e
 * o que aparece é a lista de templates aprovados. Trocar sozinho é o que impede
 * o atendente de escrever uma resposta inteira para receber "falhou" no fim.
 */

const hora = (iso) => {
  const d = new Date(iso || "");
  if (Number.isNaN(d.getTime())) return "";
  return isToday(d) ? format(d, "HH:mm") : format(d, "dd/MM HH:mm");
};

const nomeDaConversa = (c) =>
  c?.vinculoNome || c?.nomePerfil || c?.telefoneExibicao || formatarTelefone(c?.telefone);

/** Os tiques: pendente → enviada → entregue → lida, e o vermelho da recusa. */
function Entrega({ mensagem }) {
  if (mensagem.direcao !== "saida") return null;
  if (mensagem.status === "falhou") {
    return (
      <span title={mensagem.erroMensagem || "Recusada"} className="text-red-500">
        <AlertCircle className="h-3 w-3" />
      </span>
    );
  }
  if (mensagem.status === "lida") return <CheckCheck className="h-3 w-3 text-sky-300" />;
  if (mensagem.status === "entregue") return <CheckCheck className="h-3 w-3 opacity-70" />;
  if (mensagem.status === "enviada") return <Check className="h-3 w-3 opacity-70" />;
  return <Clock className="h-3 w-3 opacity-50" />;
}

/**
 * Só `https:` vira link.
 *
 * Segunda barreira, proposital: `enviarWhatsApp` já recusa outro esquema na
 * entrada, mas uma linha gravada antes desta trava — ou por outro caminho —
 * não pode virar `javascript:` clicável na thread. O React 18 apenas avisa no
 * console nesse caso; ele não bloqueia.
 */
const linkSeguro = (url) => /^https:\/\//i.test(String(url || ""));

/** Mídia recebida — imagem aparece, o resto vira link para baixar. */
function Midia({ midia }) {
  if (!midia) return null;
  if (midia.erro) {
    return (
      <p className="mb-1 rounded bg-black/10 px-2 py-1 text-[11px] italic opacity-80">
        Arquivo não guardado: {midia.erro}
      </p>
    );
  }
  if (!midia.url) return null;
  if (!linkSeguro(midia.url)) {
    return (
      <p className="mb-1 rounded bg-black/10 px-2 py-1 text-[11px] italic opacity-80">
        Anexo em endereço não confiável: {midia.nome || "arquivo"}
      </p>
    );
  }
  if (String(midia.mime || "").startsWith("image/")) {
    return (
      <a href={midia.url} target="_blank" rel="noopener noreferrer">
        <img src={midia.url} alt={midia.nome || "imagem"} className="mb-1 max-h-64 rounded-lg" />
      </a>
    );
  }
  return (
    <a
      href={midia.url}
      target="_blank"
      rel="noopener noreferrer"
      className="mb-1 flex items-center gap-1.5 rounded bg-black/10 px-2 py-1.5 text-xs underline"
    >
      <Paperclip className="h-3 w-3" />
      {midia.nome || "arquivo"}
    </a>
  );
}

/** Escolha do template e das variáveis dele — o caminho da janela fechada. */
function CompositorTemplate({ conversaId, onEnviou }) {
  const [templates, setTemplates] = useState([]);
  const [escolhido, setEscolhido] = useState(null);
  const [valores, setValores] = useState([]);
  const [enviando, setEnviando] = useState(false);

  useEffect(() => {
    listarTemplates()
      .then((d) => setTemplates(d.templates || []))
      .catch(() => setTemplates([]));
  }, []);

  const disparaveis = useMemo(() => templates.filter((t) => t.disparavel), [templates]);

  const escolher = (t) => {
    setEscolhido(t);
    setValores((t.metaVariaveis || []).map(() => ""));
  };

  const enviar = async () => {
    if (!escolhido || enviando) return;
    setEnviando(true);
    try {
      await enviarTemplate(conversaId, escolhido.id, valores);
      setEscolhido(null);
      setValores([]);
      onEnviou?.();
      toast.success("Template enviado — a conversa reabriu.");
    } catch (e) {
      toast.error(e?.message || "Não foi possível enviar o template");
    } finally {
      setEnviando(false);
    }
  };

  return (
    <div className="space-y-2 border-t border-slate-200 bg-amber-50/60 p-3 dark:border-[#334155] dark:bg-amber-500/5">
      <p className="flex items-start gap-1.5 text-xs text-amber-800 dark:text-amber-300">
        <AlertCircle className="mt-0.5 h-3.5 w-3.5 flex-shrink-0" />
        <span>
          Passaram-se mais de 24h desde a última mensagem do cliente. Só um template
          aprovado pela Meta reabre a conversa — e ele é cobrado como conversa nova.
        </span>
      </p>

      {disparaveis.length === 0 ? (
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Nenhum template aprovado cadastrado. Cadastre em Templates de Mensagem o nome
          aprovado na Meta para poder reabrir conversas.
        </p>
      ) : !escolhido ? (
        <div className="flex flex-wrap gap-1.5">
          {disparaveis.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => escolher(t)}
              className="flex items-center gap-1.5 rounded-lg border border-amber-300 bg-white px-2.5 py-1.5 text-xs font-medium text-amber-800 transition-colors hover:bg-amber-100 dark:border-amber-500/40 dark:bg-[#1e293b] dark:text-amber-300"
            >
              <FileText className="h-3 w-3" />
              {t.titulo || t.metaNome}
            </button>
          ))}
        </div>
      ) : (
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
              {escolhido.titulo || escolhido.metaNome}
            </span>
            <button
              type="button"
              onClick={() => setEscolhido(null)}
              className="rounded p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-[#243348]"
              aria-label="Trocar template"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
          {escolhido.conteudo && (
            <p className="whitespace-pre-wrap rounded bg-white p-2 text-xs text-slate-600 dark:bg-[#0f172a] dark:text-slate-300">
              {escolhido.conteudo}
            </p>
          )}
          {(escolhido.metaVariaveis || []).map((rotulo, i) => (
            <input
              key={`${escolhido.id}-${i}`}
              value={valores[i] || ""}
              onChange={(e) => {
                const novo = [...valores];
                novo[i] = e.target.value;
                setValores(novo);
              }}
              placeholder={rotulo || `Variável ${i + 1}`}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-sm outline-none focus:border-emerald-400 dark:border-[#334155] dark:bg-[#0f172a] dark:text-slate-100"
            />
          ))}
          <button
            type="button"
            onClick={enviar}
            disabled={enviando}
            className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white disabled:opacity-40"
          >
            {enviando ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
            Enviar template
          </button>
        </div>
      )}
    </div>
  );
}

/** Vínculo com o cadastro: sugestão pelo telefone e busca por nome. */
function PainelVinculo({ conversa, onMudou, onFechar }) {
  const [termo, setTermo] = useState("");
  const [resultados, setResultados] = useState([]);
  const [sugestao, setSugestao] = useState(null);
  const [ocupado, setOcupado] = useState(false);

  useEffect(() => {
    if (conversa.vinculoTipo !== "nenhum") return;
    sugerirVinculo(conversa.id).then((d) => setSugestao(d.sugestao || null)).catch(() => {});
  }, [conversa.id, conversa.vinculoTipo]);

  useEffect(() => {
    if (termo.trim().length < 2) { setResultados([]); return undefined; }
    // Espera a digitação parar: uma busca por tecla varreria as três entidades
    // a cada letra.
    const t = setTimeout(() => {
      buscarCadastros(termo).then((d) => setResultados(d.cadastros || [])).catch(() => setResultados([]));
    }, 350);
    return () => clearTimeout(t);
  }, [termo]);

  const aplicar = async (tipo, id) => {
    setOcupado(true);
    try {
      await vincular(conversa.id, tipo, id);
      await onMudou?.();
      onFechar?.();
    } catch (e) {
      toast.error(e?.message || "Não foi possível vincular");
    } finally {
      setOcupado(false);
    }
  };

  return (
    <div className="space-y-2 border-b border-slate-200 bg-slate-50 p-3 dark:border-[#334155] dark:bg-[#172033]">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
          Vincular a um cadastro
        </span>
        <button type="button" onClick={onFechar} className="rounded p-1 text-slate-400" aria-label="Fechar">
          <X className="h-3.5 w-3.5" />
        </button>
      </div>

      {conversa.vinculoTipo !== "nenhum" && (
        <button
          type="button"
          disabled={ocupado}
          onClick={() => aplicar("nenhum", "")}
          className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs text-slate-600 dark:border-[#334155] dark:text-slate-300"
        >
          <Unlink className="h-3 w-3" />
          Desvincular de {conversa.vinculoNome}
        </button>
      )}

      {sugestao && conversa.vinculoTipo === "nenhum" && (
        <button
          type="button"
          disabled={ocupado}
          onClick={() => aplicar(sugestao.vinculoTipo, sugestao.vinculoId)}
          className="flex w-full items-center gap-1.5 rounded-lg bg-emerald-50 px-2.5 py-1.5 text-left text-xs text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-300"
        >
          <Link2 className="h-3 w-3 flex-shrink-0" />
          Pelo telefone: {sugestao.vinculoNome} ({sugestao.vinculoTipo})
        </button>
      )}

      <div className="relative">
        <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
        <input
          value={termo}
          onChange={(e) => setTermo(e.target.value)}
          placeholder="Buscar cliente, contato ou prospect"
          className="w-full rounded-lg border border-slate-200 bg-white py-1.5 pl-8 pr-3 text-sm outline-none focus:border-emerald-400 dark:border-[#334155] dark:bg-[#0f172a] dark:text-slate-100"
        />
      </div>

      {resultados.length > 0 && (
        <div className="max-h-40 overflow-y-auto rounded-lg border border-slate-200 dark:border-[#334155]">
          {resultados.map((r) => (
            <button
              key={`${r.tipo}-${r.id}`}
              type="button"
              disabled={ocupado}
              onClick={() => aplicar(r.tipo, r.id)}
              className="flex w-full items-center justify-between gap-2 border-b border-slate-100 px-2.5 py-1.5 text-left text-xs last:border-0 hover:bg-slate-50 dark:border-[#243348] dark:hover:bg-[#243348]"
            >
              <span className="truncate text-slate-700 dark:text-slate-200">{r.nome}</span>
              <span className="flex-shrink-0 text-[10px] text-slate-400">{r.tipo}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Thread({ conversaId, onVoltar, onMudouConversa }) {
  const [conversa, setConversa] = useState(null);
  const [mensagens, setMensagens] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");
  const [rascunho, setRascunho] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [mostrarVinculo, setMostrarVinculo] = useState(false);

  const fimRef = useRef(null);
  const assinaturaRef = useRef("");
  const marcadoRef = useRef("");

  const carregar = useCallback(async () => {
    if (!conversaId) return false;
    try {
      const dados = await listarMensagens(conversaId);
      const lista = dados.mensagens || [];
      const assinatura = lista.map((m) => `${m.id}:${m.status}`).join("|");
      const mudou = assinatura !== assinaturaRef.current;
      assinaturaRef.current = assinatura;
      if (mudou) setMensagens(lista);
      setConversa(dados.conversa || null);
      setErro("");
      return mudou;
    } catch (e) {
      setErro(e?.message || "Não foi possível carregar a conversa");
      return false;
    } finally {
      setCarregando(false);
    }
  }, [conversaId]);

  const marcarAtividade = useChatPolling(
    carregar,
    { rapido: 4000, lento: 30000, ociosoApos: 120000 },
    !!conversaId,
  );

  // Troca de conversa: zera o que era da anterior antes de a nova chegar, para
  // a thread não piscar as mensagens de outra pessoa.
  useEffect(() => {
    assinaturaRef.current = "";
    setMensagens([]);
    setConversa(null);
    setRascunho("");
    setMostrarVinculo(false);
    setCarregando(!!conversaId);
  }, [conversaId]);

  // Marca como lido a cada NOVIDADE, e não a cada tique da consulta: a chave
  // inclui o número de não lidas, então uma mensagem que chega com a conversa
  // aberta manda um recibo novo (é o que o WhatsApp faz), mas os tiques em que
  // nada mudou não mandam nada.
  useEffect(() => {
    if (!conversaId || !conversa?.naoLidas) return;
    const chave = `${conversaId}:${conversa.naoLidas}`;
    if (marcadoRef.current === chave) return;
    marcadoRef.current = chave;
    marcarLido(conversaId).then(() => onMudouConversa?.()).catch(() => {});
  }, [conversaId, conversa, onMudouConversa]);

  useEffect(() => {
    fimRef.current?.scrollIntoView({ block: "end" });
  }, [mensagens.length]);

  const enviar = async () => {
    const texto = rascunho.trim();
    if (!texto || enviando || !conversaId) return;
    setEnviando(true);
    marcarAtividade();
    try {
      await enviarTexto(conversaId, texto);
      setRascunho("");
      await carregar();
      onMudouConversa?.();
    } catch (e) {
      // "janela_fechada" não é falha de sistema: é a regra da Meta, e a tela já
      // troca para o compositor de template. Um toast vermelho aqui só
      // assustaria.
      if (e?.codigo === "janela_fechada") {
        await carregar();
        toast("A janela de 24h fechou. Use um template para reabrir.", { icon: "⏱️" });
      } else {
        toast.error(e?.message || "Não foi possível enviar");
      }
    } finally {
      setEnviando(false);
    }
  };

  const acao = async (fn, sucesso) => {
    try {
      await fn();
      await carregar();
      onMudouConversa?.();
      if (sucesso) toast.success(sucesso);
    } catch (e) {
      toast.error(e?.message || "Não foi possível concluir");
    }
  };

  if (!conversaId) {
    return (
      <div className="flex h-full items-center justify-center p-6 text-center text-sm text-slate-400">
        Escolha uma conversa à esquerda.
      </div>
    );
  }

  const resta = restanteDaJanela(conversa?.janelaExpiraEm);

  return (
    <div className="flex h-full min-h-0 flex-col">
      {/* ── Cabeçalho ────────────────────────────────────────────────────── */}
      <div className="flex items-center gap-2 border-b border-slate-200 px-3 py-2 dark:border-[#334155]">
        <button
          type="button"
          onClick={onVoltar}
          className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 sm:hidden dark:hover:bg-[#243348]"
          aria-label="Voltar"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>

        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-slate-800 dark:text-slate-100">
            {nomeDaConversa(conversa)}
          </p>
          <p className="truncate text-[11px] text-slate-500 dark:text-slate-400">
            {conversa?.telefoneExibicao || formatarTelefone(conversa?.telefone)}
            {conversa?.responsavelNome ? ` · ${conversa.responsavelNome}` : ""}
            {conversa?.janelaAberta && resta ? ` · janela: ${resta}` : conversa ? " · janela fechada" : ""}
          </p>
        </div>

        <div className="flex flex-shrink-0 items-center gap-0.5">
          <button
            type="button"
            title={conversa?.vinculoTipo === "nenhum" ? "Vincular a um cadastro" : `Vinculado a ${conversa?.vinculoNome}`}
            onClick={() => setMostrarVinculo((v) => !v)}
            className={`rounded-md p-1.5 transition-colors hover:bg-slate-100 dark:hover:bg-[#243348] ${
              conversa?.vinculoTipo && conversa.vinculoTipo !== "nenhum"
                ? "text-emerald-600 dark:text-emerald-400"
                : "text-slate-500"
            }`}
          >
            <Link2 className="h-4 w-4" />
          </button>
          <button
            type="button"
            title={conversa?.responsavelUserId ? "Largar o atendimento" : "Assumir o atendimento"}
            onClick={() => acao(
              () => assumirConversa(conversaId, !!conversa?.responsavelUserId),
              conversa?.responsavelUserId ? "Atendimento largado" : "Atendimento assumido",
            )}
            className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-[#243348]"
          >
            {conversa?.responsavelUserId ? <UserMinus className="h-4 w-4" /> : <UserPlus className="h-4 w-4" />}
          </button>
          <button
            type="button"
            title={conversa?.ticketId ? "Ticket já aberto para esta conversa" : "Abrir ticket de suporte"}
            disabled={!!conversa?.ticketId}
            onClick={() => acao(() => abrirTicket(conversaId), "Ticket aberto")}
            className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 disabled:opacity-40 dark:hover:bg-[#243348]"
          >
            <Ticket className="h-4 w-4" />
          </button>
          <button
            type="button"
            title={conversa?.status === "arquivada" ? "Devolver à caixa de entrada" : "Arquivar"}
            onClick={() => acao(
              () => arquivarConversa(conversaId, conversa?.status !== "arquivada"),
              conversa?.status === "arquivada" ? "De volta à caixa de entrada" : "Conversa arquivada",
            )}
            className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-[#243348]"
          >
            <Archive className="h-4 w-4" />
          </button>
        </div>
      </div>

      {mostrarVinculo && conversa && (
        <PainelVinculo
          conversa={conversa}
          onMudou={async () => { await carregar(); onMudouConversa?.(); }}
          onFechar={() => setMostrarVinculo(false)}
        />
      )}

      {/* ── Mensagens ────────────────────────────────────────────────────── */}
      <div className="min-h-0 flex-1 space-y-2 overflow-y-auto bg-slate-50 p-3 dark:bg-[#0f172a]">
        {carregando && (
          <div className="flex justify-center py-8 text-slate-400">
            <Loader2 className="h-5 w-5 animate-spin" />
          </div>
        )}

        {!carregando && erro && (
          <div className="flex items-start gap-2 rounded-lg bg-red-50 p-3 text-xs text-red-700 dark:bg-red-500/10 dark:text-red-300">
            <AlertCircle className="mt-0.5 h-3.5 w-3.5 flex-shrink-0" />
            <span>{erro}</span>
          </div>
        )}

        {!carregando && !erro && mensagens.length === 0 && (
          <p className="py-8 text-center text-xs text-slate-500 dark:text-slate-400">
            Nenhuma mensagem nesta conversa ainda.
          </p>
        )}

        {mensagens.map((m) => {
          const meu = m.direcao === "saida";
          return (
            <div key={m.id} className={`flex ${meu ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm shadow-sm ${
                  meu
                    ? `bg-emerald-600 text-white ${m.status === "falhou" ? "opacity-70" : ""}`
                    : "bg-white text-slate-800 dark:bg-[#1e293b] dark:text-slate-100"
                }`}
              >
                <Midia midia={m.midia} />
                {m.templateNome && (
                  <p className={`mb-1 text-[10px] uppercase tracking-wide ${meu ? "text-emerald-100" : "text-slate-400"}`}>
                    template · {m.templateNome}
                  </p>
                )}
                {m.texto && <p className="whitespace-pre-wrap break-words">{m.texto}</p>}
                <div className={`mt-1 flex items-center justify-end gap-1 text-[10px] ${meu ? "text-emerald-100" : "text-slate-400"}`}>
                  {m.autorNome && meu && <span className="mr-1 truncate max-w-[120px]">{m.autorNome}</span>}
                  <span>{hora(m.ocorridoEm)}</span>
                  <Entrega mensagem={m} />
                </div>
                {m.status === "falhou" && m.erroMensagem && (
                  <p className="mt-1 border-t border-white/20 pt-1 text-[10px]">
                    Recusada: {m.erroMensagem}
                  </p>
                )}
              </div>
            </div>
          );
        })}
        <div ref={fimRef} />
      </div>

      {/* ── Compositor ───────────────────────────────────────────────────── */}
      {conversa && !conversa.janelaAberta ? (
        <CompositorTemplate
          conversaId={conversaId}
          onEnviou={async () => { await carregar(); onMudouConversa?.(); }}
        />
      ) : (
        <div className="flex items-end gap-2 border-t border-slate-200 p-2 dark:border-[#334155]">
          <textarea
            value={rascunho}
            onChange={(e) => { setRascunho(e.target.value); marcarAtividade(); }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); enviar(); }
            }}
            rows={1}
            placeholder="Escreva uma mensagem"
            className="max-h-32 min-h-[38px] flex-1 resize-y rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-emerald-400 dark:border-[#334155] dark:bg-[#0f172a] dark:text-slate-100"
          />
          <button
            type="button"
            onClick={enviar}
            disabled={!rascunho.trim() || enviando}
            className="flex h-[38px] w-[38px] flex-shrink-0 items-center justify-center rounded-lg bg-emerald-600 text-white transition-colors disabled:opacity-40"
            aria-label="Enviar"
          >
            {enviando ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </button>
        </div>
      )}
    </div>
  );
}
