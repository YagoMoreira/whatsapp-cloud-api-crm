import React, { useCallback, useEffect, useState } from "react";
import { Loader2, ExternalLink, AlertCircle } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import Thread from "@/components/whatsapp/Thread";
import WhatsAppLogo from "@/components/whatsapp/WhatsAppLogo";
import { base44 } from "@/api/base44Client";
import { abrirPorTelefone } from "@/lib/whatsapp/api";
import { formatarTelefone } from "@/lib/whatsapp/telefone";
import { melhorNumeroWhatsApp } from "@/lib/whatsapp/contatoTelefone";

/**
 * Botão do WhatsApp com a gaveta lateral, para usar dentro de outra tela.
 *
 * Gaveta, e não aba, pelo mesmo motivo do `TeamsBotao`: a conversa não é um
 * capítulo do dossiê do cliente, é uma janela para outro sistema. Abre por cima
 * do que a pessoa está fazendo e fecha sem tirá-la do lugar — quem estava
 * vendo as pendências volta para as pendências.
 *
 * ── Por que a gaveta reaproveita a `Thread` inteira ──────────────────────────
 *
 * A primeira ideia foi uma versão "reduzida", só com as últimas mensagens. Mas
 * uma conversa pela metade é pior do que nenhuma: quem abre daqui abre para
 * responder, e responder exige a janela de 24h, o seletor de template quando
 * ela fecha e os tiques de entrega — tudo que já existe na `Thread`. O que
 * encolhe é o ESPAÇO (uma gaveta, não a tela cheia), não a capacidade.
 *
 * O que fica de fora daqui, e só existe na caixa de entrada: a lista das outras
 * conversas. Aqui já se sabe com quem se está falando.
 *
 * ── O que ele faz ao abrir ───────────────────────────────────────────────────
 *
 * Troca o telefone pela conversa (criando-a se for a primeira vez) e já mostra a
 * conversa: um clique, e se está falando com a pessoa. Se o número for de um
 * cliente sob responsabilidade de outra pessoa, o servidor recusa e a gaveta
 * explica — a regra de alcance é a mesma da caixa de entrada, conferida no
 * servidor (base44/shared/whatsappAcesso.ts).
 *
 * ── De onde sai o número ─────────────────────────────────────────────────────
 *
 * Não de um campo só. A ficha do agente sumia com este botão porque olhava
 * apenas `cliente.telefone`, e o número de quem veio do CRM mora em
 * `agente.telefones[]`. Agora quem procura é `melhorNumeroWhatsApp`, com as
 * fontes que a tela tiver à mão (o registro legado, o Agente) — e o porquê da
 * ordem está lá, em `lib/whatsapp/contatoTelefone.js`.
 */
export default function WhatsAppBotao({
  telefone,
  /**
   * Cadastros de onde tirar o número quando a tela não tem o telefone na mão:
   * o Cliente/Prospect legado, o Agente, ou os dois. Aceita um só ou uma lista.
   */
  contato,
  /** Quando a tela só tem o id (o ticket, por exemplo), passe o cliente. */
  clienteId,
  nome,
  rotulo = "WhatsApp",
  compacto = false,
  /**
   * Na ficha do contato o botão aparece mesmo sem número, desligado e dizendo
   * por quê. Some sem deixar rastro é o que fez parecer que o WhatsApp tinha
   * saído da ficha — e ali o lugar dele é fixo, ao lado do Teams. Em lista e
   * modal continua sumindo: botão morto repetido em vinte linhas é ruído.
   */
  mostrarSemNumero = false,
}) {
  const [aberto, setAberto] = useState(false);
  const [conversaId, setConversaId] = useState(null);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState("");
  const [clienteBuscado, setClienteBuscado] = useState(null);

  // O ticket guarda o cliente, não o telefone dele. Buscar aqui evita obrigar
  // cada tela que usa este botão a carregar o cadastro só para achar um campo.
  useEffect(() => {
    if (telefone || !clienteId) return;
    let cancelado = false;
    base44.entities.Cliente
      .filter({ id: clienteId })
      .then((achados) => {
        const c = achados?.[0];
        if (!cancelado && c) setClienteBuscado(c);
      })
      .catch(() => {});
    return () => { cancelado = true; };
  }, [telefone, clienteId]);

  const fontes = [telefone, ...(Array.isArray(contato) ? contato : [contato]), clienteBuscado];
  const achado = melhorNumeroWhatsApp(fontes);
  const numero = achado?.numero || null;
  // Número que veio de uma pessoa vinculada: quem atende é ela, e a tela diz
  // isso antes do clique — descobrir no "oi" é tarde.
  const comQuem = achado?.pessoa || nome || "";

  const abrir = useCallback(async () => {
    setAberto(true);
    if (conversaId || !numero) return;
    setCarregando(true);
    setErro("");
    try {
      const { conversa } = await abrirPorTelefone(numero);
      setConversaId(conversa?.id || null);
    } catch (e) {
      setErro(e?.message || "Não foi possível abrir a conversa");
    } finally {
      setCarregando(false);
    }
  }, [conversaId, numero]);

  // Cadastro sem telefone utilizável em lugar nenhum: some, ou fica desligado
  // explicando — em vez de existir e falhar no clique.
  if (!numero && !mostrarSemNumero) return null;

  const classe =
    (compacto
      ? "inline-flex h-8 items-center gap-1.5 rounded-md border px-2.5 text-xs font-medium transition-colors "
      : "inline-flex h-9 items-center gap-1.5 rounded-md border px-3 text-sm font-medium transition-colors ") +
    (numero
      ? "border-emerald-600/30 bg-emerald-600/10 text-emerald-700 hover:bg-emerald-600/20 dark:border-emerald-400/40 dark:bg-emerald-500/20 dark:text-emerald-300 dark:hover:bg-emerald-500/30"
      : "cursor-not-allowed border-slate-200 bg-slate-50 text-slate-400 dark:border-slate-700 dark:bg-slate-800/60 dark:text-slate-500");

  return (
    <>
      <button
        type="button"
        onClick={abrir}
        disabled={!numero}
        title={
          numero
            ? `Conversar no WhatsApp com ${comQuem || formatarTelefone(numero)} — ${formatarTelefone(numero)}`
            : "Sem telefone no cadastro para abrir o WhatsApp"
        }
        className={classe}
      >
        <WhatsAppLogo className={(compacto ? "h-3.5 w-3.5" : "h-4 w-4") + (numero ? "" : " opacity-40")} />
        {rotulo}
      </button>

      <Sheet open={aberto} onOpenChange={setAberto}>
        <SheetContent side="right" className="flex w-full flex-col p-0 sm:max-w-xl">
          <SheetHeader className="border-b border-slate-200 px-4 py-3 dark:border-[#334155]">
            <SheetTitle className="flex items-center gap-2 text-left">
              <WhatsAppLogo className="h-5 w-5" />
              WhatsApp
              {comQuem && (
                <span className="truncate text-sm font-normal text-slate-500 dark:text-slate-400">
                  · {comQuem}
                </span>
              )}
            </SheetTitle>
          </SheetHeader>

          <div className="min-h-0 flex-1">
            {carregando && (
              <div className="flex h-full items-center justify-center text-slate-400">
                <Loader2 className="h-5 w-5 animate-spin" />
              </div>
            )}

            {!carregando && erro && (
              <div className="m-4 flex items-start gap-2 rounded-lg bg-red-50 p-3 text-xs text-red-700 dark:bg-red-500/10 dark:text-red-300">
                <AlertCircle className="mt-0.5 h-3.5 w-3.5 flex-shrink-0" />
                <span>{erro}</span>
              </div>
            )}

            {!carregando && !erro && conversaId && (
              <Thread conversaId={conversaId} onVoltar={() => setAberto(false)} />
            )}
          </div>

          {conversaId && (
            <a
              href={`/whatsapp/conversas?conversa=${conversaId}`}
              className="flex items-center justify-center gap-1.5 border-t border-slate-200 px-4 py-2.5 text-xs font-medium text-slate-500 transition-colors hover:text-emerald-700 dark:border-[#334155] dark:text-slate-400 dark:hover:text-emerald-300"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              Abrir na caixa de entrada
            </a>
          )}
        </SheetContent>
      </Sheet>
    </>
  );
}
