import React, { useCallback, useRef, useState } from "react";
import { X, Maximize2, Megaphone } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { useAuth } from "@/components/auth/AuthContext";
import { sessaoValida } from "@/lib/sessao";
import { listarConversas } from "@/lib/whatsapp/api";
import { useChatPolling } from "@/lib/chat/useChatPolling";
import ConversasLista from "@/components/whatsapp/ConversasLista";
import Thread from "@/components/whatsapp/Thread";
import WhatsAppLogo from "@/components/whatsapp/WhatsAppLogo";

/**
 * O WhatsApp na navbar, ao lado do Chat.
 *
 * ─── Por que ele saiu do menu lateral ────────────────────────────────────────
 *
 * O WhatsApp era um módulo da barra lateral, entre Pós-venda e Horas
 * Trabalhadas. Só que ele não é um módulo: módulo é onde se trabalha um assunto
 * (clientes, tickets, metas), e o WhatsApp é um CANAL — a mesma natureza do Chat
 * interno, que nunca esteve no menu justamente por isso. Canal se abre por cima
 * do que a pessoa está fazendo e se fecha sem tirá-la do lugar; ir até o menu,
 * trocar de tela e perder o contexto para responder uma mensagem é o caminho
 * mais longo possível para o gesto mais frequente do dia.
 *
 * Então ele virou o que o Chat já era: um ícone na navbar, do lado do outro, com
 * o mesmo painel em primeiro plano — e a caixa de entrada em tela cheia continua
 * existindo, a um clique de distância, para quem vai passar a manhã nela.
 *
 * ─── Por que Dialog, e não um painel no header ───────────────────────────────
 *
 * O mesmo motivo do `ChatNavButton`: o header tem `backdrop-blur`, e
 * `backdrop-filter` muda o bloco de contenção dos descendentes `position: fixed`
 * — um painel fixo ali dentro colapsa atrás do próprio header e some. O portal
 * do Dialog renderiza fora do header e escapa disso.
 */

/**
 * Ritmo do contador: 45 s com movimento, 2 min depois de 5 minutos parados.
 * Mais lento que o do Chat de propósito — aqui só se espera o badge aparecer, e
 * a lista dentro do painel tem consulta própria, bem mais curta, quando está
 * aberta.
 */
const RITMO_BADGE = { rapido: 45000, lento: 120000, ociosoApos: 300000 };

export default function WhatsAppNavButton() {
  const navigate = useNavigate();
  const { podeVer } = useAuth();
  const [aberto, setAberto] = useState(false);
  const [conversaId, setConversaId] = useState(null);
  const [naoLidas, setNaoLidas] = useState(0);
  const anteriorRef = useRef(0);

  // Sem sessão provada a função recusa, e insistir só produziria 401 em série.
  // Sem a permissão do canal, o botão não existe — a mesma folha que protegia o
  // item do menu protege agora o ícone.
  const temAcesso = sessaoValida() && podeVer("connect.whatsapp");

  const contar = useCallback(async () => {
    try {
      const { conversas } = await listarConversas({ status: "aberta" });
      const total = (conversas || []).reduce((s, c) => s + Number(c.naoLidas || 0), 0);
      setNaoLidas(total);
      const mudou = total !== anteriorRef.current;
      anteriorRef.current = total;
      return mudou;
    } catch {
      // Falha de rede não zera o contador: some do badge é pior do que um
      // número velho por um minuto.
      return false;
    }
  }, []);

  // Enquanto o painel está aberto, quem consulta é a lista de dentro (e num
  // ritmo bem mais curto). Duas consultas para o mesmo dado seriam o dobro de
  // chamadas para a mesma resposta.
  useChatPolling(contar, RITMO_BADGE, temAcesso && !aberto);

  if (!temAcesso) return null;

  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        className="relative flex-shrink-0"
        onClick={() => setAberto(true)}
        aria-label="WhatsApp"
        title="WhatsApp"
      >
        <WhatsAppLogo className="h-5 w-5" />
        {naoLidas > 0 && (
          <span className="absolute -right-0.5 -top-0.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-emerald-600 px-1 text-[10px] font-bold text-white">
            {naoLidas > 49 ? "50+" : naoLidas}
          </span>
        )}
      </Button>

      <Dialog open={aberto} onOpenChange={setAberto}>
        <DialogContent
          className="flex h-[88vh] w-full max-w-[min(64rem,calc(100vw-1.5rem))] min-w-0 flex-col gap-0 overflow-hidden bg-white p-0 dark:bg-[#1e293b] [&>button]:hidden"
        >
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3 dark:border-[#334155]">
            <DialogTitle className="flex items-center gap-2 text-sm font-semibold text-slate-800 dark:text-slate-100">
              <WhatsAppLogo className="h-6 w-6" />
              WhatsApp
            </DialogTitle>
            <span className="flex items-center gap-1">
              {/* As campanhas moram no mesmo canal, e é daqui que se chega
                  nelas: elas não têm item de menu próprio pelo mesmo motivo
                  que a caixa de entrada não tem — canal não é módulo. */}
              <button
                type="button"
                onClick={() => { setAberto(false); navigate("/whatsapp/campanhas"); }}
                className="rounded-md p-1.5 text-slate-500 transition-colors hover:bg-slate-100 dark:hover:bg-[#243348]"
                title="Campanhas — envio em lote"
              >
                <Megaphone className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => { setAberto(false); navigate("/whatsapp/conversas" + (conversaId ? `?conversa=${conversaId}` : "")); }}
                className="rounded-md p-1.5 text-slate-500 transition-colors hover:bg-slate-100 dark:hover:bg-[#243348]"
                title="Abrir a caixa de entrada em tela cheia"
              >
                <Maximize2 className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => setAberto(false)}
                className="rounded-md p-1.5 text-slate-500 transition-colors hover:bg-slate-100 dark:hover:bg-[#243348]"
                aria-label="Fechar"
              >
                <X className="h-4 w-4" />
              </button>
            </span>
          </div>

          <div className="flex min-h-0 flex-1">
            {/* No celular só uma coluna aparece por vez: lista, ou a conversa
                com o voltar no cabeçalho da thread. */}
            <div className={`w-full flex-shrink-0 border-r border-slate-200 dark:border-[#334155] sm:block sm:w-[300px] ${conversaId ? "hidden" : "block"}`}>
              <ConversasLista conversaAtivaId={conversaId} onSelecionar={setConversaId} />
            </div>
            <div className={`min-w-0 flex-1 ${conversaId ? "block" : "hidden sm:block"}`}>
              <Thread
                conversaId={conversaId}
                onVoltar={() => setConversaId(null)}
                onMudouConversa={contar}
              />
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
