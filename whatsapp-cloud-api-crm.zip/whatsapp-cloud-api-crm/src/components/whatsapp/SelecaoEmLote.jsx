import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { MessageCircle, X, Loader2, ArrowRight } from "lucide-react";
import toast from "react-hot-toast";
import {
  listarCampanhas, criarCampanha, adicionarDestinatarios,
} from "@/lib/whatsapp/campanhas";

/**
 * Seleção em lote nas listas de Clientes e Prospects.
 *
 * A barra só aparece quando há alguém marcado, e some sozinha quando a seleção
 * esvazia — uma lista de 2.000 linhas não pode ganhar uma faixa permanente por
 * causa de uma ação que se usa uma vez por mês.
 *
 * ── O que esta tela NÃO faz ─────────────────────────────────────────────────
 *
 * Não manda mensagem, e não dá para mandar daqui. Ela só escolhe GENTE: o
 * texto, o template e o disparo ficam na tela da campanha, depois da aprovação
 * de um administrador. A separação é proposital — "selecionar 800 clientes" e
 * "mandar mensagem para 800 clientes" precisam ser dois gestos distintos, com
 * uma tela inteira entre eles.
 */

// ── O estado da seleção, para a lista não precisar reinventá-lo ─────────────

export function useSelecaoEmLote() {
  const [selecionados, setSelecionados] = useState([]);

  const alternar = useCallback((id) => {
    setSelecionados((atual) => (
      atual.includes(id) ? atual.filter((i) => i !== id) : [...atual, id]
    ));
  }, []);

  /**
   * Marca ou desmarca a página inteira.
   *
   * Preserva o que já estava marcado FORA desta página: a pessoa pagina,
   * marca mais gente e volta — perder a marcação anterior ao virar a página
   * seria descobrir o problema só depois de montar a lista toda.
   */
  const alternarPagina = useCallback((idsDaPagina) => {
    setSelecionados((atual) => {
      const todosMarcados = idsDaPagina.length > 0 && idsDaPagina.every((i) => atual.includes(i));
      if (todosMarcados) return atual.filter((i) => !idsDaPagina.includes(i));
      return [...new Set([...atual, ...idsDaPagina])];
    });
  }, []);

  const limpar = useCallback(() => setSelecionados([]), []);

  return { selecionados, alternar, alternarPagina, limpar, total: selecionados.length };
}

// ── A barra ─────────────────────────────────────────────────────────────────

export function BarraSelecao({ total, onLimpar, onEnviar }) {
  if (!total) return null;
  return (
    <div className="sticky bottom-4 z-20 mx-auto flex w-fit items-center gap-3 rounded-full border border-border bg-background/95 px-4 py-2 shadow-lg backdrop-blur">
      <span className="text-sm font-medium">
        {total} {total === 1 ? "selecionado" : "selecionados"}
      </span>
      <Button size="sm" onClick={onEnviar} className="h-8 gap-1.5 rounded-full">
        <MessageCircle className="h-3.5 w-3.5" />
        Enviar em lote
      </Button>
      <button
        type="button"
        onClick={onLimpar}
        className="rounded-full p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        aria-label="Limpar seleção"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

// ── A janela ────────────────────────────────────────────────────────────────

export function ModalEnvioEmLote({ aberto, aoFechar, tipo, ids }) {
  const navigate = useNavigate();
  const [rascunhos, setRascunhos] = useState([]);
  const [escolha, setEscolha] = useState("nova");
  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [finalidade, setFinalidade] = useState("aviso");
  const [salvando, setSalvando] = useState(false);
  const [resultado, setResultado] = useState(null);

  useEffect(() => {
    if (!aberto) return;
    setResultado(null);
    setSalvando(false);
    listarCampanhas()
      .then((r) => {
        // Só rascunho aceita gente nova: depois de submetida, o público é o que
        // o administrador leu quando aprovou.
        const abertas = (r?.campanhas || []).filter((c) => c.status === "rascunho");
        setRascunhos(abertas);
        setEscolha(abertas.length ? String(abertas[0].id) : "nova");
      })
      .catch(() => setRascunhos([]));
  }, [aberto]);

  async function confirmar() {
    setSalvando(true);
    try {
      let campanhaId = escolha;

      if (escolha === "nova") {
        const limpo = nome.trim();
        if (!limpo) {
          toast.error("Dê um nome à campanha.");
          setSalvando(false);
          return;
        }
        const r = await criarCampanha({ nome: limpo, descricao: descricao.trim(), finalidade });
        campanhaId = r?.campanha?.id;
      }

      if (!campanhaId) throw new Error("Não foi possível abrir a campanha.");

      const r = await adicionarDestinatarios(campanhaId, {
        clienteIds: tipo === "cliente" ? ids : [],
        prospectIds: tipo === "prospect" ? ids : [],
      });
      setResultado({ ...r, campanhaId });
    } catch (e) {
      toast.error(e?.message || "Não foi possível acrescentar à campanha.");
    } finally {
      setSalvando(false);
    }
  }

  return (
    <Dialog open={aberto} onOpenChange={(v) => !v && aoFechar()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Enviar em lote pelo WhatsApp</DialogTitle>
          <DialogDescription>
            {ids.length} {ids.length === 1 ? "cadastro selecionado" : "cadastros selecionados"}.
            Nada é enviado agora: a campanha vai para aprovação de um administrador antes.
          </DialogDescription>
        </DialogHeader>

        {resultado ? (
          // ── Depois de acrescentar ────────────────────────────────────────
          //
          // O que foi pulado é mostrado com o motivo, e não escondido: quem
          // selecionou 300 e viu 279 entrarem precisa saber quem foram os 21.
          <div className="space-y-4">
            <div className="rounded-lg border border-border p-4">
              <p className="text-2xl font-semibold text-emerald-600 dark:text-emerald-400">
                {resultado.acrescentados}
              </p>
              <p className="text-sm text-muted-foreground">
                {resultado.acrescentados === 1 ? "pessoa entrou na fila" : "pessoas entraram na fila"}
              </p>
            </div>

            {resultado.pulados > 0 && (
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 dark:border-amber-900/50 dark:bg-amber-500/10">
                <p className="text-sm font-medium text-amber-900 dark:text-amber-200">
                  {resultado.pulados} não {resultado.pulados === 1 ? "entrou" : "entraram"}
                </p>
                <ul className="mt-2 space-y-1 text-sm text-amber-800 dark:text-amber-300">
                  {Object.entries(resultado.motivos || {}).map(([motivo, quantos]) => (
                    <li key={motivo}>{quantos} — {motivo}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={aoFechar}>Continuar aqui</Button>
              <Button
                onClick={() => navigate(`/whatsapp/campanhas?campanha=${resultado.campanhaId}`)}
                className="gap-1.5"
              >
                Abrir a campanha
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ) : (
          // ── Escolher onde ────────────────────────────────────────────────
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>Campanha</Label>
              <Select value={escolha} onValueChange={setEscolha}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="nova">➕ Criar uma nova campanha</SelectItem>
                  {rascunhos.map((c) => (
                    <SelectItem key={c.id} value={String(c.id)}>
                      {c.nome} ({c.totalDestinatarios} na fila)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {rascunhos.length === 0 && (
                <p className="text-xs text-muted-foreground">
                  Você não tem rascunho aberto. Uma campanha já submetida não recebe gente nova.
                </p>
              )}
            </div>

            {escolha === "nova" && (
              <>
                <div className="space-y-1.5">
                  <Label htmlFor="campanha-nome">Nome</Label>
                  <Input
                    id="campanha-nome"
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    placeholder="Aviso de recesso — dezembro"
                    autoFocus
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="campanha-finalidade">Finalidade</Label>
                  <Select value={finalidade} onValueChange={setFinalidade}>
                    <SelectTrigger id="campanha-finalidade"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="aviso">Aviso operacional</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="campanha-descricao">Por que esta campanha existe</Label>
                  <Textarea
                    id="campanha-descricao"
                    value={descricao}
                    onChange={(e) => setDescricao(e.target.value)}
                    placeholder="É o que o administrador vai ler antes de aprovar."
                    rows={3}
                  />
                </div>
              </>
            )}

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={aoFechar} disabled={salvando}>Cancelar</Button>
              <Button onClick={confirmar} disabled={salvando}>
                {salvando && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Acrescentar à campanha
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
