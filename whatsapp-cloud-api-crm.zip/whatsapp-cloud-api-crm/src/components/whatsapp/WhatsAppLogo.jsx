import React from "react";

/** O verde da marca, para quem precisa dele fora do SVG. */
export const WHATSAPP_VERDE = "#25D366";

/**
 * Marca do WhatsApp.
 *
 * Existe porque o canal era representado pelo balão genérico do lucide
 * (`MessageCircle`) — o mesmo símbolo que o sistema usa para o Chat interno,
 * para menção e para notificação. Dois canais diferentes com o mesmo ícone na
 * mesma navbar obrigam a ler o `title` para saber onde se está clicando; a marca
 * resolve isso sem palavra nenhuma.
 *
 * É uma APROXIMAÇÃO desenhada aqui — o balão no verde oficial (#25D366) com o
 * fone branco dentro —, não o arquivo oficial da Meta. Assim como o `TeamsLogo`,
 * foi feita inline porque o build não busca imagem de fora e porque um SVG
 * inline não some se um CDN cair.
 *
 * Se um dia entrar o asset oficial no projeto, é só trocar o miolo deste
 * componente: todo mundo usa ele, ninguém desenha o logo na mão em outro lugar.
 */
export default function WhatsAppLogo({ className = "h-4 w-4" }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden focusable="false">
      {/* O balão: o círculo e a ponta no canto inferior esquerdo. */}
      <circle cx="12.7" cy="11.3" r="10.2" fill={WHATSAPP_VERDE} />
      <path d="M2.4 22.3 4.5 16.2l4 3.9z" fill={WHATSAPP_VERDE} />
      {/* O fone: um gancho de traço grosso e arredondado, como na marca. */}
      <path
        d="M9.4 7.2c.5 0 .9.3 1.1.8l.8 1.9c.2.4.1.8-.3 1.1l-.6.6c.6 1.2 1.6 2.2 2.8 2.8l.6-.7c.3-.3.7-.4 1.1-.2l1.9.8c.5.2.8.6.8 1.2 0 .9-.4 1.7-1.1 2.2-.6.4-1.2.5-2 .4-2.2-.4-4.1-1.5-5.7-3.1-1.6-1.6-2.7-3.5-3-5.7-.1-.7 0-1.4.4-2 .5-.7 1.2-1.1 2.2-1.1z"
        fill="#fff"
      />
    </svg>
  );
}
