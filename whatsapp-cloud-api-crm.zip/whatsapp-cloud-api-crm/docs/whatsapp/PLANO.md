# WhatsApp no Central SJ — desenho, configuração e limites

> Canal: **WhatsApp Business Platform (Cloud API)**, a API oficial da Meta.
> Nada aqui usa QR Code, WhatsApp Web automatizado ou provedor não oficial.

---

## 1. O que muda

Antes, o Connect **redigia** a mensagem e a pessoa **enviava** — o botão abria
`https://wa.me/...` com o texto pronto e o resto acontecia fora do sistema
(`src/pages/funil/Mensagens.jsx`, `Propostas.jsx`, `OportunidadeDetalhe.jsx`,
`components/funil/ModalLinkFaturamento.jsx`). O que o Central registrava era a
*intenção* de mandar, nunca o envio, e a resposta do cliente não voltava para
lugar nenhum.

Agora o Central envia pela API e recebe pelo webhook. A conversa inteira —
ida e volta, com status de entrega — fica em `WhatsApp → Conversas`.

Os botões `wa.me` continuam existindo e não foram removidos: enquanto o número
oficial não estiver ligado, eles são o caminho que funciona. Quem migrar o
número desliga-os depois, e não no mesmo dia.

---

## 2. Peças

```
     Cliente no WhatsApp
            │  ▲
    (1) msg │  │ (4) resposta
            ▼  │
   ┌────────────────────────┐
   │  Meta — Cloud API      │
   └────────────────────────┘
            │  ▲
  (2) POST  │  │ (3) POST /{phone_number_id}/messages
   webhook  ▼  │
   ┌────────────────────────┐        ┌──────────────────────┐
   │ receberWhatsApp        │        │ enviarWhatsApp       │
   │ (público + assinatura) │        │ (portaria de sessão) │
   └────────────────────────┘        └──────────────────────┘
            │                                  ▲
            ▼                                  │
   WhatsAppConversa / WhatsAppMensagem ────────┘
            │
            ▼
   whatsappConversas  ←──  src/pages/whatsapp/Conversas.jsx
   (leitura e ações)        (caixa de entrada, consulta curta)
```

| Peça | Arquivo | Papel |
|---|---|---|
| Cliente da Cloud API | `base44/shared/whatsapp.ts` | Normalização de número, assinatura do webhook, chamadas à Graph API. Sem segredo dentro: recebe a configuração pronta |
| Webhook | `base44/functions/receberWhatsApp/entry.ts` | Handshake de verificação (GET) e recebimento de mensagens e status (POST) |
| Envio | `base44/functions/enviarWhatsApp/entry.ts` | Texto livre dentro da janela, template fora dela |
| Leitura e ações | `base44/functions/whatsappConversas/entry.ts` | Lista, thread, marcar lido, vincular cadastro, abrir ticket |
| Caixa de entrada | `src/pages/whatsapp/Conversas.jsx` | Lista à esquerda, conversa à direita — mesmo desenho do Chat Global |

As entidades são `WhatsAppConversa` (uma por número de cliente) e
`WhatsAppMensagem` (uma por mensagem). O porquê de cada escolha está nos
comentários dos próprios `.jsonc`.

---

## 3. A janela de 24 horas

É a regra que manda no desenho inteiro, e não uma configuração nossa:

- **Dentro de 24h** contadas da **última mensagem do cliente**, podemos responder
  com texto livre, mídia, o que for.
- **Fora dela**, a Meta recusa texto livre. O único caminho é um **template
  aprovado** por ela, e aquilo é cobrado como conversa nova.

Por isso `WhatsAppConversa.janelaExpiraEm` é gravado a cada mensagem recebida:
a lista mostra quais conversas ainda aceitam resposta livre sem precisar varrer
mensagens, e o compositor troca sozinho para o seletor de template quando a
janela fecha. Tentar enviar texto com a janela fechada devolve
`codigo: "janela_fechada"` — a tela explica em vez de mostrar "falhou".

Templates vivem em `TemplatesMensagem` com os campos `metaNome`, `metaIdioma`,
`metaVariaveis` e `metaStatus`. Um template sem `metaNome` serve para redigir,
não para reabrir conversa fechada.

---

## 4. Configuração (o que precisa existir antes de ligar)

> Passo a passo clicável, com os erros comuns de cada etapa:
> [`CONFIGURACAO-META.md`](CONFIGURACAO-META.md).

### 4.1 Do lado da Meta

1. **WhatsApp Business Account (WABA)** no Meta Business Manager, com a empresa
   verificada.
2. **Número dedicado.** O número passa a ser da API e **deixa de funcionar** no
   aplicativo comum do WhatsApp — inclusive no WhatsApp Business. Não use o
   número que a equipe usa hoje no celular sem antes decidir isso.
3. **App** no Meta for Developers com o produto *WhatsApp* adicionado.
4. **Token permanente**: crie um *System User* no Business Manager com acesso ao
   WABA e gere um token sem validade. O token de teste do painel expira em 24h e
   só serve para o primeiro teste.
5. **Webhook**: aponte para
   `https://seu-dominio.exemplo.com/functions/receberWhatsApp` e assine o campo
   `messages` — sem essa assinatura o webhook fica configurado e mudo.

### 4.2 Segredos no Base44

| Segredo | Onde se acha | Para quê |
|---|---|---|
| `WHATSAPP_ACCESS_TOKEN` | Token do System User | Autoriza o envio |
| `WHATSAPP_PHONE_NUMBER_ID` | Painel do WhatsApp → API Setup | Número que envia — e o único cujas mensagens o webhook aceita, quando a conta tem mais de um |
| `WHATSAPP_APP_SECRET` | App → Configurações → Básico | Confere a assinatura de cada webhook |
| `WHATSAPP_VERIFY_TOKEN` | Você inventa | Handshake de verificação do webhook |
| `WHATSAPP_WABA_ID` | Painel do WhatsApp | Opcional — leitura dos templates aprovados |
| `WHATSAPP_API_VERSION` | — | Opcional; sem ela usa `v22.0`. **Confira a versão corrente do seu app**: a Meta aposenta versões antigas |

Sem `WHATSAPP_APP_SECRET` o webhook **recusa tudo** com 503. É proposital: um
webhook que aceita corpo não assinado é uma porta para qualquer pessoa inserir
mensagem falsa na caixa de entrada do atendimento.

### 4.3 Conferindo

1. `GET` na URL do webhook com `hub.mode=subscribe`, `hub.verify_token=<o seu>`
   e `hub.challenge=teste` deve devolver `teste` em texto puro.
2. Mande uma mensagem do seu celular para o número da empresa: ela aparece em
   `WhatsApp → Conversas` em segundos.
3. Responda pela tela: a mensagem chega no celular e o status vira "entregue".

---

## 5. Segurança

- **Webhook (entrada).** Toda requisição carrega
  `X-Hub-Signature-256: sha256=<hmac>` calculado pela Meta sobre o corpo **cru**
  com o app secret. A conferência é feita antes de qualquer `JSON.parse`, com
  comparação de tempo constante. Assinatura errada → 401, nada é gravado.
- **Envio e leitura.** `enviarWhatsApp` e `whatsappConversas` têm a portaria de
  sessão do Central (`exigirUsuario`), a mesma das demais funções que falam com
  o mundo — funções do Base44 são endpoints HTTP abertos, cada uma se defende
  sozinha. As três estão classificadas em `scripts/verificarPortarias.mjs`.
- **Reenvio.** A Meta reenvia o webhook quando não recebe 200. Toda mensagem é
  gravada com o `wamid` dela e a gravação confere antes se aquele `wamid` já
  existe: reenviar não duplica.
- **Mídia.** A URL que a Meta devolve expira e exige o token. O arquivo é
  baixado no webhook e guardado no armazenamento do app; o que fica na mensagem
  é a cópia nossa.
- **Auditoria.** Todo envio entra na trilha (`registrarAuditoria`, módulo
  `integracoes`), como já acontece com e-mail de diagnóstico e envio ao CRM.

---

## 6. Custo

**A Cloud API não tem mensalidade.** A Meta hospeda a infraestrutura, e não há
provedor no meio para cobrar assinatura — o gasto é só o das mensagens que a
Meta cobra.

O modelo de cobrança MUDOU duas vezes nos últimos anos, e material antigo na
internet ainda descreve o modelo velho ("por conversa de 24h"). O que vale:

| O quê | Cobrança |
|---|---|
| Cliente escreve e a gente responde na janela de 24h (conversa de serviço) | **grátis**, sem limite |
| Template de **utilidade** enviado com a janela aberta | **grátis** |
| Template de **utilidade** com a janela fechada | cobrado, faixa mais barata |
| Template de **autenticação** (código, confirmação) | cobrado, faixa média |
| Template de **marketing** (oferta, reengajamento) | cobrado, faixa mais cara |

Desde julho de 2025 a cobrança é **por mensagem de template entregue**, e não
mais por conversa aberta. As tarifas variam por país e mudam periodicamente —
a tabela oficial por categoria está no WhatsApp Manager, em *Faturamento →
Preços*, e é ela que vale, não um número escrito aqui.

**Para o uso que este canal atende — atendimento e suporte, em que quem começa a
conversa é o cliente — o custo tende a zero.** O que gasta é reengajar quem
sumiu: aí sai um template, e a tela avisa antes de mandar.

O que o desenho faz para não gastar à toa:

- responder dentro da janela nunca é cobrado, e é o caminho padrão da tela;
- template só sai por ação explícita de alguém, com o aviso de que aquilo
  reabre (e cobra) a conversa;
- o `metadados` de cada mensagem guarda a categoria e os dados de cobrança que
  a Meta informou no status — é o que permite conferir a fatura depois.

Fora da Meta, o único custo novo é a **linha telefônica dedicada** ao número.

---

## 6.1 Quem vê o quê, e quem fala com quem

**Cada consultor alcança as conversas dos clientes de que é o responsável**
(`Cliente.responsavelUserId`); administrador alcança todas. A regra está em
`base44/shared/whatsappAcesso.ts` e é conferida no SERVIDOR, em toda ação que
recebe um `conversaId` — some da lista, recusa a leitura da thread e recusa o
envio. Conferir só na tela deixaria a conversa a um `fetch` de distância.

Duas consequências que valem estar escritas:

- **Conversa ainda sem vínculo aparece para todos.** Número novo que escreve
  pela primeira vez não casa com cadastro nenhum; se ficasse restrito, a
  mensagem não apareceria para ninguém. Assim que alguém vincula, ela passa a
  obedecer ao responsável.
- **`contato` e `agente` não têm responsável no cadastro**, então conversa presa
  a eles continua visível a todos. É um vão conhecido: fechá-lo exigiria
  inventar um dono onde o sistema não tem um. `cliente` e `prospect`, que têm,
  são conferidos.

### Onde a conversa aparece

| Lugar | O quê |
|---|---|
| Ícone na navbar, ao lado do Chat | A caixa de entrada em primeiro plano, sem sair da tela em que se está |
| `/whatsapp/conversas` | A mesma caixa de entrada em tela cheia, a um clique do painel, para quem vai passar a manhã nela |
| Ficha do cliente | Botão que abre a conversa na gaveta lateral, ao lado do botão do Teams |
| Ticket de suporte | O mesmo botão, resolvendo o telefone pelo cliente do ticket |
| Oportunidade | O mesmo botão, ao lado do `WApp` que abre o `wa.me` |

O WhatsApp **não é um módulo da barra lateral**. Ele esteve lá, entre Pós-venda
e Horas Trabalhadas, e saiu: módulo é onde se trabalha um assunto (clientes,
tickets, metas); WhatsApp é um **canal**, da mesma natureza do Chat interno, que
nunca esteve no menu justamente por isso. Canal se abre por cima do que a pessoa
está fazendo e se fecha sem tirá-la do lugar — trocar de tela e perder o
contexto para responder uma mensagem era o caminho mais longo possível para o
gesto mais frequente do dia. A permissão (`connect.whatsapp`) não mudou: ela
agora decide se o ícone existe na navbar, além de continuar protegendo a rota da
tela cheia.

A gaveta segue o padrão do `TeamsBotao`: abre por cima do que a pessoa está
fazendo e fecha sem tirá-la do lugar. Ela reaproveita a **thread inteira**, e
não uma versão resumida — quem abre daqui abre para responder, e responder
exige a janela de 24h, o seletor de template e os tiques de entrega. O que
encolhe é o espaço, não a capacidade.

---

## 6.2 O que dispara sozinho

Duas famílias, com destinos e riscos bem diferentes.

### Avisos internos (sem custo, sem risco)

O **vigia** (`whatsappVigia`, a cada 30 min) avisa pelo sininho do Central quem
tem cliente esperando resposta há mais de 30 minutos, e destaca a conversa cuja
janela de 24h está fechando — que é quando responder deixa de ser gratuito. Vai
para o responsável pelo cliente; conversa sem vínculo vai para os
administradores, que são quem consegue vincular.

Nada disso sai pelo WhatsApp de ninguém: mensagem a cada 30 minutos pela Cloud
API custaria por disparo e derrubaria a nota de qualidade do número.

### Mensagens ao cliente (custam e arriscam)

`whatsappAutomacoes` (diária) cobre pendência vencendo ou vencida e os passos de
pós-venda que o `posVendaEngine` deixou pendentes em `Communication`. O aviso de
horas contratadas sai de dentro de `checkHorasContratadasNotify`, junto do
alerta interno que já existia — é lá que o percentual é calculado, e repetir a
conta em outro lugar criaria duas verdades.

**Toda mensagem automática passa por quatro travas** (`shared/whatsappAutomacao.ts`),
e qualquer uma delas fecha o caminho sem erro:

1. canal configurado;
2. `Cliente.whatsappOptOut` desligado — nenhuma automação passa por cima dele;
3. existe template **aprovado** para aquele evento, achado pela `metaChave`
   (`pendencia_cobranca`, `posvenda_passo`, `posvenda_nps`, `horas_percentual`);
4. aquele fato ainda não foi avisado — automação que repete vira denúncia.

Na thread, mensagem automática aparece com autor `Automação · <origem>`: quem lê
precisa distinguir o que um atendente escreveu do que o sistema disparou.

---

## 6.3 Envio em lote (campanhas)

Marketing e aviso em massa, disparados de dentro do Central, com a resposta do
cliente voltando para a caixa de entrada — que é o que separa isto de um
disparador externo.

### O limite que define o desenho

A Meta limita **destinatários únicos por 24 horas**, por degraus: **250 →
1.000 → 10.000 → 100.000**. O degrau sobe conforme volume e qualidade se
sustentam, e **desce** quando a nota de qualidade cai. Número recém-registrado
começa no primeiro.

Estourar o teto não perde só o excedente: a rajada de recusas derruba a nota, e
com ela o degrau. Por isso **campanha aqui é fila, não disparo**. O público
inteiro fica gravado e o `campanhaWhatsAppDisparo` (cron de 15 min) entrega o
que cabe no teto do dia. Uma campanha de 2.000 levar uma semana é o desenho
funcionando, não lentidão a corrigir.

### Quem faz o quê

| Papel | O que pode |
|---|---|
| **Consultor** | Cria, escolhe o template, acrescenta gente, submete |
| **Administrador** | Aprova ou recusa — a única ação restrita |

A aprovação grava **quem** aprovou, e o disparo confere `aprovadoPorUserId`, não
só o status: status é campo que qualquer caminho futuro pode escrever;
assinatura não se põe por acidente.

### Como o público é escolhido

Pelas telas de **Clientes** e **Prospects**, com os filtros que já existem lá:
caixas de seleção, e o botão "Enviar em lote" na barra que aparece. A tela de
campanhas cuida do conteúdo e da aprovação, não do público — duplicar os
filtros manteria dois lugares em pé fazendo a mesma coisa.

### As travas

1. **Opt-out**, conferido na montagem **e de novo na hora do envio** — entre
   montar e mandar passam dias, e quem escreveu "SAIR" ontem não pode receber a
   leva de hoje. Vale para `Cliente` e para `Prospect`.
2. **Deduplicação pelo telefone**, não pelo id do cadastro: dois cadastros com o
   mesmo número são uma pessoa só do lado de lá.
3. **Template aprovado**, sempre. Campanha é fora da janela de 24h por
   definição, e ali a Meta não aceita outra coisa.
4. **Variável vazia pula a linha** antes de tentar: a Meta recusaria o template
   inteiro, e recusa em série é o que derruba a nota.
5. **Teto diário por campanha**, com padrão conservador — o atendimento humano
   e as automações dividem o mesmo teto do número.
6. **Tentativas limitadas** (3): um número que falha sempre não é arrastado por
   todas as rodadas gastando o teto de quem receberia.

**Pulado não é falha.** A tela conta os dois separados de propósito: "21
pediram para sair" é informação de campanha; "3 a Meta recusou" é problema.

Na thread, campanha aparece com autor `Campanha · <nome>` — quem abrir a
conversa daqui a um mês precisa distinguir isto de uma mensagem do atendente.

---

## 7. O que ficou de fora desta entrega

Registrado para não virar surpresa:

- **Os templates aprovados na Meta.** As automações estão prontas e desligadas
  por falta deles: sem um template com a `metaChave` do evento, cada rodada
  registra "sem template aprovado" e não manda nada. Criar e aprovar é grátis
  (§6) — é o passo que falta para ligar de fato. Os quatro textos prontos e o
  cadastro dos dois lados estão em [`TEMPLATES.md`](TEMPLATES.md).
- **Distribuição de atendimento** (fila, rodízio entre atendentes). Hoje a
  conversa tem um `responsavelUserId` que alguém assume à mão, e o alcance é
  decidido pelo responsável do CLIENTE, não por rodízio.
- **`RegraAlerta` com canal `whatsapp`.** O canal já existe no enum, mas o motor
  de regras ainda não o consome: hoje quem fala com o cliente são as três
  automações descritas em §6.2.
- **Substituir os botões `wa.me`** pelo envio pela API — proposital, ver §1.
- **Leitura da lista de templates direto da Meta.** Hoje os templates são
  cadastrados em `TemplatesMensagem` com o nome que a Meta aprovou. O
  `WHATSAPP_WABA_ID` está reservado para isso.
- **Respostas com botões e listas interativas.** Chegam e são exibidas; o envio
  é só texto, mídia e template.
