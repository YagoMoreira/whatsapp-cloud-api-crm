# Ligar o canal — passo a passo na Meta

> Roteiro de configuração do WhatsApp Business Platform (Cloud API) para o
> Central SJ. O desenho do canal está em `PLANO.md`; aqui é só o que precisa
> ser feito, na ordem, e o que costuma dar errado em cada passo.

Tempo real: **de 3 a 10 dias**, quase todo ele esperando a verificação da
empresa e a aprovação dos templates. A parte técnica leva uma tarde.

---

## Antes de começar: a decisão do número

O número que entrar na Cloud API **deixa de funcionar no aplicativo** — no
WhatsApp comum e no WhatsApp Business. Não existe usar os dois ao mesmo tempo.

Então: **use uma linha nova**, não o número que a equipe já usa no celular. Se
o número atual já é o divulgado aos clientes e precisa mesmo migrar, apague a
conta dele no aplicativo (*Configurações → Conta → Apagar minha conta*) antes de
cadastrá-lo — senão o cadastro falha.

Requisitos da linha: precisa receber SMS ou ligação para a verificação, e não
pode ser um número virtual descartável (a Meta recusa boa parte deles).

### Se já existe um número na API, atendido por outra ferramenta

É o caso de quem já usa Voxuy, Take, Zenvia, Twilio ou similar. Três caminhos,
em ordem de recomendação:

**A. Número novo, só para o Central** — o mais simples e o único sem risco de
uma ferramenta atropelar a outra. A conta Business e a verificação da empresa já
existem, então basta acrescentar o número à mesma WABA (passo 3). As duas
ferramentas seguem vivas, cada uma no seu número.

**B. Migrar o número da outra ferramenta para o Central** — quando a intenção é
substituir a ferramenta antiga. O número, os templates aprovados e o histórico
de qualidade pertencem à **WABA**, não ao app: trocar qual app a atende não
apaga nada disso. Na prática é remover a assinatura do app antigo e assinar o do
Central (passo 7). Antes de fazer, confirme **em qual conta o número está**:
se ele foi cadastrado dentro da conta Business da *própria ferramenta* — o que é
comum em contratação por "onboarding embutido" —, quem tem de liberar ou migrar
é ela, não você. Isso se vê em *Configurações do negócio → Contas → Contas do
WhatsApp Business*: se a WABA aparece aí como sua, o número é seu.

**C. Os dois na mesma linha, ao mesmo tempo** — tecnicamente uma WABA aceita
mais de um app assinando os webhooks, e aí as duas ferramentas recebem cópia de
cada mensagem. **Não recomendo.** A conversa apareceria em dois lugares, dois
robôs poderiam responder ao mesmo cliente, a janela de 24h é uma só e não há
como saber qual das ferramentas já respondeu. Só faz sentido como transição
curta, com a ferramenta antiga em modo de leitura.

> **Atenção ao webhook em conta compartilhada.** A assinatura é por WABA, não por
> número: com dois números na mesma conta, o Central recebe as mensagens dos
> dois. É por isso que `receberWhatsApp` descarta o que não vier do
> `WHATSAPP_PHONE_NUMBER_ID` configurado — sem esse filtro ele abriria conversas
> do outro atendimento e responderia pelo número errado. Configure a variável
> **antes** de assinar o webhook.

---

## 1. Conta Business e verificação da empresa

> Já tem a empresa verificada? Pule para o passo 2.

1. Entre no [Meta Business Manager](https://business.facebook.com) e crie (ou
   use) a conta da empresa.
2. Vá em **Configurações do negócio → Central de segurança → Verificação da
   empresa** e envie os documentos: CNPJ, comprovante de endereço em nome da
   empresa e um meio de contato verificável (telefone fixo ou e-mail no domínio
   da empresa).

**Dá para começar sem a verificação**, com um limite baixo (a Meta libera poucas
conversas iniciadas por dia). Para operar de verdade, a verificação precisa sair
— e ela leva de 1 a 5 dias úteis. Comece por ela, e faça o resto enquanto espera.

---

## 2. App e produto WhatsApp

> A página de **produtos/documentação** do developers.facebook.com (aquela com
> os cartões Marketing API, Meta Pixel, Conversions API…) é catálogo de leitura.
> Não se cria nada por ela — o caminho é **Meus apps**, no topo à direita.

1. Em [developers.facebook.com](https://developers.facebook.com), topo à direita
   → **Meus apps** → **Criar app**.
2. **Detalhes do app**:
   - *Nome*: algo reconhecível, ex.: `Central SJ — WhatsApp`. O cliente não vê
     este nome (o que ele vê é o nome de exibição do número, no passo 3).
   - *Portfólio empresarial*: **selecione o portfólio da empresa**. É o passo que
     amarra o app à conta que já tem a WABA e a verificação — deixar em branco
     cria um app solto, e depois é preciso refazer o vínculo.
3. **Casos de uso**: escolha **Outro** (se houver um caso de uso de WhatsApp
   listado, ele também serve) → *Avançar*.
4. **Tipo de app**: **Empresa** → *Avançar* → *Criar app* (pede a senha da conta).
5. No painel do app: **Adicionar produto** → localize **WhatsApp** → *Configurar*.

Feito isso, em **WhatsApp → Configuração da API**, o app pergunta com qual conta
vai falar. **Escolha o portfólio e a conta do WhatsApp Business que já existem** —
se deixar criar uma conta de teste, o número e os templates que você já tem não
estarão nela. A conta de teste só vale para experimentar: ela manda mensagem
para no máximo 5 números que você cadastrar à mão.

---

## 3. Cadastrar o número de verdade

Em **WhatsApp → Configuração da API**:

1. **Adicionar número de telefone**.
2. Preencha o **nome de exibição** — é o que o cliente vê no topo da conversa.
   A Meta aprova esse nome, e recusa nome que não tenha relação com a empresa.
3. Escolha o número e confirme o código: **celular recebe por SMS; fixo, só por
   ligação** (a Meta lê o código em voz alta, então tenha alguém na linha).
4. O número precisa estar **fora do aplicativo** antes disto — ver "a decisão do
   número", no começo. Número ainda ativo no WhatsApp comum ou Business faz o
   cadastro falhar sem dizer o motivo real.

Anote, nessa mesma tela:

- **`Identificação do número de telefone`** (phone number ID) → vai em
  `WHATSAPP_PHONE_NUMBER_ID`
- **`Identificação da conta do WhatsApp Business`** (WABA ID) → vai em
  `WHATSAPP_WABA_ID`

> São dois números longos e parecidos. Trocar um pelo outro é o erro mais comum
> daqui: o envio responde "objeto inexistente" sem dizer qual.

**Confira de qual WABA esse número é.** Um portfólio empresarial costuma ter
mais de uma conta do WhatsApp Business — e o app pode ter criado mais uma
durante a configuração, às vezes com nome parecido com o das outras. Nome não
serve para distinguir; ID serve.

A conferência que não erra: em *Configurações do negócio → Contas → Contas do
WhatsApp Business*, abra cada conta e olhe a aba **Phone numbers**. **A conta
certa é a que LISTA o seu número** — e o ID dela é o que vale, tanto para
atribuir ao usuário do sistema quanto para o `WHATSAPP_WABA_ID`. Comparar com o
ID que a Configuração da API mostra ao lado do número é a segunda prova.

Isso importa por dois motivos, nos dois sentidos:

- **Templates seguem a WABA.** Se os templates aprovados estão em outra conta,
  eles **não** valem para este número: é preciso criá-los aqui (sem custo, só o
  tempo da aprovação).
- **Webhook também segue a WABA.** Se o número de outra ferramenta está em conta
  separada, as mensagens dela nunca chegam a este app — separação limpa, sem
  depender de filtro nenhum.

### Registrar o número (verificar não é registrar)

Adicionar e verificar por SMS **não** põe o número na Cloud API. Falta o
**registro**, e enquanto ele não acontece o status fica **Pendente** e o número
simplesmente **não existe no WhatsApp**: quem o procura no celular vê "convidar
para o WhatsApp", e nenhuma mensagem pode chegar.

O registro é a definição do **PIN de verificação em duas etapas** — e aqui está
a armadilha: **o botão desse PIN no WhatsApp Manager fica acinzentado**. Ele
serve para *trocar* o PIN de um número já conectado, não para criar o primeiro.
Pelo painel não há saída.

**Registro só acontece por API.** No Explorador da Graph API, com
`whatsapp_business_management` e `whatsapp_business_messaging`:

```
POST  <PHONE_NUMBER_ID>/register
```

Dois parâmetros **separados** (o erro clássico é colar os dois numa chave só, e
a Meta responde "`messaging_product` is required"):

| Chave | Valor |
|---|---|
| `messaging_product` | `whatsapp` |
| `pin` | seis dígitos que você escolhe |

`{"success": true}` → o status vira **Conectado** e o número passa a existir no
WhatsApp em segundos.

> **Anote o PIN.** Ele volta a ser pedido em qualquer remanejamento futuro do
> número, e recuperá-lo é suporte da Meta.

**Nome de exibição "Em análise" não bloqueia nada.** Nome e registro são
coisas separadas: o número funciona com a análise pendente, só aparece com o
número cru até o nome ser aprovado.

### Remover um número de uma conta (para recadastrar em outra)

Quando não há saída senão mover o número — a conta atual vai ser desativada, ou
o número precisa ficar junto de outros da mesma operação —, o caminho é remover
e cadastrar de novo:

1. **Gerenciador do WhatsApp** (`business.facebook.com/wa/manage`) → selecione no
   alto **a conta que tem o número** → *Configurações da conta* → **Números de
   telefone**.
2. No número, abra o menu **"..."** → **Excluir número de telefone** → confirme.
   Pelo Business Manager dá no mesmo: *Contas → Contas do WhatsApp* → a conta →
   aba **Phone numbers** → remover.
3. Cadastre o número na conta de destino pelo fluxo do passo 3 acima.

O que some junto, e por isso precisa ser refeito:

- **O `phone_number_id` deixa de existir.** O número recadastrado ganha um ID
  novo, e é o novo que vai em `WHATSAPP_PHONE_NUMBER_ID` — o antigo passa a
  responder "objeto inexistente".
- **Nome de exibição volta para análise** e a verificação por SMS ou ligação é
  refeita.
- **Qualidade e limite recomeçam** no degrau mais baixo: são por número dentro
  da conta, não seguem a linha.
- **PIN de verificação em duas etapas**: se ele foi definido, é pedido no
  recadastro. Sem ele, a Meta impõe espera de vários dias — então recupere o PIN
  ANTES de excluir, não depois.

Fazer isso com o número já em produção é derrubar o atendimento no intervalo.
Com número recém-criado, o custo é só o da aprovação do nome.

---

## 3.1 Forma de pagamento e modo do app

Dois bloqueios que não aparecem como erro de código — aparecem como mensagem que
não sai.

**Forma de pagamento na WABA.** Sem ela, a conta recebe e responde dentro da
janela de 24h normalmente, mas **não inicia** conversa: todo template é recusado.
Como reabrir contato vencido é justamente o que exige template, o canal fica pela
metade. Cadastre em *Gerenciador do WhatsApp → Cobrança*, na conta **que atende o
número** (o alerta do painel costuma citar várias contas do portfólio; a que
importa é a do seu número).

> **Pagou na conta errada?** É por conta, não por portfólio — mas a saída é
> cadastrar o mesmo cartão também na conta certa, e não mover o número para onde
> o pagamento está. A Meta não tem botão de "mover número entre contas": o
> caminho self-service é remover o número de uma e registrá-lo na outra, com
> nome de exibição voltando para análise e verificação refeita. Trocar dois
> minutos de cadastro de cartão por uma nova rodada de aprovação é um mau
> negócio — e piora quanto mais o número tiver histórico.

**Modo do aplicativo: de "desenvolvimento" para "Ao vivo".** O seletor fica no
topo do painel do app. Antes de a operação começar, vire a chave — em
desenvolvimento a entrega de webhooks para conversas reais não é garantida, e o
sintoma é o pior possível: envio funcionando e nenhuma mensagem de cliente
chegando.

**URL da Política de Privacidade** (*Configurações do app → Básico*) é a
condição para virar essa chave: a Meta não coloca o app "Ao vivo" com o campo
vazio. A página precisa ser pública, em HTTPS e sem login — a Meta a abre para
conferir, e link que exige autenticação ou devolve 404 é recusado.

O Central serve essa página por conta própria, em rota pública:

| Campo do app | URL |
|---|---|
| URL da Política de Privacidade | `https://seu-dominio.exemplo.com/privacidade` |
| Instruções de exclusão de dados | `https://seu-dominio.exemplo.com/exclusao-de-dados` |
| URL dos Termos de Serviço | a do site institucional, quando houver |

O conteúdo está em `src/pages/publico/Privacidade.jsx`, e o cabeçalho do arquivo
diz o que precisa ser preenchido antes de publicar (CNPJ e a caixa de e-mail que
recebe pedidos de titular) — a caixa precisa existir e ser lida, porque é o
endereço que a política promete.

O campo de exclusão de dados não bloqueia o canal, mas é por ele que uma pessoa
pede que os dados dela saiam do sistema. Depois de passar a guardar conversa de
cliente, ter esse caminho escrito é o que a LGPD espera.

**Alertas com análise pendente** (aviso no topo da Configuração da API): abra
*Ir para o Gerenciador do WhatsApp* e resolva o que estiver lá antes de testar —
em geral é nome de exibição em análise ou verificação de número inacabada.

---

## 4. Token permanente

O botão **Gerar token de acesso**, na Configuração da API, emite token
**temporário — 24 horas**. Serve para o primeiro teste e nada além: configurar o
Central com ele faz o canal parar sozinho no dia seguinte. O definitivo sai
assim:

1. **Business Manager → Configurações do negócio → Usuários → Usuários do
   sistema → Adicionar**.
2. Nome: `central-sj-whatsapp`. Função: **Administrador**.
3. **Atribua os ativos ANTES de gerar o token.** O token nasce com o alcance que
   o usuário do sistema tem naquele instante: gerado antes, ele sai válido e
   inútil — autentica, mas não enxerga número nem conta, e o erro que volta fala
   em "objeto inexistente", não em falta de permissão.

   São dois ativos, e é comum a interface pedir que se faça pelo lado deles:
   - *Contas → Apps* → o app do WhatsApp → **Adicionar pessoas** → o usuário do
     sistema → **controle total**;
   - *Contas → Contas do WhatsApp* → a WABA **do seu número** → **Adicionar
     pessoas** → o mesmo usuário → **controle total**.

   Pela aba **Ativos atribuídos** do próprio usuário do sistema dá no mesmo. O
   que não vale é pular: a aba *Apps instalados* vazia, com o aviso "nenhum app
   instalado", é exatamente esse estado.
4. **Gerar token** → escolha o app → marque as permissões:
   - `whatsapp_business_messaging` (enviar)
   - `whatsapp_business_management` (ler templates e configuração)
5. Validade: **Nunca**.

> **"Nenhuma permissão disponível — atribua uma função do app ao usuário do
> sistema"?** Ter o app como *ativo atribuído* e ter *função no app* são duas
> coisas, e a segunda é a que a Meta consulta para montar essa lista. Confira
> nesta ordem:
>
> 1. *Contas → Apps* → o app → o usuário do sistema aparece com **Gerenciar app
>    / controle total**? Só "testar" ou "desenvolver" não serve.
> 2. No painel do app (developers.facebook.com) → **Funções do app → Funções**:
>    o usuário do sistema está lá como **Administrador**? Quando não está,
>    adicione por ali — é o que costuma destravar.
> 3. *Configurações do app → Básico*: o **portfólio empresarial** é o mesmo em
>    que o usuário do sistema foi criado? App em portfólio diferente não recebe
>    função nenhuma daquele negócio, e a lista fica vazia sem explicar por quê.

O token aparece **uma única vez**. Copie na hora → `WHATSAPP_ACCESS_TOKEN`.

> Se o token for perdido antes de ser colado no Base44, não há como recuperá-lo:
> gere outro. **Anular tokens** revoga todos os daquele usuário de uma vez — o
> que derruba o canal na hora, e por isso não é o botão para "limpar" um token
> perdido enquanto o antigo ainda está em uso.

---

## 5. App Secret e token de verificação

- **App Secret**: no app, **Configurações → Básico → Chave secreta do app →
  Mostrar** → `WHATSAPP_APP_SECRET`.
  É com ele que a Meta assina cada webhook, e é o que impede alguém de plantar
  mensagem falsa na caixa de entrada. Sem ele, o Central recusa tudo.

  > **Ele aparece em texto puro na tela** — e é por isso que escapa em print,
  > compartilhamento de tela e e-mail com mais facilidade que qualquer outro
  > segredo daqui. Se isso acontecer, use **Redefinir** ao lado do campo.
  >
  > A ORDEM IMPORTA: assim que a chave é redefinida, a Meta passa a assinar os
  > webhooks com a nova, e o Central — que confere a assinatura antes de
  > qualquer coisa — recusa **tudo** com 401 até `WHATSAPP_APP_SECRET` ser
  > atualizado e o app republicado. Redefina e atualize na mesma sentada, de
  > preferência fora do horário de atendimento: no vão entre as duas coisas,
  > mensagem de cliente não entra.
- **Token de verificação**: você inventa. Uma frase longa e aleatória serve —
  ela só é usada no aperto de mão do webhook → `WHATSAPP_VERIFY_TOKEN`.

---

## 6. Cadastrar os segredos no Base44

Antes de configurar o webhook, os segredos precisam estar no app — o aperto de
mão falha se o Central não souber o token de verificação.

No painel do Base44, nas variáveis de ambiente do app:

| Nome | Valor |
|---|---|
| `WHATSAPP_ACCESS_TOKEN` | token do usuário do sistema (passo 4) |
| `WHATSAPP_PHONE_NUMBER_ID` | identificação do número (passo 3) |
| `WHATSAPP_APP_SECRET` | chave secreta do app (passo 5) |
| `WHATSAPP_VERIFY_TOKEN` | a frase que você inventou (passo 5) |
| `WHATSAPP_WABA_ID` | identificação da WABA (passo 3) — opcional hoje |
| `WHATSAPP_API_VERSION` | opcional; a versão da Graph API que o app usa, ex.: `v22.0` |

Publique o app depois de cadastrar, para as funções subirem com os segredos.

---

## 7. Webhook

Em **WhatsApp → Configuração → Webhook → Editar**:

- **URL de callback**: `https://seu-dominio.exemplo.com/functions/receberWhatsApp`
- **Token de verificação**: o mesmo do `WHATSAPP_VERIFY_TOKEN`

Clique em **Verificar e salvar**. A Meta faz um GET na hora; se o token bater, a
tela aceita. Se der erro, é quase sempre um destes três: o app ainda não foi
publicado com o segredo, o token tem espaço sobrando, ou a URL está errada.

Depois de salvar, **Gerenciar** → assine o campo **`messages`**. Sem essa
assinatura o webhook fica configurado e mudo — nenhuma mensagem chega.

### 7.1 Inscrever a CONTA no app (o passo que o painel não pede)

Assinar `messages` diz ao app *o que* escutar. Falta dizer à **conta do
WhatsApp** que ela fala com esse app — são duas ligações diferentes, e o painel
não menciona a segunda.

Quem entra pelo cadastro embutido ganha essa ligação de graça. Quem cadastra o
número à mão, **não** — e o sintoma é cruel: webhook verde, `messages`
assinado, e nenhuma mensagem chegando. Nada no painel indica o que falta.

Confira no **Explorador da Graph API**
(`developers.facebook.com/tools/explorer`), com a permissão
`whatsapp_business_management`:

```
GET  <WABA_ID>/subscribed_apps
```

- Lista vazia (`{"data": []}`) → é isto. Corrija com:

```
POST <WABA_ID>/subscribed_apps      (sem parâmetros)
```

Esperado: `{"success": true}`. A primeira mensagem chega logo depois.

### 7.2 `phone_number_id` e ID da WABA não são a mesma coisa

Os dois são numéricos, do mesmo tamanho, e aparecem em telas vizinhas. Trocar
um pelo outro é o erro mais fácil desta configuração inteira — e o mais caro
de achar, porque **falha em silêncio**: `receberWhatsApp` compara o
`phone_number_id` de cada mensagem com o configurado, não bate nunca, descarta
tudo como "de outro número" e devolve **200** para a Meta. Log verde, caixa de
entrada vazia, nenhum erro em lugar nenhum.

| | O que é | Onde aparece |
|---|---|---|
| **WABA ID** | A **conta**. Contém vários números | O `asset_id=` na URL do WhatsApp Manager |
| **`phone_number_id`** | **Um número** dentro dela | Configuração da API, no seletor "De" |

Em vez de confiar na tela, pergunte à API — ela responde os dois de uma vez:

```
GET  <WABA_ID>/phone_numbers?fields=id,display_phone_number,verified_name,status
```

Se vier uma **lista de números**, o id que você usou é o da WABA, e o `id` de
cada item é o `phone_number_id` correspondente. É o segundo que vai no
`WHATSAPP_PHONE_NUMBER_ID`.

> De quebra, essa chamada devolve o `status` de cada número direto da fonte,
> sem depender do que o painel mostra.

---

## 8. Templates

Só eles reabrem conversa parada há mais de 24h.

> Os quatro templates que as **automações** usam já vêm escritos, com exemplos e
> passo a passo do cadastro: [`TEMPLATES.md`](TEMPLATES.md). Esta seção é a
> regra geral, que vale para qualquer template.

**Criar e aprovar template não custa nada.** Não existe cobrança por template,
nem por quantos você tem: a Meta cobra pela mensagem entregue, e só nas
categorias cobradas (ver §6 do `PLANO.md`). O custo de um template é o tempo da
aprovação.

**Templates pertencem à WABA, não ao número.** Então, num número novo
acrescentado à conta que já existe, **os templates já aprovados valem na hora** —
nada a recriar, nada a reaprovar. Se a outra ferramenta cadastrou os templates
dela dentro da WABA *dela*, aí não: os dela ficam lá, e os seus nascem na sua
conta (de novo, sem custo).

Isso vale também no sentido inverso: se um dia o número da outra ferramenta
migrar para o Central, os templates aprovados dele continuam de pé — eles são da
conta, e não de quem a atende.

Para reaproveitar um template que já existe, não há passo na Meta: veja o nome
exato em **WhatsApp Manager → Modelos de mensagem** e cadastre-o no Central como
descrito no fim desta seção.

Para criar um novo:

1. **WhatsApp Manager → Modelos de mensagem → Criar modelo**.
2. Categoria: **Utilidade** para retomada de atendimento (mais barata e aprovada
   mais fácil); **Marketing** só para oferta de verdade.
3. Escreva o corpo usando `{{1}}`, `{{2}}` para as partes variáveis, e dê
   exemplos de preenchimento — template sem exemplo é reprovado.
4. Aprovação leva de minutos a algumas horas.

Depois de aprovado, cadastre-o no Central em **Templates de Mensagem** com:

- `tipo`: `whatsapp`
- `metaNome`: **exatamente** o nome aprovado (ex.: `retomada_atendimento`)
- `metaIdioma`: o código do idioma (ex.: `pt_BR`)
- `metaVariaveis`: o rótulo de cada `{{n}}`, na ordem — é o que a tela pede ao
  atendente na hora de disparar
- `metaStatus`: `aprovado`

Sem `metaNome`, o template continua servindo para redigir dentro da janela, mas
não aparece na lista de reabertura.

> **O que é por número, e não pela conta:** o limite de conversas iniciadas por
> dia e a nota de qualidade. Um número novo começa no degrau mais baixo e sobe
> conforme usa bem — mesmo numa empresa já verificada e com outro número maduro
> na mesma conta. Para atendimento isso quase não pesa: o limite conta o que a
> empresa inicia, e responder quem escreveu não entra nele.

---

## 9. Conferir que está de pé

1. **Aperto de mão** — no navegador:
   `https://seu-dominio.exemplo.com/functions/receberWhatsApp?hub.mode=subscribe&hub.verify_token=SEU_TOKEN&hub.challenge=teste`
   Deve aparecer a palavra `teste` na tela, e nada mais.
2. **Recebimento** — mande uma mensagem do seu celular para o número da
   empresa. Em segundos ela aparece em **WhatsApp → Conversas**, com a pastilha
   verde da janela de 24h.
3. **Envio** — responda pela tela. A mensagem chega no seu celular e o tique
   fica duplo quando entregue.
4. **Template** — só dá para testar de verdade com uma conversa vencida; para
   não esperar 24h, use um número que nunca escreveu para a empresa: a conversa
   nasce fechada e a tela já abre no seletor de template.

---

## Quando algo falha

| Sintoma | Causa quase sempre |
|---|---|
| "Nenhuma permissão disponível" ao gerar token | Usuário do sistema sem **função no app** — ativo atribuído não basta (ver §4) |
| Webhook não verifica | App não publicado com o segredo, ou token com espaço sobrando |
| Verifica mas não chega mensagem | Campo `messages` não assinado no webhook |
| Envio responde "objeto inexistente" | `WHATSAPP_PHONE_NUMBER_ID` trocado pelo WABA ID |
| Envio responde erro de permissão | Token de 24h expirado, ou faltou `whatsapp_business_messaging` |
| Mensagem recusada com janela aberta | Conta com limite baixo por falta de verificação da empresa |
| Template recusado no envio | Nome em `metaNome` diferente do aprovado, ou idioma errado |

Toda tentativa recusada fica gravada na conversa com o código e a descrição que
a Meta devolveu — é por ali que se descobre qual dos casos acima é.
