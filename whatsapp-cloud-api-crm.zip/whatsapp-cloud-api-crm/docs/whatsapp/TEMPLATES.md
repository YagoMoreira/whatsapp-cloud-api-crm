# Os quatro templates das automações

> Texto pronto para colar no WhatsApp Manager e o passo a passo do cadastro,
> dos dois lados: na Meta e no Central. Enquanto não existirem, as automações
> rodam, registram "sem template aprovado" e **não mandam nada** — que é o
> estado seguro, não um defeito.

Criar e aprovar template **não custa nada** (§6 do `PLANO.md`). O que custa é a
mensagem entregue, e só nas categorias cobradas.

---

## Antes de escrever: as regras que fazem a Meta recusar

Quatro delas derrubam a maioria das reprovações, e as quatro estão respeitadas
nos textos abaixo:

1. **O corpo não pode começar nem terminar com variável.** `{{1}}, sua pendência`
   é recusado; `Sua pendência {{1}} vence hoje.` passa.
2. **Duas variáveis não podem ficar coladas.** `{{1}} {{2}}` precisa de palavra
   entre elas.
3. **Todo exemplo é obrigatório.** A Meta aprova lendo o texto COM os exemplos
   preenchidos — sem eles, reprova sem ler.
4. **Categoria importa.** Os quatro são **Utilidade**: falam de algo que já
   existe entre a empresa e aquele cliente (uma pendência dele, o
   acompanhamento dele, as horas dele). Marcar como Marketing encareceria e
   atrairia revisão mais dura.

E uma regra nossa, não da Meta: **todos terminam com a saída.** O rodapé
"responda SAIR" é promessa de verdade — `receberWhatsApp` reconhece *sair*,
*parar*, *pare*, *stop*, *descadastrar* e *cancelar*, liga o
`Cliente.whatsappOptOut`, confirma por escrito e nenhuma automação passa por
cima depois. Prometer descadastro que não funciona é o caminho mais curto para a
denúncia que derruba o número.

---

## 1. `pendencia_cobranca`

Cobrança de pendência vencendo (até 2 dias) ou já vencida.

- **Nome:** `pendencia_cobranca`
- **Categoria:** Utilidade
- **Idioma:** Português (BR) — `pt_BR`

**Cabeçalho** (tipo Texto):

```
Lembrete de pendência
```

**Corpo:**

```
Olá! Passando para lembrar de uma pendência do seu atendimento com o Shopping Jurídico.

Pendência: {{1}}
Prazo: {{2}}

Se já resolveu, pode ignorar esta mensagem. Qualquer dúvida, é só responder por aqui.
```

**Rodapé:**

```
Responda SAIR para não receber estes avisos.
```

**Exemplos a preencher no formulário:**

| Variável | Exemplo |
|---|---|
| `{{1}}` | `Envio do contrato assinado` |
| `{{2}}` | `vence hoje` |

> **`{{2}}` já vem como frase pronta**, montada pelo Central:
> `vence hoje`, `vence em 2 dia(s)` ou `venceu há 3 dia(s)`. Por isso a linha é
> "Prazo: {{2}}" e não "Prazo: {{2}} dias" — a palavra "dias" já está lá dentro,
> e repeti-la escreveria "venceu há 3 dia(s) dias".

---

## 2. `posvenda_passo`

Passo da jornada de pós-venda que o motor deixou pendente.

- **Nome:** `posvenda_passo`
- **Categoria:** Utilidade
- **Idioma:** `pt_BR`

**Cabeçalho** (tipo Texto):

```
Atualização do seu acompanhamento
```

**Corpo:**

```
Olá! Temos uma novidade no seu acompanhamento com o Shopping Jurídico.

{{1}}

Se quiser falar sobre isso, é só responder por aqui que a gente continua no WhatsApp.
```

**Rodapé:**

```
Responda SAIR para não receber estes avisos.
```

**Exemplo:**

| Variável | Exemplo |
|---|---|
| `{{1}}` | `Chegamos à etapa de configuração do seu ambiente. Nas próximas semanas vamos alinhar os acessos da equipe.` |

> **`{{1}}` carrega o texto inteiro do passo**, que vem do `conteudo` da
> `Communication`. Por isso o exemplo precisa ser uma frase real e completa: um
> exemplo curto como "etapa 3" faz a Meta achar que o template é um molde vazio
> e reprovar.

---

## 3. `posvenda_nps`

Pedido de avaliação (NPS) da jornada de pós-venda.

- **Nome:** `posvenda_nps`
- **Categoria:** Utilidade
- **Idioma:** `pt_BR`

**Cabeçalho** (tipo Texto):

```
Sua opinião sobre o atendimento
```

**Corpo:**

```
Olá! Queremos saber como está sendo a sua experiência com o Shopping Jurídico.

{{1}}

Sua resposta leva menos de um minuto e ajuda a melhorar o nosso atendimento.
```

**Rodapé:**

```
Responda SAIR para não receber estes avisos.
```

**Exemplo:**

| Variável | Exemplo |
|---|---|
| `{{1}}` | `De 0 a 10, o quanto você recomendaria o nosso trabalho para outro escritório?` |

> **Atenção à categoria.** Pesquisa de satisfação fica na fronteira entre
> Utilidade e Marketing. O texto acima se sustenta como Utilidade porque fala do
> atendimento que aquele cliente já tem. Se a Meta reprovar como Marketing,
> **não reescreva para insistir**: reenvie na categoria Marketing e aceite o
> custo maior — insistir em recategorizar é o que trava a conta.

---

## 4. `horas_percentual`

Aviso de percentual das horas contratadas atingido.

- **Nome:** `horas_percentual`
- **Categoria:** Utilidade
- **Idioma:** `pt_BR`

**Cabeçalho** (tipo Texto):

```
Aviso do seu pacote de horas
```

**Corpo:**

```
Olá! Um aviso sobre o seu pacote de horas no Shopping Jurídico.

O uso atingiu {{1}} do total de {{2}} horas contratadas.

Se quiser ver o detalhamento ou falar sobre a contratação de mais horas, é só responder por aqui.
```

**Rodapé:**

```
Responda SAIR para não receber estes avisos.
```

**Exemplos:**

| Variável | Exemplo |
|---|---|
| `{{1}}` | `80%` |
| `{{2}}` | `40` |

> **`{{1}}` já vem com o símbolo de porcentagem** e `{{2}}` vem só o número —
> por isso a frase tem "horas" escrito por fora. Trocar a ordem das duas manda
> "atingiu 40 do total de 80% horas".

---

## Passo a passo — na Meta

**1.** Abra o **WhatsApp Manager** (`business.facebook.com/wa/manage`) e, no
alto, **selecione a conta do WhatsApp Business que atende o número do Central**.
Template pertence à conta: criado na conta errada, ele não existe para o seu
número (§3 do `CONFIGURACAO-META.md`).

**2.** **Modelos de mensagem → Criar modelo.**

**3.** Preencha:
- **Categoria:** Utilidade
- **Nome:** exatamente como está aqui (`pendencia_cobranca`, `posvenda_passo`,
  `posvenda_nps`, `horas_percentual`) — minúsculas e sublinhado, sem acento
- **Idioma:** Português (BR)

**4.** Cole o **cabeçalho**, o **corpo** e o **rodapé**. **Não use botões** — aqui
eles não acrescentam nada e dão mais superfície para a revisão recusar.

Os quatro cabeçalhos são do tipo **Texto** e **sem variável**, de propósito: um
cabeçalho estático não pede exemplo, então ele nomeia o assunto da mensagem sem
acrescentar risco de reprovação. O limite é de **60 caracteres**; os quatro
cabem com folga. Cabeçalho com variável passaria a exigir exemplo próprio e a
reprovar junto com ele — se um dia alguém quiser um, é uma decisão nova, não uma
edição.

**5.** Preencha os **exemplos** de cada variável com os valores da tabela. É o
passo mais pulado e o que mais reprova.

**6.** **Enviar.** A aprovação leva de minutos a algumas horas.

**7.** Repita para os quatro.

---

## Passo a passo — no Central

Depois de **aprovado** (e só depois), cadastre cada um em **Templates de
Mensagem**:

| Campo | Valor |
|---|---|
| `tipo` | `whatsapp` |
| `titulo` | um nome legível, ex.: `Cobrança de pendência` |
| `conteudo` | o mesmo texto do corpo — é o que o atendente lê na tela |
| `metaNome` | **exatamente** o nome aprovado, ex.: `pendencia_cobranca` |
| `metaIdioma` | `pt_BR` |
| `metaChave` | o evento: `pendencia_cobranca`, `posvenda_passo`, `posvenda_nps` ou `horas_percentual` |
| `metaVariaveis` | os rótulos, na ordem — ver tabela abaixo |
| `metaStatus` | `aprovado` |
| `ativo` | sim |

**`metaVariaveis`, na ordem exata:**

| Template | `metaVariaveis` |
|---|---|
| `pendencia_cobranca` | `["Pendência", "Prazo"]` |
| `posvenda_passo` | `["Texto do passo"]` |
| `posvenda_nps` | `["Pergunta da avaliação"]` |
| `horas_percentual` | `["Percentual atingido", "Horas contratadas"]` |

> **A ordem é contrato com o código.** O Central preenche `{{1}}`, `{{2}}` na
> ordem em que monta os valores (`whatsappAutomacoes` e
> `checkHorasContratadasNotify`). Cadastrar invertido não dá erro em lugar
> nenhum — só manda a frase trocada para o cliente.

**`metaNome` e `metaChave` costumam ser iguais, e não são a mesma coisa.**
`metaNome` é como a Meta chama o template; `metaChave` é o evento que ele
atende no Central. Eles coincidem porque escolhi nomes iguais de propósito — se
um dia a Meta obrigar a renomear um template, só o `metaNome` muda.

---

## Conferir que ligou

1. **Sem sair mensagem para ninguém:** rode `whatsappAutomacoes` à mão. A
   resposta traz `motivos` agregados — enquanto faltar template, aparece
   `{"sem template aprovado para \"pendencia_cobranca\"": 3}`. Com tudo
   cadastrado, esse motivo some.
2. **Com um cliente de teste:** ponha o seu próprio número num cliente de teste,
   crie uma pendência vencendo hoje e rode de novo. A mensagem chega, e a
   conversa aparece na caixa de entrada com o autor `Automação · pendência`.
3. **O descadastro:** responda `SAIR` naquele número. O cliente ganha
   `whatsappOptOut`, chega a confirmação, e a rodada seguinte passa a registrar
   `cliente optou por não receber` para ele.

---

## Se a Meta reprovar

| Motivo comum | O que fazer |
|---|---|
| Exemplos ausentes ou genéricos | Preencher com frase real e completa (o erro nº 1) |
| "Conteúdo promocional" em Utilidade | Tirar convite a comprar. No `posvenda_nps`, ver a ressalva da categoria |
| Variável no começo ou no fim | Já resolvido nos textos acima — conferir se alguém editou |
| Nome inválido | Só minúsculas, números e sublinhado. Sem acento, sem espaço |

Reprovado não queima o nome: dá para corrigir e reenviar o mesmo. O que não se
deve fazer é reenviar igual, esperando outro revisor.
