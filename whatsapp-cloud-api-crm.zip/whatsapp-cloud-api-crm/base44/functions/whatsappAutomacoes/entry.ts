import { createClientFromRequest } from 'npm:@base44/sdk@0.8.48';
import { CHAVES, dispararTemplate } from '../../shared/whatsappAutomacao.ts';

// As automações que FALAM COM O CLIENTE pelo WhatsApp.
//
// Duas fontes, as duas já existentes no sistema — esta função não inventa
// regra de negócio nenhuma, só leva pelo WhatsApp o que o Central já decidiu:
//
//  1. PENDÊNCIA vencendo ou vencida, do cliente.
//  2. PÓS-VENDA: as `Communication` de tipo `whatsapp` que o `posVendaEngine`
//     deixou pendentes — passo da jornada e pedido de NPS.
//
// O terceiro caso pedido, o aviso de horas contratadas, NÃO está aqui: ele
// mora dentro de `checkHorasContratadasNotify`, junto do alerta interno que já
// existia, porque é lá que o percentual é calculado. Duplicar a conta aqui
// seria criar duas verdades sobre quanto o cliente já consumiu.
//
// ── O que esta função nunca faz ─────────────────────────────────────────────
//
// Decidir se pode mandar. Isso é de `shared/whatsappAutomacao.ts`, que confere
// canal configurado, opt-out do cliente, template aprovado e repetição antes de
// qualquer envio. Aqui só se escolhe O QUE avisar e com quais palavras.
//
// Agendada (cron diário), sem sessão de usuário — classificada assim em
// scripts/verificarPortarias.mjs.

/** Teto por rodada. Fila represada vira disparo em massa, e disparo em massa derruba a nota do número. */
const ENVIOS_MAX = 80;

/** Pendência vencendo dentro disto entra na cobrança do dia. */
const DIAS_AVISO = 2;

const dia = 24 * 60 * 60 * 1000;

const soData = (iso: string) => String(iso || '').slice(0, 10);

function diasAte(dataISO: string): number | null {
  const t = Date.parse(`${soData(dataISO)}T12:00:00Z`);
  if (Number.isNaN(t)) return null;
  return Math.round((t - Date.now()) / dia);
}

Deno.serve(async (req: Request) => {
  try {
    const base44 = createClientFromRequest(req);
    const svc = base44.asServiceRole;

    const feitos: Array<{ origem: string; clienteId: string; ok: boolean; motivo: string }> = [];
    const registrar = (origem: string, clienteId: string, r: { ok: boolean; motivo: string }) =>
      feitos.push({ origem, clienteId, ok: r.ok, motivo: r.motivo });

    // ── 1. Pendências ───────────────────────────────────────────────────────
    //
    // Só as que têm prazo e ainda não foram concluídas. Sem prazo não há o que
    // cobrar, e cobrar o que já foi entregue é o jeito mais rápido de o cliente
    // bloquear o número.
    // Aberta é `pendente` e `em_andamento`: as duas ainda dependem do cliente.
    // `em_acompanhamento`, `concluida` e `cancelada` não se cobram.
    const abertas = await Promise.all([
      svc.entities.Pendencia.filter({ status: 'pendente' }).catch(() => []),
      svc.entities.Pendencia.filter({ status: 'em_andamento' }).catch(() => []),
    ]);
    const pendencias = [...(abertas[0] || []), ...(abertas[1] || [])];

    for (const p of pendencias.slice(0, ENVIOS_MAX)) {
      if (!p?.clientId || !p?.dataVencimento) continue;
      const dias = diasAte(p.dataVencimento);
      if (dias === null || dias > DIAS_AVISO) continue;

      const quando = dias < 0
        ? `venceu há ${Math.abs(dias)} dia(s)`
        : dias === 0
          ? 'vence hoje'
          : `vence em ${dias} dia(s)`;

      registrar('pendencia', p.clientId, await dispararTemplate(svc, {
        clienteId: p.clientId,
        chave: CHAVES.PENDENCIA,
        // A ordem é a das variáveis do template aprovado: {{1}} o que é,
        // {{2}} o prazo. Mudar aqui sem mudar lá manda a frase trocada.
        variaveis: [String(p.titulo || p.descricao || 'pendência'), quando],
        // O prazo entra na chave do fato: pendência que teve o prazo empurrado
        // volta a avisar, e a mesma pendência no mesmo prazo não.
        fato: `pendencia:${p.id}:${soData(p.dataVencimento)}`,
        origem: 'pendência',
      }));
    }

    // ── 2. Pós-venda ────────────────────────────────────────────────────────
    //
    // O `posVendaEngine` não envia nada: ele deixa `Communication` pendente. Ao
    // ler daqui, o WhatsApp vira mais um canal do que já existe, em vez de uma
    // segunda jornada correndo por fora.
    const comunicacoes = await svc.entities.Communication
      .filter({ tipo: 'whatsapp', status: 'pendente' }).catch(() => []);

    for (const c of (comunicacoes || []).slice(0, ENVIOS_MAX)) {
      if (!c?.client_id) continue;
      if (c.scheduled_at && Date.parse(c.scheduled_at) > Date.now()) continue;

      const ehNps = String(c.conteudo || '').toLowerCase().includes('nps');
      const r = await dispararTemplate(svc, {
        clienteId: c.client_id,
        chave: ehNps ? CHAVES.POSVENDA_NPS : CHAVES.POSVENDA_PASSO,
        variaveis: [String(c.conteudo || '').slice(0, 500)],
        fato: `communication:${c.id}`,
        origem: ehNps ? 'pós-venda · NPS' : 'pós-venda',
      });
      registrar('pos-venda', c.client_id, r);

      // Só marca como enviada quando de fato saiu. Marcar mesmo na recusa
      // perderia a comunicação em silêncio — ela nunca mais seria tentada.
      if (r.ok) {
        await svc.entities.Communication.update(c.id, {
          status: 'enviado',
          sent_at: new Date().toISOString(),
        }).catch(() => {});
      }
    }

    const enviados = feitos.filter((f) => f.ok).length;
    return Response.json({
      ok: true,
      enviados,
      avaliados: feitos.length,
      // Os motivos das não-enviadas voltam agregados: é o que permite descobrir
      // "faltou template aprovado" sem abrir o log linha a linha.
      motivos: feitos.filter((f) => !f.ok).reduce((acc: Record<string, number>, f) => {
        acc[f.motivo] = (acc[f.motivo] || 0) + 1;
        return acc;
      }, {}),
    });
  } catch (e) {
    console.error('WHATSAPP AUTOMACOES: erro na rodada.', e);
    return Response.json({ error: (e as Error)?.message || 'erro' }, { status: 500 });
  }
});
