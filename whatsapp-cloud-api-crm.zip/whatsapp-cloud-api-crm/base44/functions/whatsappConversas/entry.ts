import { createClientFromRequest } from 'npm:@base44/sdk@0.8.48';
import {
  janelaAberta,
  marcarLidaNaMeta,
  normalizarTelefone,
  VERSAO_PADRAO,
  type Config,
} from '../../shared/whatsapp.ts';
import { acharCadastro, garantirConversa } from '../../shared/whatsappConversa.ts';
import {
  alcanceDoUsuario,
  podeVerConversa,
  RECUSA_CONVERSA,
  type Alcance,
} from '../../shared/whatsappAcesso.ts';

// A caixa de entrada do WhatsApp — leitura e ações de atendimento.
//
// Uma função por AÇÃO seria meia dúzia de endpoints com a mesma portaria copiada
// seis vezes; aqui vale o mesmo desenho da função `chat`: um endpoint, uma
// portaria, `acao` no corpo.
//
// POR QUE A TELA NÃO LÊ AS ENTIDADES DIRETO
//
// Uma conversa de WhatsApp traz o telefone pessoal de um cliente e o que ele
// escreveu — inclusive o que ele mandou por engano. Deixar `WhatsAppMensagem`
// aberta ao navegador é publicar isso para qualquer pessoa logada, sem passar
// pelas permissões do módulo. Como no Chat Global, as entidades ficam fechadas
// e esta função é o único caminho.
//
// Consequência prática: não existe `.subscribe()` aqui. O que mantém a tela
// viva é a consulta curta de `useChatPolling`, a mesma do chat.
//
// QUEM VÊ O QUÊ: cada consultor alcança as conversas dos clientes de que é
// responsável; admin alcança todas. A regra inteira, com o caso da conversa
// ainda sem vínculo, está em shared/whatsappAcesso.ts — e é conferida aqui,
// em TODA ação que recebe um conversaId, não só na listagem.
//
// Desenho do canal: docs/whatsapp/PLANO.md.

const texto = (v: unknown, max = 500) => String(v ?? '').slice(0, max);

const LIMITE_MENSAGENS = 200;
const LIMITE_CONVERSAS = 200;

// ── Portaria ────────────────────────────────────────────────────────────────
//
// Idêntica à das demais funções que leem dado de cliente: funções do Base44 são
// endpoints HTTP abertos, e sem esta checagem a caixa de entrada do atendimento
// fica legível para quem descobrir a URL.
const passa = (usuario: any) => ({ ok: true, status: 200, motivo: '', usuario });
const barra = (status: number, motivo: string) => ({ ok: false, status, motivo, usuario: null });

async function shaHex(t: string): Promise<string> {
  const d = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t));
  return Array.from(new Uint8Array(d)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function exigirUsuario(base44: any, body: any) {
  const ents = base44.asServiceRole.entities;

  const token = String(body?.sessaoToken || '').trim();
  if (/^[0-9a-f]{64}$/.test(token)) {
    const dono = (await ents.UsuarioSistema
      .filter({ sessaoTokenHash: await shaHex(token) }).catch(() => []))[0];
    if (dono && dono.status === 'ativo' && Date.parse(dono.sessaoExpira || '') > Date.now()) {
      return passa(dono);
    }
  }

  try {
    const me = await base44.auth.me();
    const email = me?.email ? String(me.email).trim().toLowerCase() : '';
    if (email) {
      const u = (await ents.UsuarioSistema.filter({ email }).catch(() => []))[0];
      if (u && u.status === 'ativo') return passa(u);
    }
    if (me?.id) return passa(null);
  } catch { /* sem sessão Base44 — cai na identidade declarada */ }

  const id = String(body?.loginAcessoId || '').trim().slice(0, 100);
  if (!id) return barra(401, 'Não autenticado.');
  const u = (await ents.UsuarioSistema.filter({ id }).catch(() => []))[0];
  if (!u) return barra(403, 'Sessão inválida.');
  if (u.status !== 'ativo') return barra(403, 'Usuário inativo.');
  if (u.sessaoServidorDesde) return barra(401, 'Sessão expirada. Entre de novo.');
  return passa(u);
}

// ── Formatos de saída ───────────────────────────────────────────────────────
//
// A tela recebe o que ela mostra, e nada além: o `metadados` cru da Meta e o id
// de mídia dela não têm uso no navegador e só aumentariam a superfície exposta.

const conversaParaTela = (c: any) => ({
  id: c.id,
  telefone: c.telefone,
  telefoneExibicao: c.telefoneExibicao || '',
  nomePerfil: c.nomePerfil || '',
  vinculoTipo: c.vinculoTipo || 'nenhum',
  vinculoId: c.vinculoId || '',
  vinculoNome: c.vinculoNome || '',
  ticketId: c.ticketId || '',
  ultimaMensagemEm: c.ultimaMensagemEm || '',
  ultimaMensagemPreview: c.ultimaMensagemPreview || '',
  ultimaMensagemDirecao: c.ultimaMensagemDirecao || '',
  janelaExpiraEm: c.janelaExpiraEm || '',
  janelaAberta: janelaAberta(c.janelaExpiraEm),
  naoLidas: Number(c.naoLidas || 0),
  status: c.status || 'aberta',
  responsavelUserId: c.responsavelUserId || '',
  responsavelNome: c.responsavelNome || '',
});

const mensagemParaTela = (m: any) => ({
  id: m.id,
  wamid: m.wamid || '',
  direcao: m.direcao,
  tipo: m.tipo || 'texto',
  texto: m.texto || '',
  midia: m.midia
    ? {
        url: m.midia.url || '',
        nome: m.midia.nome || '',
        mime: m.midia.mime || '',
        tamanho: m.midia.tamanho || 0,
        erro: m.midia.erro || '',
      }
    : null,
  status: m.status || '',
  erroMensagem: m.erroMensagem || '',
  ocorridoEm: m.ocorridoEm || m.created_date || '',
  entregueEm: m.entregueEm || '',
  lidaEm: m.lidaEm || '',
  autorNome: m.autorNome || '',
  templateNome: m.templateNome || '',
  respondendoAWamid: m.respondendoAWamid || '',
});

const porInstante = (campo: string, desc = false) => (a: any, b: any) => {
  const x = String(a?.[campo] || a?.created_date || '');
  const y = String(b?.[campo] || b?.created_date || '');
  return desc ? y.localeCompare(x) : x.localeCompare(y);
};

function configDoAmbiente(): Config {
  return {
    token: Deno.env.get('WHATSAPP_ACCESS_TOKEN') || '',
    phoneNumberId: Deno.env.get('WHATSAPP_PHONE_NUMBER_ID') || '',
    versao: Deno.env.get('WHATSAPP_API_VERSION') || VERSAO_PADRAO,
  };
}

Deno.serve(async (req: Request) => {
  try {
    if (req.method !== 'POST') {
      return Response.json({ error: 'Method not allowed' }, { status: 405 });
    }

    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));

    const porta = await exigirUsuario(base44, body);
    if (!porta.ok) return Response.json({ error: porta.motivo }, { status: porta.status });

    const svc = base44.asServiceRole;
    const acao = String(body?.acao || '');

    // Uma vez por requisição, e não uma por conversa.
    const alcance: Alcance = await alcanceDoUsuario(svc, porta.usuario);

    /**
     * A conversa pedida, ou `null` — toda ação que recebe id passa por aqui.
     *
     * Devolve `null` TAMBÉM quando a conversa existe mas está fora do alcance:
     * quem chama trata os dois casos como "não encontrada", que é o que a
     * pessoa deve ver. Distinguir os dois na resposta contaria que aquele
     * número conversa com a empresa.
     */
    const conversaDoCorpo = async () => {
      const id = texto(body?.conversaId, 100);
      if (!id) return null;
      const c = (await svc.entities.WhatsAppConversa.filter({ id }).catch(() => []))[0] || null;
      if (!c || !podeVerConversa(c, alcance)) return null;
      return c;
    };

    // ── Lista ───────────────────────────────────────────────────────────────
    if (acao === 'listar_conversas') {
      const status = body?.status === 'arquivada' ? 'arquivada' : 'aberta';
      const todas = await svc.entities.WhatsAppConversa.filter({ status }).catch(() => []);

      const busca = texto(body?.busca, 100).toLowerCase().trim();
      const digitos = busca.replace(/\D/g, '');
      const filtradas = (todas || []).filter((c: any) => {
        if (!podeVerConversa(c, alcance)) return false;
        if (!busca) return true;
        const alvo = `${c.nomePerfil || ''} ${c.vinculoNome || ''}`.toLowerCase();
        return alvo.includes(busca) || (!!digitos && String(c.telefone || '').includes(digitos));
      });

      return Response.json({
        ok: true,
        conversas: filtradas
          .sort(porInstante('ultimaMensagemEm', true))
          .slice(0, LIMITE_CONVERSAS)
          .map(conversaParaTela),
      });
    }

    // ── Thread ──────────────────────────────────────────────────────────────
    if (acao === 'listar_mensagens') {
      const conversa = await conversaDoCorpo();
      if (!conversa) return Response.json({ error: 'Conversa não encontrada.' }, { status: 404 });

      const todas = await svc.entities.WhatsAppMensagem
        .filter({ conversaId: conversa.id }).catch(() => []);
      const limite = Math.min(Number(body?.limite) || LIMITE_MENSAGENS, LIMITE_MENSAGENS);

      // As últimas `limite`, mas devolvidas em ordem crescente: a thread lê de
      // cima para baixo, e paginar pelo começo faria a conversa antiga aparecer
      // no lugar da recente.
      const ordenadas = (todas || []).sort(porInstante('ocorridoEm'));
      return Response.json({
        ok: true,
        conversa: conversaParaTela(conversa),
        mensagens: ordenadas.slice(-limite).map(mensagemParaTela),
      });
    }

    // ── Marcar lido ─────────────────────────────────────────────────────────
    if (acao === 'marcar_lido') {
      const conversa = await conversaDoCorpo();
      if (!conversa) return Response.json({ error: 'Conversa não encontrada.' }, { status: 404 });

      if (Number(conversa.naoLidas || 0) > 0) {
        await svc.entities.WhatsAppConversa.update(conversa.id, { naoLidas: 0 });
      }

      // Os dois tiques azuis no aparelho do cliente só aparecem AGORA, quando
      // alguém de fato abriu a conversa — mandar o recibo na chegada da
      // mensagem seria mentir para o cliente sobre ter sido lido.
      const cfg = configDoAmbiente();
      if (cfg.token && cfg.phoneNumberId) {
        const todas = await svc.entities.WhatsAppMensagem
          .filter({ conversaId: conversa.id, direcao: 'entrada' }).catch(() => []);
        const ultima = (todas || []).sort(porInstante('ocorridoEm')).slice(-1)[0];
        if (ultima?.wamid) await marcarLidaNaMeta(cfg, ultima.wamid);
      }

      return Response.json({ ok: true });
    }

    // ── Vínculo com o cadastro ──────────────────────────────────────────────
    if (acao === 'vincular') {
      const conversa = await conversaDoCorpo();
      if (!conversa) return Response.json({ error: 'Conversa não encontrada.' }, { status: 404 });

      const tipo = String(body?.vinculoTipo || 'nenhum');
      const permitidos = ['nenhum', 'cliente', 'prospect', 'contato', 'agente'];
      if (!permitidos.includes(tipo)) {
        return Response.json({ error: 'Tipo de vínculo inválido.' }, { status: 400 });
      }

      if (tipo === 'nenhum') {
        await svc.entities.WhatsAppConversa.update(conversa.id, {
          vinculoTipo: 'nenhum', vinculoId: '', vinculoNome: '',
        });
        return Response.json({ ok: true, vinculoTipo: 'nenhum' });
      }

      const entidade = { cliente: 'Cliente', prospect: 'Prospect', contato: 'Contato', agente: 'Agente' }[tipo]!;
      const id = texto(body?.vinculoId, 100);
      const alvo = (await svc.entities[entidade].filter({ id }).catch(() => []))[0];
      if (!alvo) return Response.json({ error: 'Registro não encontrado.' }, { status: 404 });

      await svc.entities.WhatsAppConversa.update(conversa.id, {
        vinculoTipo: tipo,
        vinculoId: alvo.id,
        vinculoNome: texto(alvo.nome || alvo.razaoSocial || '', 200),
        ...(alvo.entidadeInternaId ? { entidadeInternaId: alvo.entidadeInternaId } : {}),
      });
      return Response.json({ ok: true, vinculoTipo: tipo, vinculoNome: alvo.nome || alvo.razaoSocial || '' });
    }

    /**
     * Cadastros que casam com o termo digitado, para o vínculo manual.
     *
     * Busca por trecho de nome não existe no `filter` (que é igualdade), então
     * aqui é lista + comparação em memória, com teto por entidade. É a mesma
     * escolha do diretório de canais do chat: o volume dessas três entidades é
     * de centenas, e um índice de busca para isso seria um sistema novo.
     */
    if (acao === 'buscar_cadastros') {
      const termo = texto(body?.termo, 80).toLowerCase().trim();
      if (termo.length < 2) return Response.json({ ok: true, cadastros: [] });

      const fontes = [
        { entidade: 'Cliente', tipo: 'cliente' },
        { entidade: 'Contato', tipo: 'contato' },
        { entidade: 'Prospect', tipo: 'prospect' },
      ];

      const cadastros: any[] = [];
      for (const fonte of fontes) {
        const linhas = await svc.entities[fonte.entidade]
          .list('-created_date', 2000).catch(() => []);
        for (const r of linhas || []) {
          const nome = String(r.nome || r.razaoSocial || '');
          if (!nome.toLowerCase().includes(termo)) continue;
          cadastros.push({
            tipo: fonte.tipo,
            id: r.id,
            nome,
            telefone: String(r.whatsapp || r.telefone || ''),
          });
          if (cadastros.length >= 40) break;
        }
        if (cadastros.length >= 40) break;
      }

      return Response.json({ ok: true, cadastros });
    }

    /** Sugestão de vínculo para uma conversa ainda solta. */
    if (acao === 'sugerir_vinculo') {
      const conversa = await conversaDoCorpo();
      if (!conversa) return Response.json({ error: 'Conversa não encontrada.' }, { status: 404 });
      const achado = await acharCadastro(svc, conversa.telefone);
      return Response.json({ ok: true, sugestao: achado || null });
    }

    // ── Atendimento ─────────────────────────────────────────────────────────
    if (acao === 'assumir') {
      const conversa = await conversaDoCorpo();
      if (!conversa) return Response.json({ error: 'Conversa não encontrada.' }, { status: 404 });
      // Assumir é do usuário da sessão, e não de um id vindo do corpo: caso
      // contrário dava para "assumir" em nome de outra pessoa.
      const largar = body?.largar === true;
      await svc.entities.WhatsAppConversa.update(conversa.id, {
        responsavelUserId: largar ? '' : (porta.usuario?.id || ''),
        responsavelNome: largar ? '' : String(porta.usuario?.nome || ''),
      });
      return Response.json({ ok: true });
    }

    if (acao === 'arquivar') {
      const conversa = await conversaDoCorpo();
      if (!conversa) return Response.json({ error: 'Conversa não encontrada.' }, { status: 404 });
      await svc.entities.WhatsAppConversa.update(conversa.id, {
        status: body?.arquivar === false ? 'aberta' : 'arquivada',
      });
      return Response.json({ ok: true });
    }

    // ── Ticket a partir da conversa ─────────────────────────────────────────
    //
    // Manual de propósito. Abrir ticket a cada mensagem que chega encheria o
    // suporte de "bom dia" — quem sabe que aquilo virou um chamado é a pessoa
    // que leu a conversa.
    if (acao === 'abrir_ticket') {
      const conversa = await conversaDoCorpo();
      if (!conversa) return Response.json({ error: 'Conversa não encontrada.' }, { status: 404 });
      if (conversa.ticketId) {
        return Response.json({ ok: true, ticketId: conversa.ticketId, jaExistia: true });
      }

      const ticket = await svc.entities.SuporteTicket.create({
        titulo: texto(body?.titulo, 200) || `WhatsApp — ${conversa.nomePerfil || conversa.telefoneExibicao || conversa.telefone}`,
        tipo: body?.tipo === 'funcional' ? 'funcional' : 'tecnico',
        prioridade: ['critico', 'urgente', 'alto', 'normal'].includes(String(body?.prioridade))
          ? String(body.prioridade)
          : 'normal',
        status: 'pendente',
        origem: 'whatsapp',
        descricao: texto(body?.descricao, 4000) || conversa.ultimaMensagemPreview || '',
        nomeContato: texto(conversa.nomePerfil, 200),
        dataAberto: new Date().toISOString().slice(0, 10),
        ...(conversa.vinculoTipo === 'cliente' && conversa.vinculoId
          ? { client_id: conversa.vinculoId, nomeEscritorio: texto(conversa.vinculoNome, 200) }
          : {}),
        ...(porta.usuario?.id
          ? { responsavelSJ: porta.usuario.id, responsavelSJNome: String(porta.usuario.nome || '') }
          : {}),
      });

      await svc.entities.WhatsAppConversa.update(conversa.id, { ticketId: ticket.id });
      return Response.json({ ok: true, ticketId: ticket.id });
    }

    // ── Templates ───────────────────────────────────────────────────────────
    if (acao === 'listar_templates') {
      const todos = await svc.entities.TemplatesMensagem
        .filter({ tipo: 'whatsapp', ativo: true }).catch(() => []);
      return Response.json({
        ok: true,
        templates: (todos || []).map((t: any) => ({
          id: t.id,
          titulo: t.titulo || '',
          conteudo: t.conteudo || '',
          metaNome: t.metaNome || '',
          metaIdioma: t.metaIdioma || 'pt_BR',
          metaVariaveis: Array.isArray(t.metaVariaveis) ? t.metaVariaveis : [],
          metaStatus: t.metaStatus || 'rascunho',
          // Só o que a Meta aprovou reabre conversa fechada; o resto serve para
          // redigir dentro da janela.
          disparavel: !!t.metaNome && (!t.metaStatus || t.metaStatus === 'aprovado'),
        })),
      });
    }

    // ── Abrir conversa a partir de um número ────────────────────────────────
    if (acao === 'abrir_por_telefone') {
      const cfg = configDoAmbiente();
      if (!cfg.phoneNumberId) {
        return Response.json(
          { error: 'Canal do WhatsApp não configurado.', codigo: 'nao_configurado' },
          { status: 503 },
        );
      }
      const telefone = normalizarTelefone(body?.telefone);
      if (!telefone) {
        return Response.json(
          { error: 'Telefone inválido. Use DDD + número, ou "+" com o código do país.', codigo: 'telefone_invalido' },
          { status: 400 },
        );
      }
      const conversa = await garantirConversa(svc, { telefone, numeroId: cfg.phoneNumberId });
      if (!conversa?.id) return Response.json({ error: 'Não foi possível abrir a conversa.' }, { status: 500 });

      // Abrir pelo número não pode ser a porta dos fundos da regra de alcance:
      // digitar o telefone de um cliente de outro consultor traria a conversa
      // inteira dele.
      if (!podeVerConversa(conversa, alcance)) {
        return Response.json(
          { error: 'Esta conversa é de um cliente sob responsabilidade de outra pessoa.', codigo: 'fora_do_alcance' },
          { status: 403 },
        );
      }
      return Response.json({ ok: true, conversa: conversaParaTela(conversa) });
    }

    return Response.json({ error: `Ação desconhecida: ${acao}` }, { status: 400 });
  } catch (e) {
    console.error('WHATSAPP: erro na caixa de entrada.', e);
    return Response.json({ error: (e as Error)?.message || 'erro' }, { status: 500 });
  }
});
