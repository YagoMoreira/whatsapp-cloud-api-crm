import { createClientFromRequest } from 'npm:@base44/sdk@0.8.48';
import { janelaAberta } from '../../shared/whatsapp.ts';
import { ehAdminSistema } from '../../shared/whatsappAcesso.ts';

// O vigia do WhatsApp — roda a cada 30 minutos e avisa QUEM PRECISA AGIR.
//
// ── Por que ele existe ──────────────────────────────────────────────────────
//
// Uma caixa de entrada só funciona quando alguém está olhando para ela. Fora
// disso, a mensagem do cliente fica parada e a janela de 24h escorre: passadas
// as 24h, responder deixa de ser de graça e passa a exigir template aprovado,
// cobrado — e o cliente esperou um dia por nada.
//
// ── Por que o aviso é INTERNO, e não um WhatsApp ────────────────────────────
//
// O aviso vai para o sininho do Central (NotificacaoSJOn), não para o WhatsApp
// de ninguém. Mandar mensagem a cada 30 minutos pela Cloud API custaria por
// disparo e derrubaria a nota de qualidade do número — o risco de bloqueio na
// Meta vem de volume, não de conteúdo. Aqui não se gasta nem se arrisca nada.
//
// ── Para quem ──────────────────────────────────────────────────────────────
//
// Para o RESPONSÁVEL pelo cliente daquela conversa, que é quem tem o que fazer.
// Conversa ainda sem vínculo não tem responsável: aí o aviso vai para os
// administradores, que são quem consegue vincular.
//
// Agendada (cron de 30 min), sem sessão de usuário — está classificada assim em
// scripts/verificarPortarias.mjs.

/** Cliente esperando há mais que isto sem resposta vira aviso. */
const ESPERA_MINUTOS = 30;

/** Janela terminando em menos que isto vira aviso de urgência. */
const JANELA_URGENTE_MS = 3 * 60 * 60 * 1000;

/** Teto por rodada, para uma fila represada não virar enxurrada no sininho. */
const AVISOS_MAX = 60;

const minutos = (ms: number) => Math.floor(ms / 60000);

/**
 * Já avisamos esta pessoa sobre esta conversa nesta espera?
 *
 * Sem esta checagem o vigia repetiria o mesmo aviso a cada meia hora até alguém
 * responder — e um sininho que repete é um sininho que se aprende a ignorar. A
 * chave inclui o instante da mensagem do cliente: mensagem NOVA volta a avisar.
 */
async function jaAvisado(svc: any, usuarioId: string, chave: string) {
  const anteriores = await svc.entities.NotificacaoSJOn
    .filter({ usuarioId, tipo: 'whatsapp_espera' })
    .catch(() => []);
  return (anteriores || []).some((n: any) => String(n?.corpo || '').includes(chave));
}

async function avisar(
  svc: any,
  { usuarioId, clienteId, titulo, corpo, conversaId }:
    { usuarioId: string; clienteId: string; titulo: string; corpo: string; conversaId: string },
) {
  await svc.entities.NotificacaoSJOn.create({
    // `clienteId` é obrigatório na entidade; conversa sem vínculo usa string
    // vazia, que é o que o resto do sistema já faz com notificação sem cliente.
    clienteId: clienteId || '',
    usuarioId,
    titulo,
    corpo,
    tipo: 'whatsapp_espera',
    lida: false,
    linkUrl: `/whatsapp/conversas?conversa=${conversaId}`,
  }).catch((e: any) => console.error('WHATSAPP VIGIA: não foi possível notificar.', e));
}

Deno.serve(async (req: Request) => {
  try {
    const base44 = createClientFromRequest(req);
    const svc = base44.asServiceRole;
    const agora = Date.now();

    const abertas = await svc.entities.WhatsAppConversa
      .filter({ status: 'aberta' }).catch(() => []);

    // Só interessa conversa em que o CLIENTE falou por último: se a última
    // palavra foi nossa, a bola está com ele e não há nada a cobrar de ninguém.
    const esperando = (abertas || []).filter((c: any) => {
      if (c?.ultimaMensagemDirecao !== 'entrada') return false;
      const quando = Date.parse(c?.ultimaMensagemEm || '');
      if (Number.isNaN(quando)) return false;
      return agora - quando >= ESPERA_MINUTOS * 60000;
    });

    if (!esperando.length) {
      return Response.json({ ok: true, conversas: 0, avisos: 0 });
    }

    // Os destinatários são resolvidos uma vez, e não por conversa.
    const usuarios = await svc.entities.UsuarioSistema
      .filter({ status: 'ativo' }).catch(() => []);
    const admins = (usuarios || []).filter((u: any) => ehAdminSistema(u));

    const clientesIds = [...new Set(
      esperando
        .filter((c: any) => c.vinculoTipo === 'cliente' && c.vinculoId)
        .map((c: any) => String(c.vinculoId)),
    )];
    const responsavelPorCliente = new Map<string, string>();
    for (const id of clientesIds) {
      const cli = (await svc.entities.Cliente.filter({ id }).catch(() => []))[0];
      if (cli?.responsavelUserId) responsavelPorCliente.set(id, String(cli.responsavelUserId));
    }

    let avisos = 0;
    for (const c of esperando.slice(0, AVISOS_MAX)) {
      const esperaMin = minutos(agora - Date.parse(c.ultimaMensagemEm));
      const quem = c.vinculoNome || c.nomePerfil || c.telefoneExibicao || c.telefone;

      // A janela fechando é o que transforma "responda quando puder" em
      // "responda agora": depois dela, a resposta é cobrada.
      const fim = Date.parse(c.janelaExpiraEm || '');
      const urgente = janelaAberta(c.janelaExpiraEm, agora) && fim - agora <= JANELA_URGENTE_MS;
      const fechada = !janelaAberta(c.janelaExpiraEm, agora);

      const titulo = fechada
        ? `WhatsApp: janela fechou — ${quem}`
        : urgente
          ? `WhatsApp: janela fechando — ${quem}`
          : `WhatsApp: ${quem} aguarda resposta`;

      const corpo = [
        `${quem} escreveu há ${esperaMin} min e ainda não teve resposta.`,
        fechada
          ? 'A janela de 24h fechou: agora só um template aprovado reabre a conversa.'
          : urgente
            ? `A janela de resposta livre fecha em ${minutos(fim - agora)} min.`
            : '',
        // A chave da repetição fica no corpo, não num campo novo: NotificacaoSJOn
        // é entidade compartilhada, e isto não justifica mudar o schema dela.
        `[ref:${c.id}:${c.ultimaMensagemEm}]`,
      ].filter(Boolean).join(' ');

      const responsavelId = c.vinculoTipo === 'cliente' && c.vinculoId
        ? responsavelPorCliente.get(String(c.vinculoId))
        : '';

      const destinatarios = responsavelId
        ? [responsavelId]
        : admins.map((u: any) => String(u.id));

      for (const usuarioId of destinatarios) {
        if (await jaAvisado(svc, usuarioId, `[ref:${c.id}:${c.ultimaMensagemEm}]`)) continue;
        await avisar(svc, {
          usuarioId,
          clienteId: c.vinculoTipo === 'cliente' ? String(c.vinculoId || '') : '',
          titulo,
          corpo,
          conversaId: c.id,
        });
        avisos++;
      }
    }

    return Response.json({ ok: true, conversas: esperando.length, avisos });
  } catch (e) {
    console.error('WHATSAPP VIGIA: erro na rodada.', e);
    return Response.json({ error: (e as Error)?.message || 'erro' }, { status: 500 });
  }
});
