import { createClientFromRequest } from 'npm:@base44/sdk@0.8.48';
import { enviarTemplate, VERSAO_PADRAO, type Config } from '../../shared/whatsapp.ts';
import { garantirConversa, resumoDeSaida } from '../../shared/whatsappConversa.ts';
import {
  diaUTC,
  podeDisparar,
  proximaLeva,
  quantosCabemHoje,
  resolverVariaveis,
  variavelVazia,
} from '../../shared/whatsappCampanha.ts';

// O motor da campanha: pega o que cabe hoje, manda, e volta na próxima rodada.
//
// Agendada. Não tem portaria de usuário porque não tem usuário — e não aceita
// nada do corpo da requisição que mude o que sai: a campanha, o público e o
// template já estão gravados e já foram aprovados por um administrador.
//
// ── Por que em rodadas pequenas, e não de uma vez ───────────────────────────
//
// A Meta limita destinatários ÚNICOS por 24h por degraus (250 → 1.000 →
// 10.000 → 100.000), e o degrau sobe ou desce conforme a nota de qualidade do
// número. Uma rajada que estoura o teto não perde só o excedente: a sequência
// de recusas derruba a nota, e com ela o degrau. O jeito de mandar para muita
// gente é mandar devagar.
//
// Roda a cada 15 minutos e manda um punhado por vez, de propósito: espalhar no
// dia parece mais com atendimento e menos com disparador, e a função termina
// rápido em vez de segurar uma execução longa que pode ser cortada no meio.
//
// ── O que nunca acontece aqui ───────────────────────────────────────────────
//
// Nada sai sem `aprovadoPorUserId` gravado. Nada sai para quem tem opt-out —
// e ele é conferido DE NOVO na hora do envio, não só na montagem: entre montar
// e mandar podem passar dias, e quem escreveu "SAIR" ontem não pode receber a
// leva de hoje.

const LOTE_POR_RODADA = 25;

function configDoAmbiente(): Config {
  return {
    token: Deno.env.get('WHATSAPP_ACCESS_TOKEN') || '',
    phoneNumberId: Deno.env.get('WHATSAPP_PHONE_NUMBER_ID') || '',
    versao: Deno.env.get('WHATSAPP_API_VERSION') || VERSAO_PADRAO,
  };
}

/**
 * O opt-out, relido do cadastro AGORA.
 *
 * A montagem já filtrou, mas a campanha demora dias e o "SAIR" de ontem tem de
 * valer para a leva de hoje. Cadastro apagado no meio também vira pulo — não
 * erro: não temos como saber se aquele número ainda é daquela pessoa.
 */
async function saiuDepois(svc: any, d: any): Promise<string> {
  const entidade = d?.tipo === 'prospect' ? 'Prospect' : 'Cliente';
  if (!d?.alvoId) return '';
  const r = (await svc.entities[entidade].filter({ id: d.alvoId }).catch(() => []))[0];
  if (!r) return 'cadastro não existe mais';
  if (r.whatsappOptOut === true) return 'pediu para não receber';
  return '';
}

/** Uma pessoa: manda, grava na thread e devolve o que aconteceu. */
async function mandarPara(
  svc: any,
  cfg: Config,
  campanha: any,
  d: any,
): Promise<'enviado' | 'pulado' | 'falhou'> {
  const agora = new Date().toISOString();

  const motivoDeSaida = await saiuDepois(svc, d);
  if (motivoDeSaida) {
    await svc.entities.CampanhaDestinatario.update(d.id, {
      status: 'pulado',
      motivo: motivoDeSaida,
    }).catch(() => {});
    return 'pulado';
  }

  const valores = resolverVariaveis(campanha.variaveis || [], {
    nome: d.nome,
    empresa: d.empresa,
    responsavelNome: campanha.criadoPorNome || '',
  });

  // Template com variável vazia a Meta recusa inteiro. Pular antes de tentar
  // poupa uma recusa — e recusa em série é o que derruba a nota do número.
  if (variavelVazia(valores)) {
    await svc.entities.CampanhaDestinatario.update(d.id, {
      status: 'pulado',
      motivo: 'faltou dado para preencher a mensagem',
    }).catch(() => {});
    return 'pulado';
  }

  const conversa = await garantirConversa(svc, {
    telefone: d.telefone,
    numeroId: cfg.phoneNumberId,
  });
  if (!conversa?.id) {
    await svc.entities.CampanhaDestinatario.update(d.id, {
      status: 'falhou',
      motivo: 'não foi possível abrir a conversa',
      tentativas: (Number(d.tentativas) || 0) + 1,
    }).catch(() => {});
    return 'falhou';
  }

  const r = await enviarTemplate(
    cfg,
    d.telefone,
    campanha.templateNome,
    campanha.templateIdioma || 'pt_BR',
    valores,
  );

  const preview = `[${campanha.templateNome}] ${valores.join(' · ')}`.trim();

  // A mensagem entra na thread do cliente, como qualquer outra. É isto que
  // separa a campanha de um disparador externo: a resposta do cliente volta
  // para a caixa de entrada, com o histórico do que ele recebeu logo acima.
  const msg = await svc.entities.WhatsAppMensagem.create({
    conversaId: conversa.id,
    wamid: r.wamid || '',
    direcao: 'saida',
    tipo: 'template',
    texto: preview.slice(0, 4096),
    status: r.ok ? 'enviada' : 'falhou',
    ocorridoEm: agora,
    // Sem autor humano, e dizendo de qual campanha veio: quem abrir a thread
    // daqui a um mês precisa distinguir isto de uma mensagem do atendente.
    autorNome: `Campanha · ${campanha.nome}`,
    templateNome: campanha.templateNome,
    templateIdioma: campanha.templateIdioma || 'pt_BR',
    templateVariaveis: valores,
    metadados: { campanhaId: campanha.id, automatica: true, origem: 'campanha' },
    ...(r.ok ? {} : { erroCodigo: r.erroCodigo, erroMensagem: r.erroMensagem }),
  }).catch((e: any) => {
    console.error('CAMPANHA: mensagem não registrada.', e);
    return null;
  });

  if (r.ok) {
    await svc.entities.WhatsAppConversa.update(
      conversa.id,
      // De propósito NÃO reabre a janela de 24h: quem falou fomos nós. A janela
      // só volta a contar quando o cliente responde.
      resumoDeSaida({ tipo: 'template', texto: preview, ocorridoEm: agora }),
    ).catch(() => {});
  }

  await svc.entities.CampanhaDestinatario.update(d.id, {
    status: r.ok ? 'enviado' : 'falhou',
    motivo: r.ok ? '' : `a Meta recusou: ${r.erroMensagem || 'sem detalhe'}`,
    wamid: r.wamid || '',
    conversaId: conversa.id,
    mensagemId: msg?.id || '',
    enviadoEm: agora,
    tentativas: (Number(d.tentativas) || 0) + 1,
  }).catch(() => {});

  return r.ok ? 'enviado' : 'falhou';
}

/** Uma campanha: o que couber no teto de hoje, até o limite da rodada. */
async function rodarCampanha(svc: any, cfg: Config, campanha: any) {
  const liberada = podeDisparar(campanha);
  if (!liberada.ok) return { nome: campanha.nome, motivo: liberada.motivo, enviados: 0 };

  const agora = new Date();
  const vagasHoje = quantosCabemHoje(campanha, agora);
  if (!vagasHoje) return { nome: campanha.nome, motivo: 'teto do dia atingido', enviados: 0 };

  const pendentes = await svc.entities.CampanhaDestinatario
    .filter({ campanhaId: campanha.id, status: 'pendente' }).catch(() => []);

  const leva = proximaLeva(pendentes || [], Math.min(vagasHoje, LOTE_POR_RODADA));
  if (!leva.length) {
    // Sem pendente é fim de campanha — e só aqui, porque "sem pendente agora"
    // com teto batido é outra coisa, e já saiu acima.
    const aindaFalta = (pendentes || []).length > 0;
    if (!aindaFalta) {
      await svc.entities.CampanhaWhatsApp.update(campanha.id, {
        status: 'concluida',
        concluidaEm: agora.toISOString(),
      }).catch(() => {});
      return { nome: campanha.nome, motivo: 'concluída', enviados: 0 };
    }
    return { nome: campanha.nome, motivo: 'só restam linhas que esgotaram tentativas', enviados: 0 };
  }

  const placar = { enviado: 0, pulado: 0, falhou: 0 };
  for (const d of leva) {
    const r = await mandarPara(svc, cfg, campanha, d)
      .catch((e: any) => {
        console.error('CAMPANHA: falha ao mandar para', d?.id, e);
        return 'falhou' as const;
      });
    placar[r] += 1;
  }

  // A contagem do dia: some só o que REALMENTE saiu. Pulado não consome teto da
  // Meta — ninguém recebeu nada.
  const mesmoDia = campanha.diaDaContagem === diaUTC(agora);
  await svc.entities.CampanhaWhatsApp.update(campanha.id, {
    status: 'enviando',
    diaDaContagem: diaUTC(agora),
    enviadasHoje: (mesmoDia ? Number(campanha.enviadasHoje) || 0 : 0) + placar.enviado,
    totalEnviadas: (Number(campanha.totalEnviadas) || 0) + placar.enviado,
    totalFalhas: (Number(campanha.totalFalhas) || 0) + placar.falhou,
    totalPulados: (Number(campanha.totalPulados) || 0) + placar.pulado,
    ultimaRodadaEm: agora.toISOString(),
    ...(campanha.iniciadaEm ? {} : { iniciadaEm: agora.toISOString() }),
  }).catch((e: any) => console.error('CAMPANHA: placar não atualizado.', e));

  return { nome: campanha.nome, motivo: '', ...placar, enviados: placar.enviado };
}

Deno.serve(async (req: Request) => {
  const base44 = createClientFromRequest(req);
  const svc = base44.asServiceRole;
  const cfg = configDoAmbiente();

  if (!cfg.token || !cfg.phoneNumberId) {
    return Response.json({ ok: true, motivo: 'canal não configurado', campanhas: [] });
  }

  try {
    const todas = await svc.entities.CampanhaWhatsApp.list('-created_date', 100).catch(() => []);
    const ativas = (todas || []).filter((c: any) => ['aprovada', 'enviando'].includes(c.status));

    const rodadas = [];
    for (const c of ativas) {
      rodadas.push(await rodarCampanha(svc, cfg, c));
    }

    return Response.json({
      ok: true,
      campanhasAtivas: ativas.length,
      enviadosNestaRodada: rodadas.reduce((t, r: any) => t + (r.enviados || 0), 0),
      rodadas,
    });
  } catch (e: any) {
    console.error('CAMPANHA DISPARO: falha na rodada.', e);
    return Response.json({ ok: false, error: 'Falha ao rodar as campanhas.' }, { status: 500 });
  }
});
