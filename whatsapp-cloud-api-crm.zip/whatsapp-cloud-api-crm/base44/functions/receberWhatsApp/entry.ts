import { createClientFromRequest } from 'npm:@base44/sdk@0.8.48';
import {
  assinaturaConfere,
  baixarMidia,
  ehPedidoDeSaida,
  enviarTexto,
  extensaoDoMime,
  lerMensagem,
  normalizarTelefone,
  statusDaMeta,
  VERSAO_PADRAO,
  type Config,
} from '../../shared/whatsapp.ts';
import { garantirConversa, resumoDeEntrada } from '../../shared/whatsappConversa.ts';

// Webhook da WhatsApp Cloud API — a porta de ENTRADA do canal.
//
// A Meta chama esta função duas vezes por motivos bem diferentes:
//
//  GET  — handshake de verificação, uma vez, quando alguém salva a URL do
//         webhook no painel. Devolve o `hub.challenge` em texto puro.
//  POST — mensagens recebidas e confirmações de entrega das que enviamos.
//
// ── Por que esta função é pública, e o que a protege ────────────────────────
//
// Ela precisa aceitar chamada de fora sem sessão do Central: quem chama é a
// Meta. O que substitui a sessão é a assinatura `X-Hub-Signature-256`, um HMAC
// do corpo CRU com o app secret — conferida antes de qualquer parse, em tempo
// constante (`assinaturaConfere` em shared/whatsapp.ts). Sem o segredo
// configurado a função recusa tudo com 503: um webhook que aceita corpo não
// assinado é um formulário aberto para plantar mensagem falsa na caixa de
// entrada do atendimento.
//
// ── Reenvio ─────────────────────────────────────────────────────────────────
//
// A Meta REENVIA o lote inteiro quando não recebe 200, por horas. Toda mensagem
// é gravada com o `wamid` e a gravação confere antes se aquele `wamid` já
// existe: reenvio não duplica. É justamente por ser idempotente que esta função
// PODE devolver 500 quando não conseguiu gravar — o reenvio é a rede de
// segurança contra perder mensagem de cliente.
//
// Configuração e limites do canal: docs/whatsapp/PLANO.md.

/** Mídia acima disto fica sem cópia local — a mensagem entra assim mesmo. */
const MIDIA_BYTES_MAX = 20 * 1024 * 1024;

const texto = (v: unknown, max = 500) => String(v ?? '').slice(0, max);

function configDoAmbiente(): Config {
  return {
    token: Deno.env.get('WHATSAPP_ACCESS_TOKEN') || '',
    phoneNumberId: Deno.env.get('WHATSAPP_PHONE_NUMBER_ID') || '',
    versao: Deno.env.get('WHATSAPP_API_VERSION') || VERSAO_PADRAO,
  };
}

/**
 * Copia a mídia recebida para o armazenamento do app.
 *
 * A URL que a Meta devolve vale poucos minutos e exige o token — guardá-la
 * seria guardar um link morto. Falhar aqui NÃO derruba a mensagem: ela entra
 * com o motivo registrado, porque saber que o cliente mandou um arquivo (e qual
 * era) vale mais do que não ter mensagem nenhuma.
 */
async function copiarMidia(svc: any, cfg: Config, lida: any) {
  if (!lida.mediaId) return null;

  const baixada = await baixarMidia(cfg, lida.mediaId, MIDIA_BYTES_MAX);
  if (!baixada.ok || !baixada.bytes) {
    return {
      mediaId: lida.mediaId,
      nome: lida.midiaNome || '',
      mime: lida.midiaMime || '',
      erro: texto(baixada.motivo || 'não foi possível baixar o arquivo', 300),
    };
  }

  const mime = baixada.mime || lida.midiaMime || 'application/octet-stream';
  const nome = lida.midiaNome || `whatsapp-${lida.mediaId}.${extensaoDoMime(mime)}`;
  try {
    const arquivo = new File([baixada.bytes], nome, { type: mime });
    const { file_url } = await svc.integrations.Core.UploadFile({ file: arquivo });
    return { mediaId: lida.mediaId, nome, mime, tamanho: baixada.tamanho, url: file_url };
  } catch (e) {
    return {
      mediaId: lida.mediaId,
      nome,
      mime,
      erro: texto(`falha ao guardar o arquivo: ${(e as Error)?.message || e}`, 300),
    };
  }
}

/**
 * O cliente pedindo para não receber mais automação.
 *
 * Os templates automáticos terminam com "responda SAIR para não receber estes
 * avisos". Sem isto, aquela frase seria mentira — e uma promessa de descadastro
 * que não funciona é exatamente o que faz alguém denunciar o número em vez de
 * responder. Bloqueio por denúncia derruba a nota de qualidade e, repetido,
 * tira o número do ar.
 *
 * Desliga só a AUTOMAÇÃO. O atendimento humano continua: quem escreve "sair"
 * está recusando aviso automático, não pedindo para a empresa parar de
 * responder quando ele mesmo chamar.
 */
async function tratarPedidoDeSaida(
  svc: any,
  cfg: Config,
  { conversa, texto: corpo }: { conversa: any; texto: string },
) {
  if (!ehPedidoDeSaida(corpo)) return false;

  // Cliente e prospect valem igual. Prospect é justamente quem mais recebe
  // campanha, e um "SAIR" que só funcionasse para cliente seria a promessa do
  // rodapé mentindo para metade de quem a lê.
  const entidade = conversa?.vinculoTipo === 'cliente'
    ? 'Cliente'
    : conversa?.vinculoTipo === 'prospect'
      ? 'Prospect'
      : '';
  if (!entidade || !conversa?.vinculoId) return false;

  const cadastro = (await svc.entities[entidade].filter({ id: conversa.vinculoId }).catch(() => []))[0];
  if (!cadastro || cadastro.whatsappOptOut === true) return false;

  await svc.entities[entidade].update(cadastro.id, { whatsappOptOut: true })
    .catch((e: any) => console.error('WHATSAPP: não foi possível registrar o opt-out.', e));

  // A confirmação sai como texto livre, e não como template: o cliente acabou
  // de escrever, então a janela de 24h está aberta e isto não custa nada.
  // Silêncio depois de um "SAIR" faz a pessoa repetir — ou denunciar.
  const aviso = 'Pronto: você não vai mais receber avisos automáticos nossos por aqui. '
    + 'Se precisar de algo, é só escrever — continuamos respondendo normalmente.';
  const r = await enviarTexto(cfg, conversa.telefone, aviso);

  await svc.entities.WhatsAppMensagem.create({
    conversaId: conversa.id,
    wamid: r.wamid || '',
    direcao: 'saida',
    tipo: 'texto',
    texto: aviso,
    status: r.ok ? 'enviada' : 'falhou',
    ocorridoEm: new Date().toISOString(),
    autorNome: 'Automação · opt-out',
    metadados: { fato: `optout:${cadastro.id}`, origem: 'opt-out', automatica: true },
  }).catch(() => {});

  return true;
}

/** Uma mensagem recebida: grava (se ainda não existir) e atualiza a conversa. */
async function processarEntrada(
  svc: any,
  cfg: Config,
  { msg, numeroId, nomePerfil }: { msg: any; numeroId: string; nomePerfil: string },
) {
  const lida = lerMensagem(msg);
  const telefone = normalizarTelefone(lida.telefone) || lida.telefone.replace(/\D/g, '');
  if (!telefone || !lida.wamid) return 'ignorada';

  // Idempotência: o reenvio do lote encontra a mensagem já gravada e para aqui.
  const jaExiste = await svc.entities.WhatsAppMensagem
    .filter({ wamid: lida.wamid }).catch(() => []);
  if (jaExiste?.length) return 'repetida';

  const conversa = await garantirConversa(svc, { telefone, numeroId, nomePerfil });
  if (!conversa?.id) throw new Error('não foi possível abrir a conversa');

  const midia = await copiarMidia(svc, cfg, lida);

  await svc.entities.WhatsAppMensagem.create({
    conversaId: conversa.id,
    wamid: lida.wamid,
    direcao: 'entrada',
    tipo: lida.tipo,
    texto: texto(lida.texto, 4096),
    status: 'recebida',
    ocorridoEm: lida.ocorridoEm,
    respondendoAWamid: lida.respondendoAWamid,
    ...(midia ? { midia } : {}),
    ...(Object.keys(lida.metadados || {}).length ? { metadados: lida.metadados } : {}),
  });

  // A janela de 24h reabre dentro de `resumoDeEntrada` — ver o porquê lá.
  await svc.entities.WhatsAppConversa.update(
    conversa.id,
    resumoDeEntrada(conversa, {
      tipo: lida.tipo,
      texto: lida.texto,
      ocorridoEm: lida.ocorridoEm,
      nomePerfil,
    }),
  );

  // Depois de gravar, e não antes: o pedido de saída faz parte do histórico da
  // conversa, e quem for conferir depois precisa ver o que o cliente escreveu.
  if (lida.tipo === 'texto') {
    await tratarPedidoDeSaida(svc, cfg, { conversa, texto: lida.texto })
      .catch((e) => console.error('WHATSAPP: falha ao tratar pedido de saída.', e));
  }

  return 'gravada';
}

/**
 * Confirmação de entrega de uma mensagem NOSSA.
 *
 * Só avança o status — de "enviada" não se volta para "pendente" —, porque a
 * ordem de chegada dos eventos não é garantida: `read` pode chegar antes de
 * `delivered`, e nesse caso deixar `read` sobrescrever seria perder a leitura.
 */
const ORDEM_STATUS = ['pendente', 'enviada', 'entregue', 'lida'];

async function processarStatus(svc: any, st: any) {
  const wamid = texto(st?.id, 200);
  const novo = statusDaMeta(st?.status);
  if (!wamid || !novo) return 'ignorada';

  const achadas = await svc.entities.WhatsAppMensagem.filter({ wamid }).catch(() => []);
  const msg = achadas?.[0];
  if (!msg) return 'ignorada';

  const quando = st?.timestamp
    ? new Date(Number(st.timestamp) * 1000).toISOString()
    : new Date().toISOString();

  const patch: Record<string, unknown> = {};
  if (novo === 'falhou') {
    const erro = st?.errors?.[0] || {};
    patch.status = 'falhou';
    patch.erroCodigo = texto(erro.code ?? '', 40);
    patch.erroMensagem = texto(erro.error_data?.details || erro.title || erro.message || '', 500);
  } else {
    const atual = ORDEM_STATUS.indexOf(String(msg.status || 'pendente'));
    if (ORDEM_STATUS.indexOf(novo) > atual) patch.status = novo;
    if (novo === 'entregue' && !msg.entregueEm) patch.entregueEm = quando;
    if (novo === 'lida' && !msg.lidaEm) patch.lidaEm = quando;
  }

  // A categoria cobrada vem no status, e é o que permite conferir a fatura.
  if (st?.conversation || st?.pricing) {
    patch.metadados = {
      ...(msg.metadados || {}),
      conversaCategoria: st?.conversation?.origin?.type || '',
      cobranca: st?.pricing || {},
    };
  }

  if (Object.keys(patch).length) await svc.entities.WhatsAppMensagem.update(msg.id, patch);
  return 'atualizada';
}

Deno.serve(async (req: Request) => {
  const url = new URL(req.url);

  // ── Handshake de verificação ──────────────────────────────────────────────
  if (req.method === 'GET') {
    const verifyToken = Deno.env.get('WHATSAPP_VERIFY_TOKEN') || '';
    const modo = url.searchParams.get('hub.mode');
    const recebido = url.searchParams.get('hub.verify_token');
    const desafio = url.searchParams.get('hub.challenge') || '';
    if (verifyToken && modo === 'subscribe' && recebido === verifyToken) {
      // Texto puro, sem JSON: é o que o painel da Meta espera receber de volta.
      return new Response(desafio, { status: 200, headers: { 'content-type': 'text/plain' } });
    }
    return new Response('Forbidden', { status: 403 });
  }

  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  try {
    // Portaria de segredo: o corpo CRU, antes de qualquer parse — reserializar
    // muda espaços e ordem e derruba a conferência da assinatura.
    const corpoCru = await req.text();
    const appSecret = Deno.env.get('WHATSAPP_APP_SECRET') || '';
    if (!appSecret) {
      return Response.json({ error: 'WHATSAPP_APP_SECRET não configurado' }, { status: 503 });
    }
    // O nome do cabeçalho aparece aqui de propósito, e é a marca que
    // scripts/verificarPortarias.mjs procura: x-hub-signature-256.
    const assinatura = req.headers.get('x-hub-signature-256');
    if (!(await assinaturaConfere(corpoCru, assinatura, appSecret))) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    let corpo: any;
    try {
      corpo = JSON.parse(corpoCru);
    } catch {
      return Response.json({ error: 'Corpo inválido' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);
    const svc = base44.asServiceRole;
    const cfg = configDoAmbiente();

    let gravadas = 0;
    let repetidas = 0;
    let status = 0;
    let deOutroNumero = 0;
    const falhas: string[] = [];

    for (const entrada of corpo?.entry || []) {
      for (const mudanca of entrada?.changes || []) {
        if (mudanca?.field !== 'messages') continue;
        const valor = mudanca?.value || {};
        const numeroId = texto(valor?.metadata?.phone_number_id, 100);

        // SÓ O NOSSO NÚMERO.
        //
        // O webhook é assinado por WABA, e não por número: se a mesma conta do
        // WhatsApp Business tiver outros números — um deles atendido por outra
        // ferramenta —, as mensagens DELES chegam aqui também. Sem este filtro o
        // Central abriria conversas de um atendimento que não é dele e, pior,
        // responderia por `WHATSAPP_PHONE_NUMBER_ID`, ou seja, pelo número
        // errado: o cliente escreveria para um número e seria respondido por
        // outro.
        //
        // Sem a variável configurada nada é filtrado — é o estado de quem ainda
        // está montando o canal, e aí é melhor ver tudo chegar do que depurar um
        // silêncio.
        if (cfg.phoneNumberId && numeroId && numeroId !== cfg.phoneNumberId) {
          deOutroNumero += (valor?.messages || []).length + (valor?.statuses || []).length;
          continue;
        }

        // O nome do perfil vem uma vez por lote, fora das mensagens.
        const nomes = new Map<string, string>();
        for (const c of valor?.contacts || []) {
          if (c?.wa_id) nomes.set(String(c.wa_id), String(c?.profile?.name || ''));
        }

        for (const msg of valor?.messages || []) {
          try {
            const r = await processarEntrada(svc, cfg, {
              msg,
              numeroId,
              nomePerfil: nomes.get(String(msg?.from)) || '',
            });
            if (r === 'gravada') gravadas++;
            if (r === 'repetida') repetidas++;
          } catch (e) {
            console.error('WHATSAPP: falha ao gravar mensagem recebida.', e);
            falhas.push(texto((e as Error)?.message || e, 200));
          }
        }

        for (const st of valor?.statuses || []) {
          try {
            if ((await processarStatus(svc, st)) === 'atualizada') status++;
          } catch (e) {
            // Status perdido é um tique que não aparece; mensagem perdida é
            // cliente sem resposta. Só o segundo caso pede reenvio.
            console.error('WHATSAPP: falha ao aplicar status.', e);
          }
        }
      }
    }

    if (falhas.length) {
      // 500 pede o reenvio do lote; o `wamid` garante que o que já entrou não
      // entra de novo.
      return Response.json({ error: 'Falha ao gravar', detalhe: falhas, gravadas }, { status: 500 });
    }

    return Response.json({ ok: true, gravadas, repetidas, status, deOutroNumero });
  } catch (e) {
    console.error('WHATSAPP: erro no webhook.', e);
    return Response.json({ error: (e as Error)?.message || 'erro' }, { status: 500 });
  }
});
