import { createClientFromRequest } from 'npm:@base44/sdk@0.8.48';
import {
  enviarMidiaPorLink,
  enviarTemplate,
  enviarTexto,
  janelaAberta,
  normalizarTelefone,
  urlDeMidiaValida,
  VERSAO_PADRAO,
  type Config,
} from '../../shared/whatsapp.ts';
import { garantirConversa, resumoDeSaida } from '../../shared/whatsappConversa.ts';
import { alcanceDoUsuario, podeVerConversa } from '../../shared/whatsappAcesso.ts';

// Envio de WhatsApp pela Cloud API — a porta de SAÍDA do canal.
//
// Tudo que sai do Central para o WhatsApp de um cliente passa por aqui: a
// resposta que o atendente digita na caixa de entrada e o template que reabre
// uma conversa vencida. O registro da mensagem é gravado tenha ela saído ou
// não — uma tentativa que a Meta recusou é informação de atendimento, não lixo:
// é ela que explica por que o cliente não respondeu.
//
// ── A regra que manda no desenho ────────────────────────────────────────────
//
// Dentro de 24h contadas da ÚLTIMA mensagem DO CLIENTE, texto livre passa. Fora
// disso, a Meta recusa qualquer coisa que não seja um template aprovado por
// ela. Esta função confere a janela ANTES de chamar a Meta e devolve
// `codigo: "janela_fechada"`, para a tela poder oferecer o template em vez de
// mostrar um "falhou" que não explica nada.
//
// Configuração, segredos e limites: docs/whatsapp/PLANO.md.

const texto = (v: unknown, max = 4096) => String(v ?? '').slice(0, max);

const TIPOS_MIDIA = ['image', 'document', 'audio', 'video'] as const;

// ── Auditoria ───────────────────────────────────────────────────────────────
//
// Mensagem para fora da empresa entra na trilha, como já entram o e-mail do
// diagnóstico e os envios ao CRM.
async function auditar(base44: any, req: Request, dados: Record<string, unknown>) {
  try {
    const h = req.headers;
    const fwd = h.get('x-forwarded-for') || '';
    await base44.asServiceRole.functions.invoke('registrarAuditoria', {
      modulo: 'integracoes',
      ...dados,
      segredoInterno: Deno.env.get('AUDITORIA_SEGREDO_INTERNO') || '',
      ipOrigem: (fwd.split(',')[0] || '').trim() || h.get('cf-connecting-ip') || h.get('x-real-ip') || '',
      userAgentOrigem: String(h.get('user-agent') || '').slice(0, 300),
    });
  } catch (e) {
    console.error('AUDITORIA: falha ao registrar envio de WhatsApp.', e);
  }
}

/**
 * Portaria: só quem tem sessão no Central chama esta função.
 *
 * As funções do Base44 são endpoints HTTP abertos: sem esta checagem, qualquer
 * pessoa que descubra a URL manda WhatsApp em nome da empresa — e o número da
 * empresa é o que a Meta pune quando isso vira denúncia.
 *
 * Três identidades são aceitas, na mesma ordem do resto do sistema:
 *  1. SESSÃO VALIDADA NO SERVIDOR (`sessaoToken` emitido por `abrirSessao`);
 *  2. sessão do próprio Base44 (`auth.me()`, que LANÇA quando não há sessão);
 *  3. o `loginAcessoId` do localStorage, conferido contra o cadastro e só
 *     enquanto a conta nunca tiver aberto sessão no servidor.
 */
const passa = (usuario: any) => ({ ok: true, status: 200, motivo: '', usuario });
const barra = (status: number, motivo: string) => ({ ok: false, status, motivo, usuario: null });

async function shaHex(t: string): Promise<string> {
  const d = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t));
  return Array.from(new Uint8Array(d)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function exigirUsuario(base44: any, body: any) {
  const ents = base44.asServiceRole.entities;

  const token = String(body?.sessaoToken || '').trim();
  if (/^[0-9a-f]{64}$/.test(token)) {
    const dono = (await ents.UsuarioSistema
      .filter({ sessaoTokenHash: await shaHex(token) }).catch(() => []))[0];
    if (dono && dono.status === 'ativo' && Date.parse(dono.sessaoExpira || '') > Date.now()) {
      return passa(dono);
    }
  }

  try {
    const me = await base44.auth.me();
    const email = me?.email ? String(me.email).trim().toLowerCase() : '';
    if (email) {
      const u = (await ents.UsuarioSistema.filter({ email }).catch(() => []))[0];
      if (u && u.status === 'ativo') return passa(u);
    }
    if (me?.id) return passa(null);
  } catch { /* sem sessão Base44 — cai na identidade declarada */ }

  const id = String(body?.loginAcessoId || '').trim().slice(0, 100);
  if (!id) return barra(401, 'Não autenticado.');
  const u = (await ents.UsuarioSistema.filter({ id }).catch(() => []))[0];
  if (!u) return barra(403, 'Sessão inválida.');
  if (u.status !== 'ativo') return barra(403, 'Usuário inativo.');
  if (u.sessaoServidorDesde) return barra(401, 'Sessão expirada. Entre de novo.');
  return passa(u);
}

// ── Envio ───────────────────────────────────────────────────────────────────

function configDoAmbiente(): Config {
  return {
    token: Deno.env.get('WHATSAPP_ACCESS_TOKEN') || '',
    phoneNumberId: Deno.env.get('WHATSAPP_PHONE_NUMBER_ID') || '',
    versao: Deno.env.get('WHATSAPP_API_VERSION') || VERSAO_PADRAO,
  };
}

/**
 * O template a disparar, já conferido.
 *
 * Um template que existe no Central mas não foi aprovado pela Meta seria
 * recusado por ela com um erro genérico. Barrar aqui, com o motivo escrito,
 * poupa a viagem e diz o que fazer: cadastrar o nome aprovado.
 */
async function resolverTemplate(svc: any, body: any) {
  if (body?.templateId) {
    const t = (await svc.entities.TemplatesMensagem
      .filter({ id: String(body.templateId) }).catch(() => []))[0];
    if (!t) return { erro: 'Template não encontrado.', codigo: 'template_inexistente' };
    if (!t.metaNome) {
      return {
        erro: 'Este template não tem nome aprovado na Meta e por isso não pode ser disparado fora da janela de 24h.',
        codigo: 'template_sem_meta',
      };
    }
    if (t.metaStatus && t.metaStatus !== 'aprovado') {
      return { erro: `Template com situação "${t.metaStatus}" na Meta.`, codigo: 'template_nao_aprovado' };
    }
    return { nome: String(t.metaNome), idioma: String(t.metaIdioma || 'pt_BR'), titulo: String(t.titulo || '') };
  }

  if (body?.templateNome) {
    return {
      nome: String(body.templateNome),
      idioma: String(body.templateIdioma || 'pt_BR'),
      titulo: String(body.templateNome),
    };
  }
  return null;
}

Deno.serve(async (req: Request) => {
  try {
    if (req.method !== 'POST') {
      return Response.json({ error: 'Method not allowed' }, { status: 405 });
    }

    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));

    const porta = await exigirUsuario(base44, body);
    if (!porta.ok) return Response.json({ error: porta.motivo }, { status: porta.status });

    const svc = base44.asServiceRole;
    const cfg = configDoAmbiente();
    if (!cfg.token || !cfg.phoneNumberId) {
      return Response.json(
        {
          error: 'Canal do WhatsApp não configurado (WHATSAPP_ACCESS_TOKEN / WHATSAPP_PHONE_NUMBER_ID).',
          codigo: 'nao_configurado',
        },
        { status: 503 },
      );
    }

    // ── Para quem ───────────────────────────────────────────────────────────
    //
    // A mesma regra de alcance da caixa de entrada vale para o envio: sem isto,
    // quem não enxerga a conversa na lista ainda poderia escrever nela — e a
    // mensagem sairia em nome da empresa para o cliente de outro consultor.
    const alcance = await alcanceDoUsuario(svc, porta.usuario);

    let conversa: any = null;
    if (body?.conversaId) {
      conversa = (await svc.entities.WhatsAppConversa
        .filter({ id: String(body.conversaId) }).catch(() => []))[0];
      // "Não encontrada" também para quem não alcança: ver shared/whatsappAcesso.ts.
      if (!conversa || !podeVerConversa(conversa, alcance)) {
        return Response.json({ error: 'Conversa não encontrada.' }, { status: 404 });
      }
    } else {
      const telefone = normalizarTelefone(body?.telefone);
      if (!telefone) {
        return Response.json(
          {
            error: 'Telefone inválido. Use DDD + número, ou "+" com o código do país.',
            codigo: 'telefone_invalido',
          },
          { status: 400 },
        );
      }
      conversa = await garantirConversa(svc, { telefone, numeroId: cfg.phoneNumberId });
      if (!conversa?.id) return Response.json({ error: 'Não foi possível abrir a conversa.' }, { status: 500 });
      if (!podeVerConversa(conversa, alcance)) {
        return Response.json(
          { error: 'Este número é de um cliente sob responsabilidade de outra pessoa.', codigo: 'fora_do_alcance' },
          { status: 403 },
        );
      }
    }

    // ── O que mandar ────────────────────────────────────────────────────────
    const template = await resolverTemplate(svc, body);
    if (template && 'erro' in template) {
      return Response.json({ error: template.erro, codigo: template.codigo }, { status: 400 });
    }

    const corpo = texto(body?.texto);
    const midia = body?.midia && body.midia.url ? body.midia : null;
    if (!template && !corpo && !midia) {
      return Response.json({ error: 'Nada a enviar.' }, { status: 400 });
    }

    // A URL da mídia vem do corpo da requisição e a mensagem é gravada mesmo
    // quando a Meta recusa o envio — então uma URL com esquema perigoso ficaria
    // guardada e viraria `href` na thread de quem abrir a conversa depois.
    // Barrar aqui é o que impede que a recusa da Meta seja contornada.
    if (midia && !urlDeMidiaValida(midia.url)) {
      return Response.json(
        { error: 'A mídia precisa estar num endereço https.', codigo: 'midia_invalida' },
        { status: 400 },
      );
    }

    // A JANELA. Conferida antes de chamar a Meta, para o erro dizer o que fazer.
    if (!template && !janelaAberta(conversa.janelaExpiraEm)) {
      return Response.json(
        {
          error: 'A janela de 24h desta conversa fechou. Só um template aprovado reabre o contato.',
          codigo: 'janela_fechada',
          janelaExpiraEm: conversa.janelaExpiraEm || null,
        },
        { status: 409 },
      );
    }

    // ── Manda ───────────────────────────────────────────────────────────────
    const variaveis: string[] = Array.isArray(body?.variaveis)
      ? body.variaveis.map((v: unknown) => String(v ?? '').slice(0, 500))
      : [];

    let resultado;
    let tipoRegistro = 'texto';
    if (template) {
      tipoRegistro = 'template';
      resultado = await enviarTemplate(cfg, conversa.telefone, template.nome!, template.idioma!, variaveis);
    } else if (midia) {
      const tipoMidia = TIPOS_MIDIA.includes(midia.tipo) ? midia.tipo : 'document';
      tipoRegistro = { image: 'imagem', document: 'documento', audio: 'audio', video: 'video' }[tipoMidia]!;
      resultado = await enviarMidiaPorLink(
        cfg,
        conversa.telefone,
        tipoMidia,
        String(midia.url),
        corpo,
        String(midia.nome || ''),
      );
    } else {
      resultado = await enviarTexto(cfg, conversa.telefone, corpo, String(body?.respondendoAWamid || ''));
    }

    // ── Registra, tenha saído ou não ────────────────────────────────────────
    const agora = new Date().toISOString();
    const preview = template
      ? `[${template.titulo || template.nome}] ${corpo}`.trim()
      : corpo;

    const registro = await svc.entities.WhatsAppMensagem.create({
      conversaId: conversa.id,
      wamid: resultado.wamid || '',
      direcao: 'saida',
      tipo: tipoRegistro,
      texto: texto(preview),
      status: resultado.ok ? 'enviada' : 'falhou',
      ocorridoEm: agora,
      autorUserId: porta.usuario?.id || '',
      autorNome: String(porta.usuario?.nome || ''),
      respondendoAWamid: String(body?.respondendoAWamid || ''),
      ...(template ? { templateNome: template.nome, templateIdioma: template.idioma, templateVariaveis: variaveis } : {}),
      ...(midia ? { midia: { url: String(midia.url), nome: String(midia.nome || ''), mime: String(midia.mime || '') } } : {}),
      ...(resultado.ok ? {} : { erroCodigo: resultado.erroCodigo, erroMensagem: resultado.erroMensagem }),
    }).catch((e: any) => {
      console.error('WHATSAPP: mensagem enviada mas não registrada.', e);
      return null;
    });

    if (resultado.ok) {
      await svc.entities.WhatsAppConversa.update(
        conversa.id,
        resumoDeSaida({ tipo: tipoRegistro, texto: preview, ocorridoEm: agora }),
      ).catch(() => {});
    }

    await auditar(base44, req, {
      acao: resultado.ok ? 'criar' : 'atualizar',
      submodulo: 'whatsapp',
      entidade: 'WhatsAppMensagem',
      entidadeId: registro?.id || '',
      descricao: resultado.ok
        ? `WhatsApp enviado para ${conversa.telefoneExibicao || conversa.telefone}${template ? ` (template ${template.nome})` : ''}`
        : `Falha ao enviar WhatsApp para ${conversa.telefoneExibicao || conversa.telefone}: ${resultado.erroMensagem}`,
      origem: 'funcao',
      usuarioId: porta.usuario?.id || 'sistema',
      usuarioNome: porta.usuario?.nome || '',
      metadados: { conversaId: conversa.id, template: template?.nome || '', wamid: resultado.wamid || '' },
    });

    if (!resultado.ok) {
      return Response.json(
        {
          error: resultado.erroMensagem || 'A Meta recusou a mensagem.',
          codigo: 'recusada_pela_meta',
          erroCodigo: resultado.erroCodigo,
          mensagemId: registro?.id || null,
        },
        { status: 502 },
      );
    }

    return Response.json({
      ok: true,
      conversaId: conversa.id,
      mensagemId: registro?.id || null,
      wamid: resultado.wamid,
      enviadaEm: agora,
    });
  } catch (e) {
    console.error('WHATSAPP: erro no envio.', e);
    return Response.json({ error: (e as Error)?.message || 'erro' }, { status: 500 });
  }
});
