import { createClientFromRequest } from 'npm:@base44/sdk@0.8.48';
import {
  montarDestinatarios,
  resolverVariaveis,
  variavelVazia,
  type Cadastro,
} from '../../shared/whatsappCampanha.ts';
import { ehAdminSistema } from '../../shared/whatsappAcesso.ts';

// Gestão das campanhas de WhatsApp — montar, submeter, aprovar, acompanhar.
//
// O ENVIO NÃO ACONTECE AQUI. Esta função só mexe em registro; quem fala com a
// Meta é `campanhaWhatsAppDisparo`, no seu próprio ritmo. A separação é o que
// permite aprovar uma campanha de 2.000 pessoas num clique sem a requisição
// ficar dez minutos aberta — e o que garante que fechar a aba no meio não
// deixa metade da lista sem mandar.
//
// ── Quem faz o quê ──────────────────────────────────────────────────────────
//
// O CONSULTOR monta: cria, escolhe o template, acrescenta gente das telas de
// Clientes e Prospects, e submete. Enquanto está em rascunho nada sai.
//
// O ADMINISTRADOR aprova. É a única ação com `ehAdminSistema` — e a aprovação
// grava QUEM aprovou, não só um status. `campanhaWhatsAppDisparo` confere o
// `aprovadoPorUserId`, porque status é campo que qualquer caminho futuro pode
// escrever e assinatura não se põe por acidente.
//
// ── O que o consultor alcança ───────────────────────────────────────────────
//
// As campanhas que ele criou. Admin alcança todas. Diferente da caixa de
// entrada, o alcance aqui não é por carteira de cliente: uma campanha é um
// objeto de trabalho de quem a montou, e a lista de destinatários dela pode
// misturar clientes de vários responsáveis.
//
// Desenho do canal e das travas: docs/whatsapp/PLANO.md.

const texto = (v: unknown, max = 500) => String(v ?? '').slice(0, max);

const LIMITE_CAMPANHAS = 100;
const LIMITE_DESTINATARIOS = 500;

/** Teto de gente que entra numa campanha de uma vez, para a requisição não estourar. */
const MAXIMO_POR_SELECAO = 1000;

// ── Portaria de usuário ─────────────────────────────────────────────────────
//
// Mesma das outras funções do canal: token de sessão do servidor, sessão do
// Base44, ou identidade declarada conferida contra o UsuarioSistema.

const passa = (usuario: any) => ({ ok: true, status: 200, motivo: '', usuario });
const barra = (status: number, motivo: string) => ({ ok: false, status, motivo, usuario: null });

async function shaHex(t: string): Promise<string> {
  const d = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t));
  return Array.from(new Uint8Array(d)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function exigirUsuario(base44: any, body: any) {
  const ents = base44.asServiceRole.entities;

  const token = String(body?.sessaoToken || '').trim();
  if (/^[0-9a-f]{64}$/.test(token)) {
    const dono = (await ents.UsuarioSistema
      .filter({ sessaoTokenHash: await shaHex(token) }).catch(() => []))[0];
    if (dono && dono.status === 'ativo' && Date.parse(dono.sessaoExpira || '') > Date.now()) {
      return passa(dono);
    }
  }

  try {
    const me = await base44.auth.me();
    const email = me?.email ? String(me.email).trim().toLowerCase() : '';
    if (email) {
      const u = (await ents.UsuarioSistema.filter({ email }).catch(() => []))[0];
      if (u && u.status === 'ativo') return passa(u);
    }
    if (me?.id) return passa(null);
  } catch { /* sem sessão Base44 — cai na identidade declarada */ }

  const id = String(body?.loginAcessoId || '').trim().slice(0, 100);
  if (!id) return barra(401, 'Não autenticado.');
  const u = (await ents.UsuarioSistema.filter({ id }).catch(() => []))[0];
  if (!u) return barra(403, 'Sessão inválida.');
  if (u.status !== 'ativo') return barra(403, 'Usuário inativo.');
  if (u.sessaoServidorDesde) return barra(401, 'Sessão expirada. Entre de novo.');
  return passa(u);
}

// ── Formatos de saída ───────────────────────────────────────────────────────

const campanhaParaTela = (c: any) => ({
  id: c.id,
  nome: c.nome || '',
  descricao: c.descricao || '',
  finalidade: c.finalidade || 'aviso',
  status: c.status || 'rascunho',
  templateId: c.templateId || '',
  templateNome: c.templateNome || '',
  templateIdioma: c.templateIdioma || 'pt_BR',
  variaveis: Array.isArray(c.variaveis) ? c.variaveis : [],
  criadoPorUserId: c.criadoPorUserId || '',
  criadoPorNome: c.criadoPorNome || '',
  aprovadoPorNome: c.aprovadoPorNome || '',
  aprovadaEm: c.aprovadaEm || '',
  motivoDecisao: c.motivoDecisao || '',
  limiteDiario: Number(c.limiteDiario) || 200,
  enviadasHoje: Number(c.enviadasHoje) || 0,
  totalDestinatarios: Number(c.totalDestinatarios) || 0,
  totalEnviadas: Number(c.totalEnviadas) || 0,
  totalFalhas: Number(c.totalFalhas) || 0,
  totalPulados: Number(c.totalPulados) || 0,
  iniciadaEm: c.iniciadaEm || '',
  concluidaEm: c.concluidaEm || '',
  ultimaRodadaEm: c.ultimaRodadaEm || '',
  criadaEm: c.created_date || '',
});

const destinatarioParaTela = (d: any) => ({
  id: d.id,
  tipo: d.tipo || 'cliente',
  alvoId: d.alvoId || '',
  nome: d.nome || '',
  empresa: d.empresa || '',
  telefone: d.telefone || '',
  status: d.status || 'pendente',
  motivo: d.motivo || '',
  conversaId: d.conversaId || '',
  enviadoEm: d.enviadoEm || '',
});

// ── Alcance ─────────────────────────────────────────────────────────────────

/**
 * A campanha, se este usuário a alcança. `null` tanto para inexistente quanto
 * para fora de alcance: dizer "existe mas não é sua" já entrega que ela existe.
 */
async function campanhaDoCorpo(svc: any, body: any, usuario: any, admin: boolean) {
  const id = texto(body?.campanhaId, 100);
  if (!id) return null;
  const c = (await svc.entities.CampanhaWhatsApp.filter({ id }).catch(() => []))[0];
  if (!c) return null;
  if (admin) return c;
  return c.criadoPorUserId && c.criadoPorUserId === usuario?.id ? c : null;
}

/** Recontagem a partir das linhas, que são a verdade — o placar é só cache. */
async function recontar(svc: any, campanhaId: string) {
  const linhas = await svc.entities.CampanhaDestinatario
    .filter({ campanhaId }).catch(() => []);
  const conta = (s: string) => (linhas || []).filter((d: any) => d.status === s).length;
  return {
    totalDestinatarios: (linhas || []).length,
    totalEnviadas: conta('enviado') + conta('entregue') + conta('lido'),
    totalFalhas: conta('falhou'),
    totalPulados: conta('pulado'),
    pendentes: conta('pendente'),
  };
}

Deno.serve(async (req: Request) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  let body: any = {};
  try { body = await req.json(); } catch { /* corpo vazio vira ação inválida */ }

  const base44 = createClientFromRequest(req);
  const porta = await exigirUsuario(base44, body);
  if (!porta.ok) return Response.json({ error: porta.motivo }, { status: porta.status });

  const usuario = porta.usuario;
  const admin = ehAdminSistema(usuario);
  const svc = base44.asServiceRole;
  const acao = texto(body?.acao, 60);

  try {
    switch (acao) {
      // ── Leitura ───────────────────────────────────────────────────────────

      case 'listar': {
        const todas = await svc.entities.CampanhaWhatsApp
          .list('-created_date', LIMITE_CAMPANHAS).catch(() => []);
        const minhas = admin
          ? todas
          : (todas || []).filter((c: any) => c.criadoPorUserId === usuario?.id);
        return Response.json({
          campanhas: (minhas || []).map(campanhaParaTela),
          // A fila de aprovação só existe para quem pode aprovar. Mostrar o
          // número para quem não pode agir sobre ele é ruído.
          aguardandoAprovacao: admin
            ? (todas || []).filter((c: any) => c.status === 'aguardando_aprovacao').length
            : 0,
          souAdmin: admin,
        });
      }

      case 'detalhe': {
        const c = await campanhaDoCorpo(svc, body, usuario, admin);
        if (!c) return Response.json({ error: 'Campanha não encontrada.' }, { status: 404 });
        const linhas = await svc.entities.CampanhaDestinatario
          .filter({ campanhaId: c.id }).catch(() => []);
        return Response.json({
          campanha: campanhaParaTela(c),
          destinatarios: (linhas || []).slice(0, LIMITE_DESTINATARIOS).map(destinatarioParaTela),
          totalLinhas: (linhas || []).length,
          souAdmin: admin,
        });
      }

      case 'listar_templates': {
        // Só os aprovados: campanha é sempre fora da janela de 24h, e ali a
        // Meta não aceita nada que não seja template aprovado por ela.
        const ts = await svc.entities.TemplatesMensagem
          .filter({ tipo: 'whatsapp', ativo: true }).catch(() => []);
        return Response.json({
          templates: (ts || [])
            .filter((t: any) => t.metaNome && (!t.metaStatus || t.metaStatus === 'aprovado'))
            .map((t: any) => ({
              id: t.id,
              titulo: t.titulo || t.metaNome,
              metaNome: t.metaNome,
              metaIdioma: t.metaIdioma || 'pt_BR',
              metaVariaveis: Array.isArray(t.metaVariaveis) ? t.metaVariaveis : [],
              conteudo: texto(t.conteudo, 2000),
            })),
        });
      }

      // ── Montagem ──────────────────────────────────────────────────────────

      case 'criar': {
        const nome = texto(body?.nome, 200).trim();
        if (!nome) return Response.json({ error: 'Dê um nome à campanha.' }, { status: 400 });

        const criada = await svc.entities.CampanhaWhatsApp.create({
          nome,
          descricao: texto(body?.descricao, 2000),
          finalidade: body?.finalidade === 'marketing' ? 'marketing' : 'aviso',
          status: 'rascunho',
          // Autoria vem da SESSÃO, nunca do corpo: é ela que decide o alcance.
          criadoPorUserId: usuario?.id || '',
          criadoPorNome: usuario?.nome || usuario?.email || '',
          limiteDiario: 200,
          totalDestinatarios: 0,
          totalEnviadas: 0,
          totalFalhas: 0,
          totalPulados: 0,
        });
        return Response.json({ campanha: campanhaParaTela(criada) });
      }

      case 'editar': {
        const c = await campanhaDoCorpo(svc, body, usuario, admin);
        if (!c) return Response.json({ error: 'Campanha não encontrada.' }, { status: 404 });
        if (c.status !== 'rascunho') {
          return Response.json(
            { error: 'Só rascunho pode ser editado.', codigo: 'nao_e_rascunho' },
            { status: 409 },
          );
        }

        const patch: Record<string, unknown> = {};
        if (body?.nome !== undefined) patch.nome = texto(body.nome, 200);
        if (body?.descricao !== undefined) patch.descricao = texto(body.descricao, 2000);
        if (body?.finalidade !== undefined) {
          patch.finalidade = body.finalidade === 'marketing' ? 'marketing' : 'aviso';
        }
        if (body?.limiteDiario !== undefined) {
          const n = Math.floor(Number(body.limiteDiario));
          // Teto do teto: acima do degrau da Meta o excedente vira recusa em
          // rajada, que é justamente o que derruba a nota de qualidade.
          patch.limiteDiario = Number.isFinite(n) && n > 0 ? Math.min(n, 1000) : 200;
        }
        if (body?.templateId !== undefined) {
          const t = (await svc.entities.TemplatesMensagem
            .filter({ id: texto(body.templateId, 100) }).catch(() => []))[0];
          if (!t?.metaNome) {
            return Response.json({ error: 'Template não encontrado.' }, { status: 400 });
          }
          patch.templateId = t.id;
          patch.templateNome = t.metaNome;
          patch.templateIdioma = t.metaIdioma || 'pt_BR';
        }
        if (Array.isArray(body?.variaveis)) {
          patch.variaveis = body.variaveis.slice(0, 10).map((v: any) => ({
            origem: v?.origem === 'campo' ? 'campo' : 'fixo',
            valor: texto(v?.valor, 500),
            campo: texto(v?.campo, 40),
          }));
        }

        const atualizada = await svc.entities.CampanhaWhatsApp.update(c.id, patch);
        return Response.json({ campanha: campanhaParaTela(atualizada) });
      }

      case 'adicionar_destinatarios': {
        const c = await campanhaDoCorpo(svc, body, usuario, admin);
        if (!c) return Response.json({ error: 'Campanha não encontrada.' }, { status: 404 });
        if (c.status !== 'rascunho') {
          return Response.json(
            { error: 'Só dá para mexer no público enquanto é rascunho.', codigo: 'nao_e_rascunho' },
            { status: 409 },
          );
        }

        const clienteIds = (Array.isArray(body?.clienteIds) ? body.clienteIds : [])
          .map((i: unknown) => texto(i, 100)).filter(Boolean).slice(0, MAXIMO_POR_SELECAO);
        const prospectIds = (Array.isArray(body?.prospectIds) ? body.prospectIds : [])
          .map((i: unknown) => texto(i, 100)).filter(Boolean).slice(0, MAXIMO_POR_SELECAO);

        if (!clienteIds.length && !prospectIds.length) {
          return Response.json({ error: 'Nenhum cadastro selecionado.' }, { status: 400 });
        }

        const cadastros: Array<{ tipo: 'cliente' | 'prospect'; dados: Cadastro }> = [];
        for (const id of clienteIds) {
          const r = (await svc.entities.Cliente.filter({ id }).catch(() => []))[0];
          if (r) cadastros.push({ tipo: 'cliente', dados: r });
        }
        for (const id of prospectIds) {
          const r = (await svc.entities.Prospect.filter({ id }).catch(() => []))[0];
          if (r) cadastros.push({ tipo: 'prospect', dados: r });
        }

        const jaTem = await svc.entities.CampanhaDestinatario
          .filter({ campanhaId: c.id }).catch(() => []);
        const linhas = montarDestinatarios(
          cadastros,
          (jaTem || []).map((d: any) => d.telefone).filter(Boolean),
        );

        for (const l of linhas) {
          await svc.entities.CampanhaDestinatario.create({
            campanhaId: c.id,
            ...l,
            tentativas: 0,
          }).catch((e: any) => console.error('CAMPANHA: destinatário não gravado.', e));
        }

        const placar = await recontar(svc, c.id);
        await svc.entities.CampanhaWhatsApp.update(c.id, {
          totalDestinatarios: placar.totalDestinatarios,
          totalPulados: placar.totalPulados,
        }).catch(() => {});

        return Response.json({
          acrescentados: linhas.filter((l) => l.status === 'pendente').length,
          pulados: linhas.filter((l) => l.status === 'pulado').length,
          // Agrupado, para a tela poder dizer "21 pediram para sair" em vez de
          // listar 21 linhas iguais.
          motivos: linhas.filter((l) => l.status === 'pulado')
            .reduce((acc: Record<string, number>, l) => {
              acc[l.motivo] = (acc[l.motivo] || 0) + 1;
              return acc;
            }, {}),
          total: placar.totalDestinatarios,
        });
      }

      case 'remover_destinatario': {
        const c = await campanhaDoCorpo(svc, body, usuario, admin);
        if (!c) return Response.json({ error: 'Campanha não encontrada.' }, { status: 404 });
        if (c.status !== 'rascunho') {
          return Response.json(
            { error: 'Só dá para mexer no público enquanto é rascunho.', codigo: 'nao_e_rascunho' },
            { status: 409 },
          );
        }
        const id = texto(body?.destinatarioId, 100);
        const d = (await svc.entities.CampanhaDestinatario.filter({ id }).catch(() => []))[0];
        if (!d || d.campanhaId !== c.id) {
          return Response.json({ error: 'Destinatário não encontrado.' }, { status: 404 });
        }
        await svc.entities.CampanhaDestinatario.delete(id);

        const placar = await recontar(svc, c.id);
        await svc.entities.CampanhaWhatsApp.update(c.id, {
          totalDestinatarios: placar.totalDestinatarios,
          totalPulados: placar.totalPulados,
        }).catch(() => {});
        return Response.json({ ok: true, total: placar.totalDestinatarios });
      }

      // ── Prévia ────────────────────────────────────────────────────────────
      //
      // O que os primeiros destinatários vão receber, DE VERDADE, com as
      // variáveis resolvidas. Existe porque variável trocada de ordem não dá
      // erro em lugar nenhum: só manda a frase errada para o cliente.

      case 'previa': {
        const c = await campanhaDoCorpo(svc, body, usuario, admin);
        if (!c) return Response.json({ error: 'Campanha não encontrada.' }, { status: 404 });

        const linhas = (await svc.entities.CampanhaDestinatario
          .filter({ campanhaId: c.id, status: 'pendente' }).catch(() => [])).slice(0, 3);

        const amostras = [];
        for (const d of linhas) {
          const valores = resolverVariaveis(c.variaveis || [], {
            nome: d.nome,
            empresa: d.empresa,
            responsavelNome: usuario?.nome || '',
          });
          amostras.push({
            nome: d.nome,
            telefone: d.telefone,
            valores,
            incompleta: variavelVazia(valores),
          });
        }
        return Response.json({ template: c.templateNome || '', amostras });
      }

      // ── Ciclo de aprovação ────────────────────────────────────────────────

      case 'submeter': {
        const c = await campanhaDoCorpo(svc, body, usuario, admin);
        if (!c) return Response.json({ error: 'Campanha não encontrada.' }, { status: 404 });
        if (c.status !== 'rascunho') {
          return Response.json({ error: 'Esta campanha já foi submetida.' }, { status: 409 });
        }
        if (!c.templateNome) {
          return Response.json({ error: 'Escolha um template antes de submeter.' }, { status: 400 });
        }

        const placar = await recontar(svc, c.id);
        if (!placar.pendentes) {
          return Response.json(
            { error: 'Nenhum destinatário pode receber esta campanha.' },
            { status: 400 },
          );
        }

        const atualizada = await svc.entities.CampanhaWhatsApp.update(c.id, {
          status: 'aguardando_aprovacao',
          totalDestinatarios: placar.totalDestinatarios,
          totalPulados: placar.totalPulados,
        });
        return Response.json({ campanha: campanhaParaTela(atualizada), pendentes: placar.pendentes });
      }

      case 'decidir': {
        // A ÚNICA ação restrita a administrador. Aprovar é liberar mensagem em
        // massa saindo pelo número da empresa.
        if (!admin) {
          return Response.json(
            { error: 'Só administrador aprova campanha.', codigo: 'nao_e_admin' },
            { status: 403 },
          );
        }
        const id = texto(body?.campanhaId, 100);
        const c = (await svc.entities.CampanhaWhatsApp.filter({ id }).catch(() => []))[0];
        if (!c) return Response.json({ error: 'Campanha não encontrada.' }, { status: 404 });
        if (c.status !== 'aguardando_aprovacao') {
          return Response.json({ error: 'Esta campanha não está aguardando aprovação.' }, { status: 409 });
        }

        const aprovar = body?.aprovar === true;
        const agora = new Date().toISOString();
        const atualizada = await svc.entities.CampanhaWhatsApp.update(c.id, aprovar
          ? {
            status: 'aprovada',
            // Assinatura, não só status: é o que o disparo confere.
            aprovadoPorUserId: usuario?.id || '',
            aprovadoPorNome: usuario?.nome || usuario?.email || '',
            aprovadaEm: agora,
            motivoDecisao: texto(body?.motivo, 1000),
          }
          : {
            status: 'recusada',
            aprovadoPorUserId: '',
            aprovadoPorNome: '',
            motivoDecisao: texto(body?.motivo, 1000),
          });

        // Quem montou precisa saber, sem depender de abrir a tela.
        if (c.criadoPorUserId) {
          await svc.entities.NotificacaoSJOn.create({
            // `clienteId` é obrigatório na entidade; campanha não tem um só
            // cliente, então vai vazio, como o vigia já faz.
            clienteId: '',
            usuarioId: c.criadoPorUserId,
            tipo: 'whatsapp_campanha',
            titulo: aprovar ? 'Campanha aprovada' : 'Campanha recusada',
            corpo: `${c.nome} — ${aprovar ? 'liberada para envio' : texto(body?.motivo, 300) || 'sem motivo informado'}`,
            linkUrl: `/whatsapp/campanhas?campanha=${c.id}`,
            lida: false,
          }).catch(() => {});
        }

        return Response.json({ campanha: campanhaParaTela(atualizada) });
      }

      case 'cancelar': {
        const c = await campanhaDoCorpo(svc, body, usuario, admin);
        if (!c) return Response.json({ error: 'Campanha não encontrada.' }, { status: 404 });
        if (['concluida', 'cancelada'].includes(c.status)) {
          return Response.json({ error: 'Esta campanha já terminou.' }, { status: 409 });
        }
        // Cancelar no meio para o que ainda não saiu. O que já foi, foi — não
        // existe desfazer mensagem entregue, e fingir que existe seria pior.
        const atualizada = await svc.entities.CampanhaWhatsApp.update(c.id, {
          status: 'cancelada',
          concluidaEm: new Date().toISOString(),
        });
        return Response.json({ campanha: campanhaParaTela(atualizada) });
      }

      default:
        return Response.json({ error: `Ação desconhecida: ${acao}` }, { status: 400 });
    }
  } catch (e: any) {
    console.error('CAMPANHAS WHATSAPP: falha na ação', acao, e);
    return Response.json({ error: 'Não foi possível concluir a ação.' }, { status: 500 });
  }
});
