// Quem enxerga qual conversa do WhatsApp.
//
// A REGRA, EM UMA FRASE: cada consultor vê as conversas dos clientes de que ele
// é o responsável; administrador vê todas.
//
// Por que isso mora no servidor e não na tela: a tela some com o que a pessoa
// não deve ver, mas quem impede de fato é a função — `whatsappConversas` e
// `enviarWhatsApp` chamam daqui antes de devolver ou de mandar qualquer coisa.
// Conferir só no navegador seria deixar a conversa a um `fetch` de distância.
//
// ── A conversa ainda sem dono ────────────────────────────────────────────────
//
// Quando um número escreve pela primeira vez e não casa com cadastro nenhum, a
// conversa nasce sem vínculo. Ela fica visível para TODOS, de propósito: se
// ficasse restrita, uma mensagem de cliente novo não apareceria para ninguém —
// e o canal existe justamente para não perder isso. Assim que alguém vincula ao
// cadastro, ela passa a obedecer à regra do responsável.
//
// ── O que esta regra não alcança ─────────────────────────────────────────────
//
// `contato` e `agente` não têm responsável no cadastro, então conversa vinculada
// a eles continua visível a todos. É um vão conhecido, e não um esquecimento:
// fechá-lo exigiria inventar um dono onde o sistema não tem um. Cliente e
// prospect, que têm, são conferidos.

/** Admin do sistema — mesma leitura da função `chat`. */
export const ehAdminSistema = (u: any) =>
  u?.isAdmin === true ||
  (u?.cargosNomes || []).some((n: unknown) => String(n).toLowerCase() === 'admin');

export type Alcance = {
  /** Vê tudo (admin, ou chamada de automação sem usuário). */
  tudo: boolean;
  clientesIds: Set<string>;
  prospectsIds: Set<string>;
};

/**
 * O que este usuário alcança.
 *
 * Duas consultas, uma vez por requisição — e não uma por conversa da lista: com
 * 200 conversas na tela, conferir cliente a cliente seria 200 idas ao banco a
 * cada tique da consulta curta.
 */
export async function alcanceDoUsuario(svc: any, usuario: any): Promise<Alcance> {
  if (!usuario?.id || ehAdminSistema(usuario)) {
    return { tudo: true, clientesIds: new Set(), prospectsIds: new Set() };
  }

  const [clientes, prospects] = await Promise.all([
    svc.entities.Cliente.filter({ responsavelUserId: usuario.id }).catch(() => []),
    svc.entities.Prospect.filter({ responsavelUserId: usuario.id }).catch(() => []),
  ]);

  return {
    tudo: false,
    clientesIds: new Set((clientes || []).map((c: any) => String(c.id))),
    prospectsIds: new Set((prospects || []).map((p: any) => String(p.id))),
  };
}

/** Esta conversa aparece para quem tem este alcance? */
export function podeVerConversa(conversa: any, alcance: Alcance): boolean {
  if (alcance.tudo) return true;

  const tipo = String(conversa?.vinculoTipo || 'nenhum');
  const id = String(conversa?.vinculoId || '');
  if (tipo === 'nenhum' || !id) return true; // ainda sem dono — ver cabeçalho

  if (tipo === 'cliente') return alcance.clientesIds.has(id);
  if (tipo === 'prospect') return alcance.prospectsIds.has(id);
  return true; // contato e agente não têm responsável no cadastro
}

/**
 * Motivo da recusa, para a função responder algo que se entenda.
 *
 * Devolve 404, e não 403, quando a pessoa não alcança a conversa: dizer
 * "existe, mas não é sua" já entrega que aquele número fala com a empresa.
 */
export const RECUSA_CONVERSA = {
  status: 404,
  corpo: { error: 'Conversa não encontrada.' },
};
