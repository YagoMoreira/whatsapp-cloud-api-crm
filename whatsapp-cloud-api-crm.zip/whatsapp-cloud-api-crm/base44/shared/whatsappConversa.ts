// A conversa do WhatsApp no banco — o que as três funções do canal precisam
// fazer com `WhatsAppConversa` e que seria erro escrever três vezes.
//
// Separado de `shared/whatsapp.ts` (que fala com a Meta e não conhece o banco)
// porque as responsabilidades são outras: aqui dentro tudo recebe o cliente de
// serviço (`svc`) e mexe em entidade.
//
// Desenho do canal: docs/whatsapp/PLANO.md.

import {
  fimDaJanela,
  formatarTelefone,
  previewDaMensagem,
  variacoesTelefone,
} from './whatsapp.ts';

const texto = (v: unknown, max = 500) => String(v ?? '').slice(0, max);

/** A linha mais antiga do conjunto — a que vence quando houve corrida. */
const maisAntiga = (linhas: any[]) =>
  [...(linhas || [])].sort((a, b) =>
    String(a.created_date || a.id).localeCompare(String(b.created_date || b.id)))[0];

/**
 * Procura no cadastro quem é o dono do número.
 *
 * Consulta por igualdade, uma por formato plausível (`variacoesTelefone`), em
 * vez de varrer a base e comparar normalizado: a varredura custaria a base
 * inteira a cada mensagem que chega. O preço é não reconhecer um cadastro
 * gravado num formato exótico — e aí o atendente vincula à mão pela tela, que é
 * o caminho que existe justamente para isso.
 */
export async function acharCadastro(svc: any, telefone: string) {
  const formatos = variacoesTelefone(telefone);
  if (!formatos.length) return null;

  const alvos = [
    { entidade: 'Cliente', campo: 'whatsapp', tipo: 'cliente' },
    { entidade: 'Cliente', campo: 'telefone', tipo: 'cliente' },
    { entidade: 'Contato', campo: 'telefone', tipo: 'contato' },
    { entidade: 'Prospect', campo: 'telefone', tipo: 'prospect' },
  ];

  for (const alvo of alvos) {
    for (const formato of formatos) {
      const achados = await svc.entities[alvo.entidade]
        .filter({ [alvo.campo]: formato })
        .catch(() => []);
      const r = achados?.[0];
      if (r) {
        return {
          vinculoTipo: alvo.tipo,
          vinculoId: r.id,
          vinculoNome: texto(r.nome || r.razaoSocial || '', 200),
          entidadeInternaId: texto(r.entidadeInternaId || '', 100),
        };
      }
    }
  }
  return null;
}

/**
 * A conversa daquele número neste nosso número, criando-a se for a primeira.
 *
 * A releitura depois do create não é paranoia: um cliente que manda três
 * mensagens seguidas gera três entregas do webhook em paralelo, e as três podem
 * não achar conversa nenhuma ao mesmo tempo. Quando isso acontece, todas
 * convergem para a linha mais antiga — as mensagens ficam juntas, que é o que
 * importa, e sobra uma linha vazia em vez de um histórico partido em dois.
 */
export async function garantirConversa(
  svc: any,
  { telefone, numeroId, nomePerfil = '' }:
    { telefone: string; numeroId: string; nomePerfil?: string },
) {
  const existentes = await svc.entities.WhatsAppConversa
    .filter({ telefone, numeroId }).catch(() => []);
  if (existentes?.length) return maisAntiga(existentes);

  const cadastro = await acharCadastro(svc, telefone);
  await svc.entities.WhatsAppConversa.create({
    telefone,
    numeroId,
    telefoneExibicao: formatarTelefone(telefone),
    nomePerfil: texto(nomePerfil, 200),
    status: 'aberta',
    naoLidas: 0,
    ...(cadastro || { vinculoTipo: 'nenhum' }),
  });

  const depois = await svc.entities.WhatsAppConversa
    .filter({ telefone, numeroId }).catch(() => []);
  return maisAntiga(depois);
}

/**
 * Resumo da conversa depois de uma mensagem RECEBIDA.
 *
 * A janela de 24h reabre aqui, e só aqui: ela conta da mensagem do cliente.
 */
export function resumoDeEntrada(
  conversa: any,
  { tipo, texto: corpo, ocorridoEm, nomePerfil }:
    { tipo: string; texto: string; ocorridoEm: string; nomePerfil?: string },
) {
  return {
    ultimaMensagemEm: ocorridoEm,
    ultimaMensagemPreview: previewDaMensagem(tipo, corpo),
    ultimaMensagemDirecao: 'entrada',
    janelaExpiraEm: fimDaJanela(ocorridoEm),
    naoLidas: Number(conversa?.naoLidas || 0) + 1,
    status: 'aberta',
    ...(nomePerfil && !conversa?.nomePerfil ? { nomePerfil: texto(nomePerfil, 200) } : {}),
  };
}

/**
 * Resumo depois de uma mensagem ENVIADA.
 *
 * Note o que NÃO está aqui: `janelaExpiraEm`. Responder não estende a janela —
 * quem a estende é o cliente. Mexer nela no envio faria a tela prometer texto
 * livre que a Meta vai recusar.
 */
export function resumoDeSaida(
  { tipo, texto: corpo, ocorridoEm }: { tipo: string; texto: string; ocorridoEm: string },
) {
  return {
    ultimaMensagemEm: ocorridoEm,
    ultimaMensagemPreview: previewDaMensagem(tipo, corpo),
    ultimaMensagemDirecao: 'saida',
    status: 'aberta',
  };
}
