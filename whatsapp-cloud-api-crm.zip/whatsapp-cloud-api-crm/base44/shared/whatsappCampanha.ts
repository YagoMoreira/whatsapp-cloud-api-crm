// Regras do envio em lote, sem I/O.
//
// Tudo aqui é função pura: recebe listas e devolve listas. O que fala com a
// Meta e com o banco fica em `functions/campanhaWhatsAppDisparo`. A separação
// não é estética — é o que deixa `scripts/testeWhatsApp.mjs` empacotar este
// arquivo com o esbuild e conferir as travas sem rede e sem banco.
//
// ── O que este módulo protege ───────────────────────────────────────────────
//
// Campanha é a ação de maior alcance do canal. As três formas de estragar um
// número são todas de lote:
//
// 1. Mandar para quem pediu para sair.
// 2. Mandar duas vezes para a mesma pessoa.
// 3. Mandar mais do que o degrau da Meta permite em 24h.
//
// As três são decididas aqui.

import { normalizarTelefone } from './whatsapp.ts';

// ── Público ─────────────────────────────────────────────────────────────────

export type Cadastro = {
  id?: string;
  nome?: string;
  empresa?: string;
  telefone?: string;
  whatsapp?: string;
  responsavelUserId?: string;
  whatsappOptOut?: boolean;
};

export type Destinatario = {
  tipo: 'cliente' | 'prospect';
  alvoId: string;
  nome: string;
  empresa: string;
  responsavelUserId: string;
  telefone: string;
  status: 'pendente' | 'pulado';
  motivo: string;
};

/**
 * Transforma cadastros selecionados na tela em linhas de destinatário.
 *
 * Ninguém é descartado em silêncio: quem não pode receber entra como `pulado`
 * com o motivo escrito. Sumir com a linha faria a pessoa que selecionou 300 e
 * viu 280 não ter como descobrir quem foram os 20 — e a resposta ("21 pediram
 * para sair") costuma ser a informação mais útil da campanha.
 *
 * `jaNaCampanha` são os telefones que já estão na campanha de rodadas
 * anteriores de seleção, para acrescentar gente a uma campanha existente não
 * duplicar quem já estava.
 */
export function montarDestinatarios(
  cadastros: Array<{ tipo: 'cliente' | 'prospect'; dados: Cadastro }>,
  jaNaCampanha: string[] = [],
): Destinatario[] {
  const vistos = new Set(jaNaCampanha.filter(Boolean));
  const linhas: Destinatario[] = [];

  for (const { tipo, dados } of cadastros || []) {
    const telefone = normalizarTelefone(dados?.whatsapp || dados?.telefone);
    const base = {
      tipo,
      alvoId: String(dados?.id || ''),
      nome: String(dados?.nome || '').slice(0, 200),
      empresa: String(dados?.empresa || '').slice(0, 200),
      responsavelUserId: String(dados?.responsavelUserId || ''),
      telefone,
    };

    if (!telefone) {
      linhas.push({ ...base, status: 'pulado', motivo: 'sem telefone utilizável' });
      continue;
    }
    if (dados?.whatsappOptOut === true) {
      linhas.push({ ...base, status: 'pulado', motivo: 'pediu para não receber' });
      continue;
    }
    // Deduplicação pelo TELEFONE, não pelo id do cadastro: dois cadastros com o
    // mesmo número são uma pessoa só do lado de lá, e receber a mesma campanha
    // duas vezes é o que gera denúncia.
    if (vistos.has(telefone)) {
      linhas.push({ ...base, status: 'pulado', motivo: 'número repetido na campanha' });
      continue;
    }

    vistos.add(telefone);
    linhas.push({ ...base, status: 'pendente', motivo: '' });
  }

  return linhas;
}

// ── Variáveis ───────────────────────────────────────────────────────────────

export type RegraVariavel = {
  origem?: 'fixo' | 'campo';
  valor?: string;
  campo?: 'nome' | 'primeiroNome' | 'empresa' | 'responsavelNome';
};

/** Primeiro nome, para o template soar como gente e não como mala direta. */
export function primeiroNome(nome: unknown): string {
  const inteiro = String(nome ?? '').trim();
  if (!inteiro) return '';
  return inteiro.split(/\s+/)[0];
}

/**
 * Preenche {{1}}, {{2}}… para um destinatário, NA ORDEM das regras.
 *
 * Campo vazio vira string vazia e não quebra o envio — mas a Meta recusa
 * template com variável vazia, então `variavelVazia` abaixo é o que o disparo
 * usa para pular a linha ANTES de gastar uma tentativa com ela.
 */
export function resolverVariaveis(
  regras: RegraVariavel[],
  alvo: { nome?: string; empresa?: string; responsavelNome?: string },
): string[] {
  return (regras || []).map((r) => {
    if (r?.origem === 'campo') {
      switch (r.campo) {
        case 'primeiroNome': return primeiroNome(alvo?.nome);
        case 'empresa': return String(alvo?.empresa ?? '').trim();
        case 'responsavelNome': return String(alvo?.responsavelNome ?? '').trim();
        case 'nome':
        default: return String(alvo?.nome ?? '').trim();
      }
    }
    return String(r?.valor ?? '').trim();
  }).map((v) => v.slice(0, 500));
}

/** Alguma variável saiu vazia? A Meta recusa o template inteiro se sim. */
export function variavelVazia(valores: string[]): boolean {
  return (valores || []).some((v) => !String(v ?? '').trim());
}

// ── Ritmo ───────────────────────────────────────────────────────────────────

/** O dia, em UTC, no formato que `diaDaContagem` guarda. */
export function diaUTC(agora: Date = new Date()): string {
  return agora.toISOString().slice(0, 10);
}

/**
 * Quantos ainda cabem hoje.
 *
 * A contagem zera sozinha quando o dia vira: o disparo não tem um cron de
 * meia-noite para confiar, então a virada é deduzida comparando a data
 * guardada com a de agora. Um dia sem rodada nenhuma continua zerando certo.
 */
export function quantosCabemHoje(
  campanha: { limiteDiario?: number; enviadasHoje?: number; diaDaContagem?: string },
  agora: Date = new Date(),
): number {
  const limite = Number(campanha?.limiteDiario);
  const teto = Number.isFinite(limite) && limite > 0 ? Math.floor(limite) : 200;
  const mesmoDia = campanha?.diaDaContagem === diaUTC(agora);
  const jaForam = mesmoDia ? Math.max(0, Number(campanha?.enviadasHoje) || 0) : 0;
  return Math.max(0, teto - jaForam);
}

/**
 * A campanha está liberada para mandar?
 *
 * `aprovadoPorUserId` é conferido além do status, de propósito: status é um
 * campo que qualquer caminho futuro pode escrever, e a assinatura de quem
 * liberou é o que não se põe por acidente.
 */
export function podeDisparar(campanha: any): { ok: boolean; motivo: string } {
  if (!campanha) return { ok: false, motivo: 'campanha não encontrada' };
  if (campanha.status === 'cancelada') return { ok: false, motivo: 'campanha cancelada' };
  if (campanha.status === 'recusada') return { ok: false, motivo: 'campanha recusada' };
  if (campanha.status === 'concluida') return { ok: false, motivo: 'campanha concluída' };
  if (campanha.status === 'rascunho') return { ok: false, motivo: 'campanha ainda em rascunho' };
  if (campanha.status === 'aguardando_aprovacao') return { ok: false, motivo: 'aguardando aprovação' };
  if (!campanha.aprovadoPorUserId) return { ok: false, motivo: 'sem aprovação registrada' };
  if (!campanha.templateNome) return { ok: false, motivo: 'sem template escolhido' };
  return { ok: true, motivo: '' };
}

/** Quantas tentativas um número ganha antes de a campanha desistir dele. */
export const TENTATIVAS_MAXIMAS = 3;

/**
 * A próxima leva: os pendentes que cabem no teto de hoje.
 *
 * Quem já esgotou as tentativas fica de fora — arrastar um número que falha
 * sempre por todas as rodadas gasta o teto de quem receberia.
 */
export function proximaLeva<T extends { status?: string; tentativas?: number }>(
  pendentes: T[],
  vagas: number,
): T[] {
  if (!(vagas > 0)) return [];
  return (pendentes || [])
    .filter((d) => d?.status === 'pendente' && (Number(d?.tentativas) || 0) < TENTATIVAS_MAXIMAS)
    .slice(0, vagas);
}
