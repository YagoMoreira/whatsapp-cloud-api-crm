// Mensagem que o sistema manda ao cliente sozinho.
//
// É o caminho que as automações usam — e é deliberadamente estreito, porque
// mensagem automática é a que mais estraga um número: ela sai sem ninguém ler
// antes, em volume, e a Meta pune volume com queda de qualidade e bloqueio.
//
// ── As quatro travas, todas antes de qualquer envio ─────────────────────────
//
// 1. CANAL CONFIGURADO. Sem token e número, não tenta.
// 2. O CLIENTE NÃO PEDIU PARA SAIR. `Cliente.whatsappOptOut` desliga o canal
//    para aquele cliente, e nenhuma automação passa por cima — é o que a LGPD
//    espera e o que evita a denúncia que derruba o número.
// 3. EXISTE TEMPLATE APROVADO para aquele evento, achado pela `metaChave`.
//    Automação roda de madrugada, quando a janela de 24h quase sempre está
//    fechada: sem template aprovado a Meta recusaria, e recusa em massa também
//    conta contra o número.
// 4. NÃO É REPETIÇÃO. Quem chama diz qual é a chave do fato (a pendência, o
//    passo da jornada, o percentual de horas) e este módulo confere se já
//    mandou aquilo — automação que repete vira denúncia de spam.
//
// Qualquer trava que feche devolve `{ ok: false, motivo }`. Nenhuma delas é
// erro: são o funcionamento normal de um canal que prefere não mandar a mandar
// errado.

import { enviarTemplate, janelaAberta, VERSAO_PADRAO, type Config } from './whatsapp.ts';
import { garantirConversa, resumoDeSaida } from './whatsappConversa.ts';
import { normalizarTelefone } from './whatsapp.ts';

/** Chaves de evento que as automações usam para achar o template. */
export const CHAVES = {
  PENDENCIA: 'pendencia_cobranca',
  POSVENDA_PASSO: 'posvenda_passo',
  POSVENDA_NPS: 'posvenda_nps',
  HORAS: 'horas_percentual',
} as const;

export function configDoAmbiente(): Config {
  return {
    token: Deno.env.get('WHATSAPP_ACCESS_TOKEN') || '',
    phoneNumberId: Deno.env.get('WHATSAPP_PHONE_NUMBER_ID') || '',
    versao: Deno.env.get('WHATSAPP_API_VERSION') || VERSAO_PADRAO,
  };
}

export type Resultado = { ok: boolean; motivo: string; wamid?: string };

const naoMandou = (motivo: string): Resultado => ({ ok: false, motivo });

/**
 * Manda um template ao cliente, se as quatro travas deixarem.
 *
 * `fato` é o que identifica o acontecimento — `pendencia:<id>`, `passo:<id>`,
 * `horas:<percentual>`. É por ele que a repetição é barrada, e é ele que fica
 * gravado na mensagem para quem for conferir depois entender por que ela saiu.
 */
export async function dispararTemplate(
  svc: any,
  { clienteId, chave, variaveis = [], fato, origem }:
    {
      clienteId: string;
      chave: string;
      variaveis?: string[];
      fato: string;
      origem: string;
    },
): Promise<Resultado> {
  const cfg = configDoAmbiente();
  if (!cfg.token || !cfg.phoneNumberId) return naoMandou('canal não configurado');

  const cliente = (await svc.entities.Cliente.filter({ id: clienteId }).catch(() => []))[0];
  if (!cliente) return naoMandou('cliente não encontrado');
  if (cliente.whatsappOptOut === true) return naoMandou('cliente optou por não receber');

  const telefone = normalizarTelefone(cliente.whatsapp || cliente.telefone);
  if (!telefone) return naoMandou('cliente sem telefone utilizável');

  const templates = await svc.entities.TemplatesMensagem
    .filter({ tipo: 'whatsapp', metaChave: chave, ativo: true }).catch(() => []);
  const modelo = (templates || []).find((t: any) => t.metaNome && (!t.metaStatus || t.metaStatus === 'aprovado'));
  if (!modelo) return naoMandou(`sem template aprovado para "${chave}"`);

  const conversa = await garantirConversa(svc, { telefone, numeroId: cfg.phoneNumberId });
  if (!conversa?.id) return naoMandou('não foi possível abrir a conversa');

  // Repetição: o mesmo fato não sai duas vezes para a mesma conversa.
  const anteriores = await svc.entities.WhatsAppMensagem
    .filter({ conversaId: conversa.id, direcao: 'saida' }).catch(() => []);
  const repetido = (anteriores || []).some(
    (m: any) => m?.metadados?.fato === fato && m.status !== 'falhou',
  );
  if (repetido) return naoMandou('já avisado');

  const valores = variaveis.map((v) => String(v ?? '').slice(0, 500));
  const resultado = await enviarTemplate(cfg, telefone, modelo.metaNome, modelo.metaIdioma || 'pt_BR', valores);

  const agora = new Date().toISOString();
  const preview = `[${modelo.titulo || modelo.metaNome}] ${valores.join(' · ')}`.trim();

  await svc.entities.WhatsAppMensagem.create({
    conversaId: conversa.id,
    wamid: resultado.wamid || '',
    direcao: 'saida',
    tipo: 'template',
    texto: preview.slice(0, 4096),
    status: resultado.ok ? 'enviada' : 'falhou',
    ocorridoEm: agora,
    // Sem autor humano de propósito: quem lê a thread precisa distinguir o que
    // um atendente escreveu do que o sistema disparou.
    autorNome: `Automação · ${origem}`,
    templateNome: modelo.metaNome,
    templateIdioma: modelo.metaIdioma || 'pt_BR',
    templateVariaveis: valores,
    metadados: { fato, origem, automatica: true },
    ...(resultado.ok ? {} : { erroCodigo: resultado.erroCodigo, erroMensagem: resultado.erroMensagem }),
  }).catch((e: any) => console.error('WHATSAPP AUTOMACAO: mensagem não registrada.', e));

  if (resultado.ok) {
    await svc.entities.WhatsAppConversa.update(
      conversa.id,
      resumoDeSaida({ tipo: 'template', texto: preview, ocorridoEm: agora }),
    ).catch(() => {});

    await svc.entities.HistoricoNotificacao.create({
      usuarioId: cliente.responsavelUserId || '',
      mensagem: `WhatsApp automático (${origem}) para ${cliente.nome || telefone}`,
      canal: 'whatsapp',
      dataEnvio: agora,
      metadados: { clienteId, fato, template: modelo.metaNome },
    }).catch(() => {});
  }

  return resultado.ok
    ? { ok: true, motivo: '', wamid: resultado.wamid }
    : naoMandou(`a Meta recusou: ${resultado.erroMensagem}`);
}

/**
 * A janela está aberta? Serve para a automação preferir texto livre quando o
 * cliente acabou de escrever — mais barato e menos formal que um template.
 *
 * Reexportado daqui para quem chama não precisar importar de dois módulos.
 */
export { janelaAberta };
