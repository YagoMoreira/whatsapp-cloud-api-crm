// Ponte com a WhatsApp Business Platform (Cloud API) — a API oficial da Meta.
//
// As três funções do canal (receberWhatsApp, enviarWhatsApp, whatsappConversas)
// importam daqui, para que a normalização de número, a regra da janela de 24h e
// o formato das chamadas à Graph API existam num lugar só.
//
// POR QUE ESTE MÓDULO NÃO LÊ SEGREDO NENHUM
//
// Os outros módulos de `shared/` usam `secrets.get(...)` de "base44:runtime" —
// um especificador que só existe dentro do runtime do Base44. Aqui a
// configuração entra por parâmetro (`Config`) porque a normalização de número e
// a conferência de assinatura são justamente o que precisa de teste automático,
// e teste roda em node: um import de "base44:runtime" no meio do arquivo
// tornaria o módulo inteiro impossível de empacotar fora do Deno.
// Quem lê os segredos é cada `entry.ts` (`Deno.env.get`), que os passa adiante.
//
// O desenho completo, a configuração na Meta e os limites do canal estão em
// docs/whatsapp/PLANO.md.

// ── Configuração ─────────────────────────────────────────────────────────────

export type Config = {
  /** Token do System User (permanente). */
  token: string;
  /** phone_number_id do número nosso que envia. */
  phoneNumberId: string;
  /** Versão da Graph API, ex.: "v22.0". */
  versao: string;
};

/**
 * Versão da Graph API usada quando `WHATSAPP_API_VERSION` não está definida.
 *
 * A Meta aposenta versões depois de cerca de dois anos, e uma versão aposentada
 * responde erro em vez de enviar. O valor aqui é um ponto de partida — quem
 * configurar o canal deve fixar em `WHATSAPP_API_VERSION` a versão corrente do
 * app, e revisar isso quando a Meta anunciar a aposentadoria.
 */
export const VERSAO_PADRAO = "v22.0";

const GRAPH = "https://graph.facebook.com";

/** Janela de resposta livre: 24h contadas da última mensagem DO CLIENTE. */
export const JANELA_MS = 24 * 60 * 60 * 1000;

// ── Telefone ─────────────────────────────────────────────────────────────────

/**
 * Número no formato que a Meta usa: E.164 só com dígitos, sem "+".
 *
 * A entrada vem de cadastro feito à mão ao longo de anos: "(27) 99999-8888",
 * "27 9 9999-8888", "+55 27 99999-8888", "5527999998888". Todas viram
 * "5527999998888".
 *
 * A AMBIGUIDADE QUE O "+" RESOLVE. Onze dígitos podem ser um celular brasileiro
 * sem código de país (27 99999-8888) ou um número americano com ele
 * (1 415 555-0100). Não existe regra que separe os dois pelo número. Então:
 * quem escreve com "+" está declarando internacional e é respeitado como veio;
 * quem escreve sem "+" está falando de um número brasileiro, que é o caso de
 * 99% do cadastro. Um internacional digitado sem "+" é recusado — e recusar é
 * melhor do que mandar mensagem para o país errado.
 *
 * Devolve `null` quando não dá para afirmar qual é o número.
 */
export function normalizarTelefone(bruto: string | null | undefined): string | null {
  const texto = String(bruto ?? "").trim();
  if (!texto) return null;

  const internacional = texto.startsWith("+") || texto.startsWith("00");
  const d = texto.replace(/\D/g, "");
  if (!d) return null;

  if (internacional) {
    // 00 é o prefixo internacional discado; o país começa depois dele.
    const semPrefixo = texto.startsWith("00") ? d.replace(/^00/, "") : d;
    return semPrefixo.length >= 8 && semPrefixo.length <= 15 ? semPrefixo : null;
  }

  // Brasil com código de país: 55 + DDD(2) + 8 ou 9 dígitos.
  if ((d.length === 12 || d.length === 13) && d.startsWith("55")) return d;

  // Brasil sem código de país: DDD(2) + 8 ou 9 dígitos.
  // Vem ANTES da checagem de "começa com 55" de propósito: 55 também é o DDD de
  // Santa Maria (RS), e "55999998888" é um celular de lá, não um número já
  // internacionalizado.
  if (d.length === 10 || d.length === 11) return `55${d}`;

  return null;
}

/** "5527999998888" → "+55 (27) 99999-8888". Fora do Brasil, devolve "+dígitos". */
export function formatarTelefone(e164: string | null | undefined): string {
  const d = String(e164 ?? "").replace(/\D/g, "");
  if (!d) return "";
  if (d.startsWith("55") && (d.length === 12 || d.length === 13)) {
    const ddd = d.slice(2, 4);
    const resto = d.slice(4);
    const meio = resto.length === 9 ? resto.slice(0, 5) : resto.slice(0, 4);
    const fim = resto.length === 9 ? resto.slice(5) : resto.slice(4);
    return `+55 (${ddd}) ${meio}-${fim}`;
  }
  return `+${d}`;
}

/**
 * Variações do mesmo número brasileiro, para casar com telefone de cadastro.
 *
 * O nono dígito entrou nos celulares em 2013 e o cadastro tem os dois formatos
 * — às vezes do mesmo cliente. Procurar só pela forma canônica deixaria de
 * reconhecer metade das pessoas que escrevem.
 */
export function variacoesTelefone(e164: string | null | undefined): string[] {
  const d = normalizarTelefone(e164);
  if (!d) return [];
  const fora = new Set<string>([d]);
  if (d.startsWith("55") && d.length >= 12) {
    const ddd = d.slice(2, 4);
    const resto = d.slice(4);
    const com9 = resto.length === 8 ? `9${resto}` : resto;
    const sem9 = resto.length === 9 && resto.startsWith("9") ? resto.slice(1) : resto;
    for (const r of [com9, sem9]) {
      fora.add(`55${ddd}${r}`);
      fora.add(`${ddd}${r}`);
      fora.add(r);
    }
  }
  return [...fora];
}

// ── Janela de 24h ────────────────────────────────────────────────────────────

/** Fim da janela a partir do instante em que o CLIENTE falou. */
export function fimDaJanela(recebidaEmISO: string): string {
  const t = Date.parse(recebidaEmISO);
  const base = Number.isNaN(t) ? Date.now() : t;
  return new Date(base + JANELA_MS).toISOString();
}

/** A conversa ainda aceita texto livre? */
export function janelaAberta(
  janelaExpiraEm: string | null | undefined,
  agora: number = Date.now(),
): boolean {
  const t = Date.parse(String(janelaExpiraEm || ""));
  return !Number.isNaN(t) && t > agora;
}

// ── Assinatura do webhook ────────────────────────────────────────────────────

/** Comparação de tempo constante: um `===` vazaria o hash byte a byte. */
function igualdadeSegura(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diferenca = 0;
  for (let i = 0; i < a.length; i++) diferenca |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diferenca === 0;
}

/**
 * Confere o `X-Hub-Signature-256` que a Meta manda em todo webhook.
 *
 * O HMAC é calculado sobre o corpo **cru**, exatamente como chegou. Reserializar
 * (`JSON.stringify(JSON.parse(corpo))`) muda espaços e ordem e derruba a
 * conferência — por isso quem chama precisa passar o texto original, antes de
 * qualquer parse.
 *
 * Sem esta conferência o webhook é um formulário aberto na internet para
 * inserir mensagem falsa na caixa de entrada do atendimento.
 */
export async function assinaturaConfere(
  corpoCru: string,
  cabecalho: string | null,
  appSecret: string,
): Promise<boolean> {
  const recebida = String(cabecalho || "").trim().toLowerCase();
  if (!recebida.startsWith("sha256=") || !appSecret) return false;

  const chave = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(appSecret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const assinado = await crypto.subtle.sign("HMAC", chave, new TextEncoder().encode(corpoCru));
  const hex = Array.from(new Uint8Array(assinado))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  return igualdadeSegura(recebida.slice("sha256=".length), hex);
}

// ── Leitura do payload da Meta ───────────────────────────────────────────────

/** Timestamp da Meta (segundos, como texto) → ISO. */
export function instanteDaMeta(timestamp: string | number | null | undefined): string {
  const segundos = Number(timestamp);
  if (!Number.isFinite(segundos) || segundos <= 0) return new Date().toISOString();
  return new Date(segundos * 1000).toISOString();
}

export type MensagemLida = {
  wamid: string;
  telefone: string;
  tipo: string;
  texto: string;
  /** id da mídia na Meta, quando houver — o arquivo é baixado à parte. */
  mediaId: string;
  midiaNome: string;
  midiaMime: string;
  respondendoAWamid: string;
  metadados: Record<string, unknown>;
  ocorridoEm: string;
};

const TIPOS_MIDIA: Record<string, string> = {
  image: "imagem",
  document: "documento",
  audio: "audio",
  video: "video",
  sticker: "sticker",
};

/**
 * Uma mensagem do webhook no formato das nossas entidades.
 *
 * O que não sabemos exibir NÃO vira erro: vira `nao_suportado` com um texto que
 * diz o que chegou. Um botão interativo novo da Meta não pode fazer o
 * atendimento perder a mensagem — ele precisa saber que o cliente respondeu.
 */
export function lerMensagem(msg: any): MensagemLida {
  const base: MensagemLida = {
    wamid: String(msg?.id || ""),
    telefone: String(msg?.from || ""),
    tipo: "nao_suportado",
    texto: "",
    mediaId: "",
    midiaNome: "",
    midiaMime: "",
    respondendoAWamid: String(msg?.context?.id || ""),
    metadados: {},
    ocorridoEm: instanteDaMeta(msg?.timestamp),
  };
  const tipo = String(msg?.type || "");

  if (tipo === "text") {
    return { ...base, tipo: "texto", texto: String(msg?.text?.body || "") };
  }

  if (TIPOS_MIDIA[tipo]) {
    const m = msg?.[tipo] || {};
    return {
      ...base,
      tipo: TIPOS_MIDIA[tipo],
      texto: String(m.caption || ""),
      mediaId: String(m.id || ""),
      midiaNome: String(m.filename || ""),
      midiaMime: String(m.mime_type || ""),
    };
  }

  if (tipo === "location") {
    const l = msg?.location || {};
    return {
      ...base,
      tipo: "localizacao",
      texto: String(l.name || l.address || "Localização"),
      metadados: { latitude: l.latitude, longitude: l.longitude, endereco: l.address || "" },
    };
  }

  if (tipo === "contacts") {
    const nomes = (msg?.contacts || [])
      .map((c: any) => c?.name?.formatted_name)
      .filter(Boolean);
    return {
      ...base,
      tipo: "contato",
      texto: nomes.join(", ") || "Contato",
      metadados: { contatos: msg?.contacts || [] },
    };
  }

  // Resposta de botão ou de lista: a Meta manda o rótulo que o cliente tocou.
  if (tipo === "interactive" || tipo === "button") {
    const i = msg?.interactive || {};
    const rotulo = i?.button_reply?.title || i?.list_reply?.title || msg?.button?.text || "";
    return {
      ...base,
      tipo: "texto",
      texto: String(rotulo || "(resposta sem texto)"),
      metadados: { interativo: i || msg?.button || {} },
    };
  }

  return {
    ...base,
    texto: `(mensagem de tipo "${tipo || "desconhecido"}" — abra no aplicativo)`,
    metadados: { bruto: msg },
  };
}

/** Status da Meta → status da nossa entidade. */
export function statusDaMeta(status: string): string {
  const mapa: Record<string, string> = {
    sent: "enviada",
    delivered: "entregue",
    read: "lida",
    failed: "falhou",
  };
  return mapa[String(status || "")] || "";
}

/** Texto curto da conversa na lista — mídia sem legenda vira o nome do tipo. */
export function previewDaMensagem(tipo: string, texto: string): string {
  const limpo = String(texto || "").replace(/\s+/g, " ").trim();
  if (limpo) return limpo.slice(0, 120);
  const rotulos: Record<string, string> = {
    imagem: "📷 Imagem",
    documento: "📎 Documento",
    audio: "🎤 Áudio",
    video: "🎬 Vídeo",
    sticker: "Figurinha",
    localizacao: "📍 Localização",
    contato: "👤 Contato",
  };
  return rotulos[tipo] || "Mensagem";
}

// ── Chamadas à Cloud API ─────────────────────────────────────────────────────

export type Resultado = {
  ok: boolean;
  wamid: string;
  /** Código do erro na Meta — é ele que distingue os motivos de falha. */
  erroCodigo: string;
  erroMensagem: string;
};

/**
 * A Meta responde 200 com corpo de erro em alguns casos e 4xx em outros. Ler o
 * corpo sempre (e não só quando `!ok`) é o que evita gravar como "enviada" uma
 * mensagem que não saiu.
 */
async function lerResposta(res: Response): Promise<Resultado> {
  const corpo = await res.json().catch(() => ({}));
  const erro = corpo?.error;
  if (erro) {
    return {
      ok: false,
      wamid: "",
      erroCodigo: String(erro.code ?? erro.type ?? res.status),
      erroMensagem: String(
        erro.error_data?.details || erro.message || "Erro sem descrição na Meta",
      ).slice(0, 500),
    };
  }
  if (!res.ok) {
    return { ok: false, wamid: "", erroCodigo: String(res.status), erroMensagem: "Falha na Cloud API" };
  }
  return { ok: true, wamid: String(corpo?.messages?.[0]?.id || ""), erroCodigo: "", erroMensagem: "" };
}

function urlMensagens(cfg: Config): string {
  return `${GRAPH}/${cfg.versao || VERSAO_PADRAO}/${cfg.phoneNumberId}/messages`;
}

async function postar(cfg: Config, corpo: unknown): Promise<Resultado> {
  try {
    const res = await fetch(urlMensagens(cfg), {
      method: "POST",
      headers: {
        Authorization: `Bearer ${cfg.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(corpo),
    });
    return await lerResposta(res);
  } catch (e) {
    return { ok: false, wamid: "", erroCodigo: "rede", erroMensagem: String((e as Error)?.message || e) };
  }
}

/** Texto livre. Só passa dentro da janela de 24h — fora dela a Meta recusa. */
export function enviarTexto(
  cfg: Config,
  para: string,
  texto: string,
  responderAWamid = "",
): Promise<Resultado> {
  const corpo: Record<string, unknown> = {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to: para,
    type: "text",
    // `preview_url` liga a prévia de link — é o que faz um link de proposta
    // chegar com título e imagem em vez de uma URL crua.
    text: { body: texto, preview_url: true },
  };
  if (responderAWamid) corpo.context = { message_id: responderAWamid };
  return postar(cfg, corpo);
}

/**
 * Template aprovado — o único caminho com a janela fechada.
 *
 * As variáveis vão POSICIONAIS, na ordem de {{1}}, {{2}}... É a ordem que a
 * Meta espera; nome de variável não existe no corpo da requisição.
 */
export function enviarTemplate(
  cfg: Config,
  para: string,
  nome: string,
  idioma: string,
  variaveis: string[] = [],
): Promise<Resultado> {
  const componentes = variaveis.length
    ? [{ type: "body", parameters: variaveis.map((v) => ({ type: "text", text: String(v ?? "") })) }]
    : [];
  return postar(cfg, {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to: para,
    type: "template",
    template: {
      name: nome,
      language: { code: idioma || "pt_BR" },
      ...(componentes.length ? { components: componentes } : {}),
    },
  });
}

/**
 * A URL de mídia é confiável o bastante para virar link?
 *
 * Só `https:`. E não é preciosismo: a URL entra pelo corpo da requisição, é
 * gravada na mensagem MESMO QUANDO a Meta recusa o envio, e a tela a rende como
 * `href`. Um `javascript:` ali é script rodando na origem do Central, na sessão
 * de quem clicar — o atendente vê "📎 Proposta.pdf" e clica.
 *
 * `http:` também fica de fora: a Meta só busca link público em HTTPS, então
 * aceitar texto claro não compraria nada e ainda daria uma segunda forma do
 * mesmo link.
 */
export function urlDeMidiaValida(url: unknown): boolean {
  try {
    return new URL(String(url ?? "")).protocol === "https:";
  } catch {
    return false;
  }
}

/** Mídia já hospedada por nós, entregue à Meta pela URL pública. */
export function enviarMidiaPorLink(
  cfg: Config,
  para: string,
  tipo: "image" | "document" | "audio" | "video",
  link: string,
  legenda = "",
  nomeArquivo = "",
): Promise<Resultado> {
  const midia: Record<string, unknown> = { link };
  // Áudio não aceita legenda, e documento é o único que aceita nome de arquivo:
  // mandar o campo errado faz a Meta recusar a mensagem inteira.
  if (legenda && tipo !== "audio") midia.caption = legenda;
  if (nomeArquivo && tipo === "document") midia.filename = nomeArquivo;
  return postar(cfg, {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to: para,
    type: tipo,
    [tipo]: midia,
  });
}

/**
 * Marca a mensagem do cliente como lida (os dois tiques azuis no aparelho dele).
 *
 * Falhar aqui não atrapalha nada: é cortesia, não entrega.
 */
export async function marcarLidaNaMeta(cfg: Config, wamid: string): Promise<boolean> {
  if (!wamid) return false;
  try {
    const res = await fetch(urlMensagens(cfg), {
      method: "POST",
      headers: { Authorization: `Bearer ${cfg.token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ messaging_product: "whatsapp", status: "read", message_id: wamid }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

/**
 * Baixa uma mídia recebida.
 *
 * São duas chamadas: a primeira troca o id por uma URL, a segunda busca os
 * bytes — e ela também exige o token, apesar de a URL parecer pública. A URL
 * vale poucos minutos, e é por isso que o arquivo é copiado para o
 * armazenamento do app no momento em que chega, e não quando alguém abre.
 */
export async function baixarMidia(
  cfg: Config,
  mediaId: string,
  limiteBytes: number,
): Promise<{ ok: boolean; bytes: Uint8Array | null; mime: string; tamanho: number; motivo: string }> {
  const vazio = { ok: false, bytes: null, mime: "", tamanho: 0 };
  try {
    const meta = await fetch(`${GRAPH}/${cfg.versao || VERSAO_PADRAO}/${mediaId}`, {
      headers: { Authorization: `Bearer ${cfg.token}` },
    });
    if (!meta.ok) return { ...vazio, motivo: `metadados da mídia: HTTP ${meta.status}` };
    const dados = await meta.json();

    const tamanho = Number(dados?.file_size || 0);
    if (tamanho > limiteBytes) {
      return { ...vazio, tamanho, motivo: "arquivo maior que o limite guardado pelo Central" };
    }

    const arquivo = await fetch(String(dados?.url || ""), {
      headers: { Authorization: `Bearer ${cfg.token}` },
    });
    if (!arquivo.ok) return { ...vazio, motivo: `download da mídia: HTTP ${arquivo.status}` };

    const bytes = new Uint8Array(await arquivo.arrayBuffer());
    if (bytes.length > limiteBytes) {
      return { ...vazio, tamanho: bytes.length, motivo: "arquivo maior que o limite guardado pelo Central" };
    }
    return {
      ok: true,
      bytes,
      mime: String(dados?.mime_type || arquivo.headers.get("content-type") || ""),
      tamanho: bytes.length,
      motivo: "",
    };
  } catch (e) {
    return { ...vazio, motivo: String((e as Error)?.message || e) };
  }
}

/**
 * O cliente está pedindo para não receber mais automação?
 *
 * Mora aqui, e não dentro do webhook, para poder ser testado: a frase
 * "responda SAIR" está impressa nos templates aprovados, e um `pare` que não
 * casasse com o padrão faria a promessa virar mentira — que é o que leva alguém
 * a denunciar o número em vez de responder.
 *
 * Só a palavra sozinha conta. "Não quero sair do plano" é assunto de
 * atendimento, não descadastro.
 */
export function ehPedidoDeSaida(texto: unknown): boolean {
  return /^\s*(sair|parar|pare|stop|descadastrar|cancelar)\s*[.!]?\s*$/i
    .test(String(texto ?? ''));
}

/** Extensão a partir do mime, para o arquivo guardado ter nome utilizável. */
export function extensaoDoMime(mime: string): string {
  const mapa: Record<string, string> = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "video/mp4": "mp4",
    "video/3gpp": "3gp",
    "audio/ogg": "ogg",
    "audio/mpeg": "mp3",
    "audio/mp4": "m4a",
    "audio/amr": "amr",
    "application/pdf": "pdf",
    "application/msword": "doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
    "application/vnd.ms-excel": "xls",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
  };
  const limpo = String(mime || "").split(";")[0].trim();
  return mapa[limpo] || "bin";
}
