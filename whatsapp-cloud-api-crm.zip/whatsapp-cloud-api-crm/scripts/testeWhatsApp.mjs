// Teste do canal WhatsApp — as três regras que, erradas, custam caro.
//
//   sh scripts/rodarTestesWhatsApp.sh
//
// 1. O NÚMERO. A regra de normalização existe duas vezes: no navegador
//    (src/lib/whatsapp/telefone.js, que avisa a pessoa enquanto ela digita) e no
//    servidor (base44/shared/whatsapp.ts, que fala com a Meta). Duas cópias
//    porque os runtimes são diferentes — não porque possam divergir. Este teste
//    roda AS DUAS contra a mesma tabela: se alguém mexer em uma só, ele acusa.
//    Divergir aqui significa a tela aceitar um número que o envio recusa, ou
//    pior, mandar mensagem para outra pessoa.
//
// 2. A ASSINATURA DO WEBHOOK. É a única coisa que separa a caixa de entrada do
//    atendimento de um formulário aberto na internet. Um `===` no lugar da
//    comparação certa, ou um parse antes da conferência, e qualquer um pode
//    plantar mensagem falsa em nome de um cliente.
//
// 3. A JANELA DE 24H. Errar para mais faz a tela prometer resposta livre que a
//    Meta vai recusar; errar para menos faz o sistema cobrar um template que
//    não era necessário.
//
// O runner empacota os dois módulos REAIS com esbuild — testa o código de
// produção, não uma cópia dele.

import { webcrypto } from "node:crypto";
import {
  normalizarTelefone as normalizarCliente,
  formatarTelefone as formatarCliente,
  restanteDaJanela,
} from "@/lib/whatsapp/telefone";
import {
  normalizarTelefone as normalizarServidor,
  formatarTelefone as formatarServidor,
  variacoesTelefone,
  assinaturaConfere,
  fimDaJanela,
  janelaAberta,
  lerMensagem,
  statusDaMeta,
  previewDaMensagem,
  instanteDaMeta,
  urlDeMidiaValida,
  ehPedidoDeSaida,
} from "../base44/shared/whatsapp.ts";
import { ehAdminSistema, podeVerConversa } from "../base44/shared/whatsappAcesso.ts";
import {
  montarDestinatarios,
  resolverVariaveis,
  primeiroNome,
  variavelVazia,
  quantosCabemHoje,
  podeDisparar,
  proximaLeva,
  diaUTC,
} from "../base44/shared/whatsappCampanha.ts";
import { melhorNumeroWhatsApp } from "@/lib/whatsapp/contatoTelefone";

// HMAC no node precisa do webcrypto apontado no global (o Deno já traz).
if (!globalThis.crypto?.subtle) globalThis.crypto = webcrypto;

let falhas = 0;
const checar = (nome, real, esperado) => {
  const ok = JSON.stringify(real) === JSON.stringify(esperado);
  if (!ok) falhas++;
  console.log(
    `${ok ? "PASSA" : "FALHA"}  ${nome}${ok ? "" : `  (obtido: ${JSON.stringify(real)}, esperado: ${JSON.stringify(esperado)})`}`,
  );
};

// ── 1. O número, nos dois lados ──────────────────────────────────────────────

console.log("── Normalização do telefone (cliente e servidor têm de concordar)");

const CASOS = [
  // entrada                     esperado           por quê
  ["27999998888", "5527999998888", "celular com DDD, sem país"],
  ["(27) 99999-8888", "5527999998888", "pontuação de cadastro"],
  ["27 9 9999-8888", "5527999998888", "nono dígito separado"],
  ["5527999998888", "5527999998888", "já normalizado"],
  ["+55 27 99999-8888", "5527999998888", "com + e país"],
  ["552733334444", "552733334444", "fixo com país (12 dígitos)"],
  ["2733334444", "552733334444", "fixo com DDD, sem país"],
  ["55999998888", "5555999998888", "DDD 55 (Santa Maria) não é código de país"],
  ["+1 415 555 0100", "14155550100", "internacional declarado com +"],
  ["0014155550100", "14155550100", "internacional discado com 00"],
  ["99998888", null, "sem DDD: não dá para afirmar qual é"],
  ["14155550100", "5514155550100", "11 dígitos sem + é lido como brasileiro"],
  ["", null, "vazio"],
  [null, null, "nulo"],
  ["abc", null, "sem dígito nenhum"],
];

for (const [entrada, esperado, motivo] of CASOS) {
  const doCliente = normalizarCliente(entrada);
  const doServidor = normalizarServidor(entrada);
  checar(`normalizar ${JSON.stringify(entrada)} — ${motivo}`, doCliente, esperado);
  checar(`  servidor concorda com o cliente (${JSON.stringify(entrada)})`, doServidor, doCliente);
}

console.log();
console.log("── Formatação para leitura");
for (const [numero, esperado] of [
  ["5527999998888", "+55 (27) 99999-8888"],
  ["552733334444", "+55 (27) 3333-4444"],
  ["14155550100", "+14155550100"],
  ["", ""],
]) {
  checar(`formatar ${numero || "(vazio)"}`, formatarCliente(numero), esperado);
  checar(`  servidor concorda (${numero || "vazio"})`, formatarServidor(numero), formatarCliente(numero));
}

console.log();
console.log("── Variações para casar com o cadastro");
// O nono dígito entrou em 2013 e o cadastro tem os dois formatos: procurar só
// pela forma canônica deixaria de reconhecer metade de quem escreve.
const variacoes = variacoesTelefone("5527999998888");
checar("variações incluem a forma canônica", variacoes.includes("5527999998888"), true);
checar("variações incluem sem o nono dígito", variacoes.includes("552799998888"), true);
checar("variações incluem sem o código do país", variacoes.includes("27999998888"), true);
checar("variações incluem só o número", variacoes.includes("999998888"), true);
checar("número irreconhecível não gera variação", variacoesTelefone("abc"), []);

// ── 2. A assinatura do webhook ───────────────────────────────────────────────

console.log();
console.log("── Assinatura do webhook (X-Hub-Signature-256)");

const SEGREDO = "segredo-do-app-da-meta";
const CORPO = JSON.stringify({ entry: [{ changes: [{ field: "messages" }] }] });

async function assinar(corpo, segredo) {
  const chave = await globalThis.crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(segredo),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const bytes = await globalThis.crypto.subtle.sign("HMAC", chave, new TextEncoder().encode(corpo));
  return `sha256=${Array.from(new Uint8Array(bytes)).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}

const valida = await assinar(CORPO, SEGREDO);

checar("assinatura correta passa", await assinaturaConfere(CORPO, valida, SEGREDO), true);
checar(
  "maiúsculas no cabeçalho não derrubam",
  await assinaturaConfere(CORPO, valida.toUpperCase(), SEGREDO),
  true,
);
checar(
  "corpo alterado é recusado",
  await assinaturaConfere(`${CORPO} `, valida, SEGREDO),
  false,
);
checar(
  "outro segredo é recusado",
  await assinaturaConfere(CORPO, valida, "outro-segredo"),
  false,
);
checar("sem cabeçalho é recusado", await assinaturaConfere(CORPO, null, SEGREDO), false);
checar(
  "sem o prefixo sha256= é recusado",
  await assinaturaConfere(CORPO, valida.replace("sha256=", ""), SEGREDO),
  false,
);
checar(
  "sem segredo configurado nada passa",
  await assinaturaConfere(CORPO, valida, ""),
  false,
);
// Reserializar o corpo muda espaços e ordem — é o erro clássico que derruba a
// conferência de webhook, e este caso existe para deixá-lo registrado.
checar(
  "corpo reserializado com espaços é recusado",
  await assinaturaConfere(JSON.stringify(JSON.parse(CORPO), null, 2), valida, SEGREDO),
  false,
);

// ── 3. A janela de 24h ───────────────────────────────────────────────────────

console.log();
console.log("── Janela de 24h");

const AGORA = Date.parse("2026-09-08T12:00:00.000Z");
checar(
  "a janela fecha 24h depois da mensagem do cliente",
  fimDaJanela("2026-09-08T12:00:00.000Z"),
  "2026-09-09T12:00:00.000Z",
);
checar("dentro da janela aceita texto livre", janelaAberta("2026-09-08T12:00:01.000Z", AGORA), true);
checar("no instante do vencimento já fechou", janelaAberta("2026-09-08T12:00:00.000Z", AGORA), false);
checar("depois do vencimento está fechada", janelaAberta("2026-09-08T11:59:59.000Z", AGORA), false);
checar("conversa sem janela nenhuma está fechada", janelaAberta("", AGORA), false);
checar("data inválida não abre a janela", janelaAberta("qualquer coisa", AGORA), false);

checar("restante em horas", restanteDaJanela("2026-09-08T15:00:00.000Z", AGORA), "3 h");
checar("restante em minutos", restanteDaJanela("2026-09-08T12:40:00.000Z", AGORA), "40 min");
checar("janela vencida não tem restante", restanteDaJanela("2026-09-08T11:00:00.000Z", AGORA), "");

// ── 4. Leitura do payload da Meta ────────────────────────────────────────────

console.log();
console.log("── Leitura das mensagens que chegam");

const texto = lerMensagem({
  id: "wamid.ABC",
  from: "5527999998888",
  timestamp: "1757332800",
  type: "text",
  text: { body: "Bom dia, preciso de ajuda" },
});
checar("texto: tipo", texto.tipo, "texto");
checar("texto: corpo", texto.texto, "Bom dia, preciso de ajuda");
checar("texto: wamid preservado", texto.wamid, "wamid.ABC");
checar("texto: instante convertido de segundos", texto.ocorridoEm, instanteDaMeta("1757332800"));

const imagem = lerMensagem({
  id: "wamid.IMG",
  from: "5527999998888",
  type: "image",
  image: { id: "media-1", mime_type: "image/jpeg", caption: "o print do erro" },
});
checar("imagem: tipo em português", imagem.tipo, "imagem");
checar("imagem: legenda vira o texto", imagem.texto, "o print do erro");
checar("imagem: id da mídia guardado para o download", imagem.mediaId, "media-1");

const documento = lerMensagem({
  id: "wamid.DOC",
  from: "5527999998888",
  type: "document",
  document: { id: "media-2", filename: "contrato.pdf", mime_type: "application/pdf" },
});
checar("documento: nome do arquivo", documento.midiaNome, "contrato.pdf");

const local = lerMensagem({
  id: "wamid.LOC",
  from: "5527999998888",
  type: "location",
  location: { latitude: -20.3, longitude: -40.3, name: "Escritório" },
});
checar("localização: nome vira texto", local.texto, "Escritório");
checar("localização: coordenadas nos metadados", local.metadados.latitude, -20.3);

const botao = lerMensagem({
  id: "wamid.BTN",
  from: "5527999998888",
  type: "interactive",
  interactive: { type: "button_reply", button_reply: { id: "sim", title: "Confirmo" } },
});
checar("resposta de botão vira o texto que a pessoa tocou", botao.texto, "Confirmo");

// O caso que mais importa: um tipo que a Meta inventar depois. Ele NÃO pode
// virar erro — o atendimento precisa ver que o cliente respondeu.
const novoTipo = lerMensagem({ id: "wamid.NOVO", from: "5527999998888", type: "tipo_do_futuro" });
checar("tipo desconhecido não estoura", novoTipo.tipo, "nao_suportado");
checar("tipo desconhecido explica o que houve", novoTipo.texto.includes("tipo_do_futuro"), true);

const citacao = lerMensagem({
  id: "wamid.RESP",
  from: "5527999998888",
  type: "text",
  text: { body: "isso mesmo" },
  context: { id: "wamid.ABC" },
});
checar("citação guarda a mensagem respondida", citacao.respondendoAWamid, "wamid.ABC");

console.log();
console.log("── Status de entrega e prévia");
checar("sent vira enviada", statusDaMeta("sent"), "enviada");
checar("delivered vira entregue", statusDaMeta("delivered"), "entregue");
checar("read vira lida", statusDaMeta("read"), "lida");
checar("failed vira falhou", statusDaMeta("failed"), "falhou");
checar("status desconhecido não vira nada", statusDaMeta("qualquer"), "");

checar("prévia usa o texto quando existe", previewDaMensagem("texto", "  oi   tudo bem "), "oi tudo bem");
checar("mídia sem legenda ganha rótulo", previewDaMensagem("imagem", ""), "📷 Imagem");
checar("documento sem legenda ganha rótulo", previewDaMensagem("documento", ""), "📎 Documento");

console.log();
console.log("── URL de mídia (o que pode virar link na thread)");
// A URL entra pelo corpo da requisição e a mensagem é gravada mesmo quando a
// Meta recusa o envio — então o que passa daqui vira `href` na tela de quem
// abrir a conversa. Um `javascript:` ali roda na sessão do atendente.
checar("https passa", urlDeMidiaValida("https://exemplo.com/proposta.pdf"), true);
checar("javascript: é recusado", urlDeMidiaValida("javascript:alert(1)"), false);
checar("javascript: com maiúsculas é recusado", urlDeMidiaValida("JavaScript:alert(1)"), false);
checar("data: é recusado", urlDeMidiaValida("data:text/html;base64,PHNjcmlwdD4="), false);
checar("http (texto claro) é recusado", urlDeMidiaValida("http://exemplo.com/x.pdf"), false);
checar("caminho relativo é recusado", urlDeMidiaValida("/arquivos/x.pdf"), false);
checar("vazio é recusado", urlDeMidiaValida(""), false);
checar("nulo é recusado", urlDeMidiaValida(null), false);

console.log();
console.log("── Pedido de saída das automações");
// Os templates aprovados terminam com "responda SAIR". Um "pare" que não casasse
// aqui faria a promessa virar mentira — e promessa de descadastro quebrada é o
// que leva à denúncia que derruba a nota do número.
for (const palavra of ["SAIR", "sair", " Sair ", "parar", "pare", "stop", "descadastrar", "cancelar", "Sair."]) {
  checar(`"${palavra}" desliga a automação`, ehPedidoDeSaida(palavra), true);
}
// E o que NÃO é pedido de saída, porque é assunto de atendimento.
for (const frase of [
  "não quero sair do plano",
  "posso cancelar a reunião de amanhã?",
  "pare de cobrar o boleto errado",
  "",
]) {
  checar(`"${frase || "(vazio)"}" não desliga nada`, ehPedidoDeSaida(frase), false);
}

console.log();
console.log("── Quem enxerga qual conversa");
// Errar aqui não é detalhe de tela: é um consultor lendo a conversa do cliente
// de outro, ou — do outro lado — mensagem de cliente novo não aparecendo para
// ninguém e ficando sem resposta.
const meuAlcance = {
  tudo: false,
  clientesIds: new Set(["cli-meu"]),
  prospectsIds: new Set(["pro-meu"]),
};
const alcanceDeAdmin = { tudo: true, clientesIds: new Set(), prospectsIds: new Set() };

checar(
  "vejo a conversa do meu cliente",
  podeVerConversa({ vinculoTipo: "cliente", vinculoId: "cli-meu" }, meuAlcance),
  true,
);
checar(
  "não vejo a do cliente de outro consultor",
  podeVerConversa({ vinculoTipo: "cliente", vinculoId: "cli-alheio" }, meuAlcance),
  false,
);
checar(
  "vejo o prospect que é meu",
  podeVerConversa({ vinculoTipo: "prospect", vinculoId: "pro-meu" }, meuAlcance),
  true,
);
checar(
  "não vejo o prospect de outro",
  podeVerConversa({ vinculoTipo: "prospect", vinculoId: "pro-alheio" }, meuAlcance),
  false,
);
// Número novo que ninguém vinculou ainda precisa aparecer, ou a mensagem se
// perde — é a escolha explicada em shared/whatsappAcesso.ts.
checar(
  "conversa ainda sem vínculo aparece para todos",
  podeVerConversa({ vinculoTipo: "nenhum", vinculoId: "" }, meuAlcance),
  true,
);
checar(
  "vínculo com tipo mas sem id conta como sem dono",
  podeVerConversa({ vinculoTipo: "cliente", vinculoId: "" }, meuAlcance),
  true,
);
checar("admin vê a de qualquer um", podeVerConversa({ vinculoTipo: "cliente", vinculoId: "cli-alheio" }, alcanceDeAdmin), true);

checar("isAdmin explícito é admin", ehAdminSistema({ isAdmin: true }), true);
checar("cargo Admin é admin", ehAdminSistema({ cargosNomes: ["Consultor", "admin"] }), true);
checar("consultor comum não é admin", ehAdminSistema({ cargosNomes: ["Consultor"] }), false);
checar("usuário vazio não é admin", ehAdminSistema({}), false);

// ── 5. De onde a ficha tira o número ─────────────────────────────────────────
//
// O botão do WhatsApp se esconde quando não acha número — e foi assim que ele
// sumiu da ficha de quem veio do CRM, cujo telefone mora em `telefones[]` e não
// no campo legado. A regra da procura é o que este bloco protege: um campo novo
// no cadastro não pode voltar a esconder o botão em silêncio.

console.log();
console.log("── De onde a ficha tira o número do WhatsApp");

const numeroDe = (...fontes) => melhorNumeroWhatsApp(fontes)?.numero || null;

checar("campo whatsapp ganha de tudo", numeroDe({
  whatsapp: "27 99999-1111",
  telefones: [{ numero: "27 99999-2222", tipo: "Celular" }],
  telefone: "27 3333-4444",
}), "5527999991111");

checar("celular ganha do fixo, esteja onde estiver na lista", numeroDe({
  telefones: [{ numero: "27 3333-4444", tipo: "Comercial" }, { numero: "27 99999-2222", tipo: "Celular" }],
}), "5527999992222");

checar("sem tipo, vale a ordem da lista", numeroDe({
  telefones: [{ numero: "27 3333-4444" }, { numero: "27 99999-2222" }],
}), "552733334444");

checar("cai no campo legado quando a lista está vazia", numeroDe({ telefones: [], telefone: "27 99999-3333" }), "5527999993333");

// O caso que motivou tudo: legado sem telefone, Agente com a lista preenchida.
checar("o Agente cobre o legado vazio", numeroDe(
  { nome: "Cliente sem telefone" },
  { telefones: [{ numero: "11 98888-7777", tipo: "Celular" }] },
), "5511988887777");

// Só depois de esgotar TODAS as fontes próprias é que o sócio entra.
checar("o número da empresa ganha do sócio", numeroDe(
  { pessoasVinculadas: [{ nome: "Dra. Ana", telefone: "11 97777-6666" }] },
  { telefone: "11 3030-2020" },
), "551130302020");

checar("o sócio entra quando não há número próprio", numeroDe(
  { pessoasVinculadas: [{ nome: "Dra. Ana", telefone: "11 97777-6666" }] },
), "5511977776666");

checar("e volta com o nome de quem atende", melhorNumeroWhatsApp([
  { pessoasVinculadas: [{ nome: "Dra. Ana", telefone: "11 97777-6666" }] },
])?.pessoa, "Dra. Ana");

checar("telefone solto (string) continua valendo", numeroDe("27 99999-0000"), "5527999990000");
checar("número impossível não vira botão", numeroDe({ telefone: "1234" }), null);
checar("cadastro vazio não vira botão", numeroDe(null, undefined, {}), null);

// ── 8. Campanha em lote: as três formas de queimar um número ────────────────
//
// Mandar para quem saiu, mandar duas vezes, e mandar mais do que o degrau da
// Meta permite. As três decisões são de `shared/whatsappCampanha.ts`, e é por
// isso que elas têm teste: errar qualquer uma não dá erro na hora — dá
// denúncia e queda de qualidade dias depois.

console.log();
console.log("── Campanha: montagem do público");

const cad = (dados) => ({ tipo: "cliente", dados });

checar("quem tem número entra como pendente", montarDestinatarios([
  cad({ id: "c1", nome: "Ana Paula Souza", telefone: "27 99999-8888" }),
])[0].status, "pendente");

checar("e o número sai normalizado", montarDestinatarios([
  cad({ id: "c1", nome: "Ana", telefone: "(27) 99999-8888" }),
])[0].telefone, "5527999998888");

checar("quem pediu para sair é pulado", montarDestinatarios([
  cad({ id: "c1", nome: "Ana", telefone: "27 99999-8888", whatsappOptOut: true }),
])[0].status, "pulado");

checar("e o motivo fica escrito", montarDestinatarios([
  cad({ id: "c1", nome: "Ana", telefone: "27 99999-8888", whatsappOptOut: true }),
])[0].motivo, "pediu para não receber");

checar("quem não tem número é pulado, não some", montarDestinatarios([
  cad({ id: "c1", nome: "Sem Telefone" }),
])[0].motivo, "sem telefone utilizável");

checar("número impossível também é pulado", montarDestinatarios([
  cad({ id: "c1", nome: "Ana", telefone: "1234" }),
])[0].motivo, "sem telefone utilizável");

// A trava que mais importa: o mesmo número não recebe duas vezes, mesmo
// vindo de cadastros diferentes — do lado de lá é a mesma pessoa.
const repetidos = montarDestinatarios([
  cad({ id: "c1", nome: "Ana", telefone: "27 99999-8888" }),
  cad({ id: "c2", nome: "Ana (duplicada)", telefone: "(27) 9 9999-8888" }),
]);
checar("o primeiro do número repetido entra", repetidos[0].status, "pendente");
checar("o segundo é pulado", repetidos[1].status, "pulado");
checar("e diz que é repetição", repetidos[1].motivo, "número repetido na campanha");

checar("quem já estava na campanha não entra de novo", montarDestinatarios(
  [cad({ id: "c1", nome: "Ana", telefone: "27 99999-8888" })],
  ["5527999998888"],
)[0].status, "pulado");

checar("nenhuma linha se perde no caminho", montarDestinatarios([
  cad({ id: "c1", nome: "Ana", telefone: "27 99999-8888" }),
  cad({ id: "c2", nome: "Sem número" }),
  cad({ id: "c3", nome: "Saiu", telefone: "27 98888-7777", whatsappOptOut: true }),
]).length, 3);

checar("prospect carrega o próprio tipo", montarDestinatarios([
  { tipo: "prospect", dados: { id: "p1", nome: "Lead", telefone: "27 99999-0000" } },
])[0].tipo, "prospect");

checar("whatsapp ganha do telefone quando existe", montarDestinatarios([
  cad({ id: "c1", nome: "Ana", telefone: "27 3333-4444", whatsapp: "27 99999-8888" }),
])[0].telefone, "5527999998888");

console.log();
console.log("── Campanha: variáveis do template");

const alvo1 = { nome: "Ana Paula Souza", empresa: "Souza Advogados", responsavelNome: "Yago" };

checar("texto fixo vale para todos", resolverVariaveis(
  [{ origem: "fixo", valor: "20 de dezembro" }], alvo1,
), ["20 de dezembro"]);

checar("campo lê do cadastro", resolverVariaveis(
  [{ origem: "campo", campo: "nome" }], alvo1,
), ["Ana Paula Souza"]);

checar("primeiro nome é só o primeiro", primeiroNome("Ana Paula Souza"), "Ana");
checar("primeiro nome de vazio é vazio", primeiroNome(null), "");

checar("a ordem das variáveis é respeitada", resolverVariaveis([
  { origem: "campo", campo: "primeiroNome" },
  { origem: "fixo", valor: "20/12" },
], alvo1), ["Ana", "20/12"]);

// A Meta recusa o template inteiro se uma variável vier vazia — melhor pular a
// linha antes de gastar uma tentativa e uma recusa com ela.
checar("variável vazia é detectada", variavelVazia(["Ana", ""]), true);
checar("só espaço também conta como vazia", variavelVazia(["   "]), true);
checar("tudo preenchido passa", variavelVazia(["Ana", "20/12"]), false);
checar("campo ausente no cadastro vira vazio", resolverVariaveis(
  [{ origem: "campo", campo: "empresa" }], { nome: "Ana" },
), [""]);

console.log();
console.log("── Campanha: o teto diário da Meta");

const hoje = new Date("2026-09-16T10:00:00Z");

checar("campanha nova tem o teto inteiro", quantosCabemHoje(
  { limiteDiario: 200 }, hoje,
), 200);

checar("o que já saiu hoje desconta", quantosCabemHoje(
  { limiteDiario: 200, enviadasHoje: 50, diaDaContagem: "2026-09-16" }, hoje,
), 150);

checar("teto batido não deixa passar nem mais um", quantosCabemHoje(
  { limiteDiario: 200, enviadasHoje: 200, diaDaContagem: "2026-09-16" }, hoje,
), 0);

// A contagem de ontem não pode segurar a rodada de hoje.
checar("a contagem zera quando o dia vira", quantosCabemHoje(
  { limiteDiario: 200, enviadasHoje: 200, diaDaContagem: "2026-09-15" }, hoje,
), 200);

checar("um dia sem rodada nenhuma também zera", quantosCabemHoje(
  { limiteDiario: 200, enviadasHoje: 200, diaDaContagem: "2026-09-01" }, hoje,
), 200);

checar("sem limite definido cai no padrão conservador", quantosCabemHoje({}, hoje), 200);
checar("limite absurdo não vira teto negativo", quantosCabemHoje(
  { limiteDiario: -5 }, hoje,
), 200);
checar("o dia é lido em UTC", diaUTC(hoje), "2026-09-16");

console.log();
console.log("── Campanha: quem pode disparar");

const aprovada = { status: "aprovada", aprovadoPorUserId: "u1", templateNome: "aviso_geral" };

checar("aprovada com assinatura dispara", podeDisparar(aprovada).ok, true);
checar("rascunho não dispara", podeDisparar({ ...aprovada, status: "rascunho" }).ok, false);
checar("aguardando aprovação não dispara", podeDisparar({ ...aprovada, status: "aguardando_aprovacao" }).ok, false);
checar("recusada não dispara", podeDisparar({ ...aprovada, status: "recusada" }).ok, false);
checar("cancelada não dispara", podeDisparar({ ...aprovada, status: "cancelada" }).ok, false);
checar("concluída não dispara", podeDisparar({ ...aprovada, status: "concluida" }).ok, false);

// A trava que não depende do status: status é campo que qualquer caminho
// futuro pode escrever; a assinatura de quem liberou não se põe por acidente.
checar("status aprovada SEM assinatura não dispara", podeDisparar(
  { status: "aprovada", templateNome: "aviso_geral" },
).ok, false);
checar("e diz que falta a aprovação", podeDisparar(
  { status: "aprovada", templateNome: "aviso_geral" },
).motivo, "sem aprovação registrada");
checar("sem template não dispara", podeDisparar(
  { status: "aprovada", aprovadoPorUserId: "u1" },
).ok, false);
checar("campanha inexistente não dispara", podeDisparar(null).ok, false);

console.log();
console.log("── Campanha: a próxima leva");

const fila = [
  { id: "d1", status: "pendente", tentativas: 0 },
  { id: "d2", status: "enviado", tentativas: 1 },
  { id: "d3", status: "pendente", tentativas: 0 },
  { id: "d4", status: "pulado", tentativas: 0 },
  { id: "d5", status: "pendente", tentativas: 3 },
];

checar("só os pendentes entram", proximaLeva(fila, 10).map((d) => d.id), ["d1", "d3"]);
checar("a leva respeita as vagas", proximaLeva(fila, 1).map((d) => d.id), ["d1"]);
checar("sem vaga, ninguém sai", proximaLeva(fila, 0), []);
checar("teto negativo não vira leva", proximaLeva(fila, -3), []);
checar("quem esgotou as tentativas fica de fora", proximaLeva(fila, 10).some((d) => d.id === "d5"), false);
checar("fila vazia não quebra", proximaLeva([], 10), []);

console.log();
console.log(falhas === 0 ? "Canal do WhatsApp: todas as regras no lugar." : `${falhas} verificação(ões) falharam.`);
process.exit(falhas === 0 ? 0 : 1);
