#!/bin/sh
# Teste do canal WhatsApp (número, assinatura do webhook e janela de 24h).
#
#   sh scripts/rodarTestesWhatsApp.sh
#
# O projeto não tem runner de testes; este roda direto no node. Ele importa os
# módulos REAIS dos dois lados — o do navegador pelo alias "@/" e o do servidor
# pelo caminho relativo, TypeScript e tudo —, empacotados com esbuild. É o que
# permite provar que a regra do telefone é a mesma nos dois, que é justamente o
# que ninguém percebe quando deixa de ser.
set -e

raiz=$(cd "$(dirname "$0")/.." && pwd)

npx --yes esbuild "$raiz/scripts/testeWhatsApp.mjs" \
  --bundle --platform=node --format=esm \
  --alias:@="$raiz/src" \
  --outfile="$raiz/.teste-whatsapp.mjs" \
  --log-level=warning

node "$raiz/.teste-whatsapp.mjs" || { rm -f "$raiz/.teste-whatsapp.mjs"; exit 1; }
rm -f "$raiz/.teste-whatsapp.mjs"
